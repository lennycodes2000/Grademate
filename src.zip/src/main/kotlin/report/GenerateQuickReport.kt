import components.Constants.recipients
import org.apache.pdfbox.pdmodel.PDDocument
import org.apache.pdfbox.pdmodel.PDPage
import org.apache.pdfbox.pdmodel.PDPageContentStream
import org.apache.pdfbox.pdmodel.common.PDRectangle
import org.apache.pdfbox.pdmodel.font.PDFont
import org.apache.pdfbox.pdmodel.font.PDType1Font
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject
import java.awt.Desktop
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

fun generateQuickReport(
    module: Module,
    students: List<Student>,
    grades: List<Grade>,
    academicYear: String,
    selectedIntake: String,
    name: String
) {
    val passingScore = 30
    val maxNameFontSize = 12f
    val minNameFontSize = 8f

    val document = PDDocument()
    val pageSize = PDRectangle(PDRectangle.LETTER.height, PDRectangle.LETTER.width) // Landscape
    val pageWidth = pageSize.width
    val pageHeight = pageSize.height

    val pages = mutableListOf<PDPage>()
    var currentPage = PDPage(pageSize)
    document.addPage(currentPage)
    pages.add(currentPage)

    var contentStream = PDPageContentStream(document, currentPage)
    val margin = 50f
    var yPosition = pageHeight - margin
    val lineSpacing = 18f

    fun newPage() {
        contentStream.close()
        currentPage = PDPage(pageSize)
        document.addPage(currentPage)
        pages.add(currentPage)
        contentStream = PDPageContentStream(document, currentPage)
        yPosition = pageHeight - margin
    }

    fun drawCenteredText(text: String, font: PDFont, fontSize: Float, yOffset: Float) {
        val textWidth = font.getStringWidth(text) / 1000 * fontSize
        val x = (pageWidth - textWidth) / 2
        contentStream.beginText()
        contentStream.setFont(font, fontSize)
        contentStream.newLineAtOffset(x, yOffset)
        contentStream.showText(text)
        contentStream.endText()
    }

    // ==== HEADER ====
    drawCenteredText("BIHARAMULO COLLEGE OF BUSINESS AND TECHNOLOGY ( BCBT )", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= 25f

    val resourceStream = object {}.javaClass.getResourceAsStream("/logo.png")
    if (resourceStream != null) {
        val tempLogoFile = File.createTempFile("logo", ".png")
        tempLogoFile.deleteOnExit()
        tempLogoFile.outputStream().use { output -> resourceStream.copyTo(output) }
        val pdImage = PDImageXObject.createFromFileByContent(tempLogoFile, document)
        val imgWidth = 70f
        val imgHeight = (pdImage.height.toFloat() / pdImage.width.toFloat()) * imgWidth
        val imgX = (pageWidth - imgWidth) / 2
        val imgY = yPosition - imgHeight
        contentStream.drawImage(pdImage, imgX, imgY, imgWidth, imgHeight)
        yPosition = imgY - 20f
    }

    drawCenteredText("DEPARTMENT OF INFORMATION AND COMMUNICATION TECHNOLOGY", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= lineSpacing
    drawCenteredText("SEMESTER EXAMINATION / SPECIAL & SUPPLEMENTARY EXAMINATION", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= lineSpacing
    drawCenteredText("Module Name: ${module.name}", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= lineSpacing

    val ntaLevel = module.code.filter { it.isDigit() }.drop(1).firstOrNull()?.toString() ?: "-"
    drawCenteredText("Module Code: ${module.code}     NTA Level: $ntaLevel", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= lineSpacing

    val semester = module.code.filter { it.isDigit() }.drop(2).firstOrNull()?.toString() ?: "-"
    drawCenteredText("Year of Study: $academicYear ($selectedIntake Intake)   Semester: $semester", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= 30f

    // ==== TABLE HEADER ====
    val colTitles = listOf("S/N", "Reg Number", "Full Name", "CA", "UE/SE", "Total", "Grade")
    val colWidths = listOf(30f, 110f, 210f, 30f, 45f, 40f, 40f)
    val colX = colWidths.runningFold(margin) { acc, w -> acc + w }.dropLast(1)

    val cellHeight = 20f
    val textPaddingTop = 5f

    contentStream.setFont(PDType1Font.TIMES_BOLD, 12f)
    contentStream.setStrokingColor(java.awt.Color.BLACK)
    contentStream.setLineWidth(1f)

    // Header row
    for (i in colTitles.indices) {
        contentStream.addRect(colX[i], yPosition - cellHeight, colWidths[i], cellHeight)
    }
    contentStream.stroke()
    for (i in colTitles.indices) {
        contentStream.beginText()
        contentStream.newLineAtOffset(colX[i] + 2f, yPosition - cellHeight + textPaddingTop)
        contentStream.showText(colTitles[i])
        contentStream.endText()
    }
    yPosition -= cellHeight

    contentStream.setFont(PDType1Font.TIMES_ROMAN, 12f)

    // ==== FILTER STUDENTS ====
    val validStudents = students.filter { student ->
        val grade = grades.find { it.studentId == student.regNo && it.moduleCode == module.code }
        val ca = grade?.let { g ->
            listOf(g.assignmentMark, g.quizMark, g.attendanceMark, g.testOneMark, g.testTwoMark)
                .sumOf { mark -> mark.toDoubleOrNull() ?: 0.0 }
        } ?: 0.0
        ca > 0.0
    }

    // ==== TABLE ROWS ====
    validStudents.forEachIndexed { index, student ->
        if (yPosition < 100f) newPage()

        val grade = grades.find { it.studentId == student.regNo && it.moduleCode == module.code }
        val ca = grade?.let { g ->
            String.format(
                "%.1f",
                listOf(g.assignmentMark, g.quizMark, g.attendanceMark, g.testOneMark, g.testTwoMark)
                    .sumOf { mark -> mark.toDoubleOrNull() ?: 0.0 }
            )
        } ?: ""

        val exam = grade?.examMark
        val total = String.format("%.1f", (ca.toDoubleOrNull() ?: 0.0) + (exam?.toDoubleOrNull() ?: 0.0))

        val levelFour = listOf("A", "B", "C", "D", "F")
        val levelSix = listOf("A", "B+", "B", "C", "D", "F")

        val caValue = ca.toDoubleOrNull() ?: 0.0
        val examValue = exam?.toDoubleOrNull()
        val totalValue = total.toDoubleOrNull()
        val ntaLevelInt = ntaLevel.trim().toIntOrNull() ?: -1

        val remark = when {
            caValue >= passingScore && exam.isNullOrEmpty() -> "Passed"
            caValue < passingScore && exam.isNullOrEmpty() -> "Repeat"
            caValue >= passingScore && examValue != null && examValue < 20.0 -> "Supp"
            (ntaLevelInt == 4 || ntaLevelInt == 5) && examValue != null && totalValue != null -> when {
                totalValue >= 80 -> levelFour[0]
                totalValue >= 65 -> levelFour[1]
                totalValue >= 50 -> levelFour[2]
                totalValue >= 40 -> levelFour[3]
                else -> levelFour[4]
            }
            ntaLevelInt == 6 && examValue != null && totalValue != null -> when {
                totalValue >= 75 -> levelSix[0]
                totalValue >= 65 -> levelSix[1]
                totalValue >= 55 -> levelSix[2]
                totalValue >= 45 -> levelSix[3]
                totalValue >= 35 -> levelSix[4]
                else -> levelSix[5]
            }
            else -> "Pending"
        }

        val values = listOf(
            (index + 1).toString(),
            student.regNo,
            student.studentName,
            ca,
            exam,
            total,
            remark
        )

        for (i in values.indices) {
            contentStream.addRect(colX[i], yPosition - cellHeight, colWidths[i], cellHeight)
        }
        contentStream.stroke()

        for (i in values.indices) {
            val fontSize = if (i == 1) {
                val textWidth = PDType1Font.TIMES_ROMAN.getStringWidth(values[i]) / 1000
                val maxWidth = colWidths[i] - 4f
                (maxNameFontSize.coerceAtMost((maxWidth / textWidth))).coerceAtLeast(minNameFontSize)
            } else 12f

            contentStream.beginText()
            contentStream.setFont(PDType1Font.TIMES_ROMAN, fontSize)
            contentStream.newLineAtOffset(colX[i] + 2f, yPosition - cellHeight + textPaddingTop)
            contentStream.showText(values[i])
            contentStream.endText()
        }

        yPosition -= cellHeight
    }

    // ==== FOOTER ====
    yPosition -= 20f
    val nameFont = PDType1Font.TIMES_ROMAN
    val formatter = DateTimeFormatter.ofPattern("dd MMMM,yy HH:mm")
    val timestamp = LocalDateTime.now().format(formatter)
    drawCenteredText("Generated from GradeMate App On $timestamp", nameFont, 8f, 40f)

    pages.forEachIndexed { index, page ->
        val footer = PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true)
        footer.beginText()
        footer.setFont(nameFont, 8f)
        val footerText = "Page ${index + 1} of ${pages.size}"
        val footerWidth = nameFont.getStringWidth(footerText) / 1000 * 8f
        footer.newLineAtOffset((pageWidth - footerWidth) / 2, 20f)
        footer.showText(footerText)
        footer.endText()
        footer.close()
    }

    contentStream.close()

    val outputFile = File("GradeSheet_${module.code}.pdf")
    document.save(outputFile)
    document.close()

    // ✅ Open document first
    try {
        if (Desktop.isDesktopSupported()) {
            Desktop.getDesktop().open(outputFile)
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }

    // ✅ Then send email
    if (outputFile.exists() && outputFile.length() > 0) {
        sendEmail(
            to = recipients,
            subject = "${module.code}_${module.name}_$selectedIntake Intake_$academicYear",
            body = "Please find the attached grade sheet generated by user ${name.takeIf { it.isNotEmpty() }}",
            attachment = outputFile
        )
        println("✅ Email sent with attachment: ${outputFile.name}")
    } else {
        println("⚠️ Email not sent. Attachment file is missing or empty: ${outputFile.absolutePath}")
    }
}

