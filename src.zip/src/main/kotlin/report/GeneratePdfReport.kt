
import org.apache.pdfbox.pdmodel.PDDocument
import org.apache.pdfbox.pdmodel.PDPage
import org.apache.pdfbox.pdmodel.PDPageContentStream
import org.apache.pdfbox.pdmodel.common.PDRectangle
import org.apache.pdfbox.pdmodel.font.PDFont
import org.apache.pdfbox.pdmodel.font.PDType1Font
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject
import java.awt.Desktop
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
fun generatePdfReport(
    module: Module,
    students: List<Student>,
    grades: List<Grade>,
    instructor: String,
    hod: String,
    examOfficer: String,
    academicYear: String,
    selectedIntake: String,
    name:String
) {
    val passingScore = 30
    val maxNameFontSize = 12f
    val minNameFontSize = 8f

    val document = PDDocument()
    val pageSize = PDRectangle(PDRectangle.LETTER.height, PDRectangle.LETTER.width) // Landscape
    val pageWidth = pageSize.width
    val pageHeight = pageSize.height

    val pages = mutableListOf<PDPage>()
    var currentPage = PDPage(pageSize)
    document.addPage(currentPage)
    pages.add(currentPage)

    var contentStream = PDPageContentStream(document, currentPage)
    val margin = 50f
    var yPosition = pageHeight - margin
    val lineSpacing = 18f

    fun newPage() {
        contentStream.close()
        currentPage = PDPage(pageSize)
        document.addPage(currentPage)
        pages.add(currentPage)
        contentStream = PDPageContentStream(document, currentPage)
        yPosition = pageHeight - margin
    }

    fun drawCenteredText(text: String, font: PDFont, fontSize: Float, yOffset: Float) {
        val textWidth = font.getStringWidth(text) / 1000 * fontSize
        val x = (pageWidth - textWidth) / 2
        contentStream.beginText()
        contentStream.setFont(font, fontSize)
        contentStream.newLineAtOffset(x, yOffset)
        contentStream.showText(text)
        contentStream.endText()
    }

    drawCenteredText("BIHARAMULO COLLEGE OF BUSINESS AND TECHNOLOGY ( BCBT )", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= 25f

    val resourceStream = object {}.javaClass.getResourceAsStream("/logo.png")
    if (resourceStream != null) {
        val tempLogoFile = File.createTempFile("logo", ".png")
        tempLogoFile.deleteOnExit()
        tempLogoFile.outputStream().use { output -> resourceStream.copyTo(output) }
        val pdImage = PDImageXObject.createFromFileByContent(tempLogoFile, document)
        val imgWidth = 70f
        val imgHeight = (pdImage.height.toFloat() / pdImage.width.toFloat()) * imgWidth
        val imgX = (pageWidth - imgWidth) / 2
        val imgY = yPosition - imgHeight
        contentStream.drawImage(pdImage, imgX, imgY, imgWidth, imgHeight)
        yPosition = imgY - 20f
    }

    drawCenteredText("DEPARTMENT OF INFORMATION AND COMMUNICATION TECHNOLOGY", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= lineSpacing
    drawCenteredText("SEMESTER EXAMINATION / SPECIAL & SUPPLEMENTARY EXAMINATION", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= lineSpacing
    drawCenteredText("Module Name: ${module.name}", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= lineSpacing

    val ntaLevel = module.code.filter { it.isDigit() }.drop(1).firstOrNull()?.toString() ?: "-"
    drawCenteredText("Module Code: ${module.code}     NTA Level: $ntaLevel", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= lineSpacing

    val semester = module.code.filter { it.isDigit() }.drop(2).firstOrNull()?.toString() ?: "-"
    drawCenteredText("Year of Study: $academicYear ($selectedIntake Intake)   Semester: $semester", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= 30f

    val colTitles = listOf("S/N", "Full Name", "Assign", "Quiz", "Attend", "Test1", "Test2", "CA", "UE/SE", "Total", "Remarks")
    val colWidths = listOf(30f, 210f, 45f, 40f, 45f, 45f, 45f, 30f, 40f, 40f, 90f)
    val colX = colWidths.runningFold(margin) { acc, w -> acc + w }.dropLast(1)

    val cellHeight = 20f
    val textPaddingTop = 5f

    contentStream.setFont(PDType1Font.TIMES_BOLD, 12f)
    contentStream.setStrokingColor(java.awt.Color.BLACK)
    contentStream.setLineWidth(1f)

    // Header row
    for (i in colTitles.indices) {
        contentStream.addRect(colX[i], yPosition - cellHeight, colWidths[i], cellHeight)
    }
    contentStream.stroke()
    for (i in colTitles.indices) {
        contentStream.beginText()
        contentStream.newLineAtOffset(colX[i] + 2f, yPosition - cellHeight + textPaddingTop)
        contentStream.showText(colTitles[i])
        contentStream.endText()
    }
    yPosition -= cellHeight

    contentStream.setFont(PDType1Font.TIMES_ROMAN, 12f)

    // ✅ Filter: only students with CA > 0
    val validStudents = students.filter { student ->
        val grade = grades.find { it.studentId == student.regNo && it.moduleCode == module.code }
        val ca = grade?.let { g ->
            listOf(
                g.assignmentMark,
                g.quizMark,
                g.attendanceMark,
                g.testOneMark,
                g.testTwoMark
            ).sumOf { mark -> mark.toDoubleOrNull() ?: 0.0 }
        } ?: 0.0
        ca > 0.0
    }

    validStudents.forEachIndexed { index, student ->
        if (yPosition < 100f) newPage()

        val grade = grades.find { it.studentId == student.regNo && it.moduleCode == module.code }

        val assignment = grade?.assignmentMark ?: ""
        val quiz = grade?.quizMark ?: ""
        val attendance = grade?.attendanceMark ?: ""
        val testOne = grade?.testOneMark ?: ""
        val testTwo = grade?.testTwoMark ?: ""
        val ca = grade?.let { g ->
            String.format(
                "%.1f",
                listOf(g.assignmentMark, g.quizMark, g.attendanceMark, g.testOneMark, g.testTwoMark)
                    .sumOf { mark -> mark.toDoubleOrNull() ?: 0.0 }
            )
        } ?: ""

        val exam = grade?.examMark
        val total = String.format(
            "%.1f",
            (ca.toDoubleOrNull() ?: 0.0) + (exam?.toDoubleOrNull() ?: 0.0)
        )

        val levelFour = listOf("Excellent(A)", "Good(B)", "Pass(C)", "Poor(D)", "Failure(F)")
        val levelSix = listOf("Excellent(A)", "Very Good(B+)", "Good(B)", "Average(C)", "Poor(D)", "Failure(F)")

        val caValue = ca.toDoubleOrNull() ?: 0.0
        val examValue = exam?.toDoubleOrNull()
        val totalValue = total.toDoubleOrNull()
        val ntaLevelInt = ntaLevel.trim().toIntOrNull() ?: -1

        val remark = when {
            caValue >= passingScore && exam.isNullOrEmpty() -> "Passed"
            caValue < passingScore && exam.isNullOrEmpty() -> "Repeat"
            caValue >= passingScore && examValue != null && examValue < 20.0 -> "Supplementary"

            (ntaLevelInt == 4 || ntaLevelInt == 5) && examValue != null && totalValue != null -> when {
                totalValue >= 80 -> levelFour[0]
                totalValue >= 65 -> levelFour[1]
                totalValue >= 50 -> levelFour[2]
                totalValue >= 40 -> levelFour[3]
                else -> levelFour[4]
            }

            ntaLevelInt == 6 && examValue != null && totalValue != null -> when {
                totalValue >= 75 -> levelSix[0]
                totalValue >= 65 -> levelSix[1]
                totalValue >= 55 -> levelSix[2]
                totalValue >= 45 -> levelSix[3]
                totalValue >= 35 -> levelSix[4]
                else -> levelSix[5]
            }

            else -> "Pending"
        }

        val values = listOf(
            (index + 1).toString(),
            student.studentName,
            assignment,
            quiz,
            attendance,
            testOne,
            testTwo,
            ca,
            exam,
            total,
            remark
        )

        for (i in values.indices) {
            contentStream.addRect(colX[i], yPosition - cellHeight, colWidths[i], cellHeight)
        }
        contentStream.stroke()

        for (i in values.indices) {
            val fontSize = if (i == 1) {
                val textWidth = PDType1Font.TIMES_ROMAN.getStringWidth(values[i]) / 1000
                val maxWidth = colWidths[i] - 4f
                (maxNameFontSize.coerceAtMost((maxWidth / textWidth))).coerceAtLeast(minNameFontSize)
            } else 12f

            contentStream.beginText()
            contentStream.setFont(PDType1Font.TIMES_ROMAN, fontSize)
            contentStream.newLineAtOffset(colX[i] + 2f, yPosition - cellHeight + textPaddingTop)
            contentStream.showText(values[i])
            contentStream.endText()
        }

        yPosition -= cellHeight
    }

    yPosition -= 20f
    val nameSectionX = 50f
    val signX = 300f
    val nameFont = PDType1Font.TIMES_ROMAN

    val details = listOf(
        "Instructor: $instructor",
        "HOD: $hod",
        "Examination Officer: $examOfficer"
    )

    details.forEach { line ->
        if (yPosition < 100f) newPage()
        contentStream.beginText()
        contentStream.setFont(nameFont, 12f)
        contentStream.newLineAtOffset(nameSectionX, yPosition)
        contentStream.showText(line)
        contentStream.newLineAtOffset(signX - nameSectionX, 0f)
        contentStream.showText("Signature: ............................")
        contentStream.endText()
        yPosition -= 20f
    }

    val today = java.time.LocalDate.now()
    val day = today.dayOfMonth
    val suffix = when {
        day in 11..13 -> "th"
        day % 10 == 1 -> "st"
        day % 10 == 2 -> "nd"
        day % 10 == 3 -> "rd"
        else -> "th"
    }

    val baseFontSize = 12f
    val suffixFontSize = 7f
    val suffixYOffset = 4f

    contentStream.beginText()
    contentStream.setFont(nameFont, baseFontSize)
    contentStream.newLineAtOffset(50f, yPosition)
    contentStream.showText("Date: ")
    contentStream.endText()

    val dateX = 50f + nameFont.getStringWidth("Date: ") / 1000 * baseFontSize
    contentStream.beginText()
    contentStream.setFont(nameFont, baseFontSize)
    contentStream.newLineAtOffset(dateX, yPosition)
    contentStream.showText(day.toString())
    contentStream.endText()

    val suffixX = dateX + nameFont.getStringWidth(day.toString()) / 1000 * baseFontSize
    contentStream.beginText()
    contentStream.setFont(nameFont, suffixFontSize)
    contentStream.newLineAtOffset(suffixX, yPosition + suffixYOffset)
    contentStream.showText(suffix)
    contentStream.endText()

    val monthYearText = " ${today.month.name.lowercase().replaceFirstChar { it.uppercase() }}, ${today.year}"
    val monthYearX = suffixX + nameFont.getStringWidth(suffix) / 1000 * suffixFontSize
    contentStream.beginText()
    contentStream.setFont(nameFont, baseFontSize)
    contentStream.newLineAtOffset(monthYearX, yPosition)
    contentStream.showText(monthYearText)
    contentStream.endText()

    yPosition -= 20f

    val formatter = DateTimeFormatter.ofPattern("dd MMMM,yy HH:mm")
    val timestamp = LocalDateTime.now().format(formatter)
    drawCenteredText("Generated from GradeMate App On $timestamp", nameFont, 8f, 40f)

    pages.forEachIndexed { index, page ->
        val footer = PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true)
        footer.beginText()
        footer.setFont(nameFont, 8f)
        val footerText = "Page ${index + 1} of ${pages.size}"
        val footerWidth = nameFont.getStringWidth(footerText) / 1000 * 8f
        footer.newLineAtOffset((pageWidth - footerWidth) / 2, 20f)
        footer.showText(footerText)
        footer.endText()
        footer.close()
    }

    contentStream.close()

    val outputFile = File("GradeSheet_${module.code}.pdf")
           //sending the email
    sendEmail(
        to = listOf(
            "lennyflorence2000@gmail.com",
            "bcbtictdepartment@gmail.com",
            "thirdperson@example.com"
        ),
        subject = "${module.code}_${module.name}_$selectedIntake Intake_$academicYear",
        body = "Please find the attached grade sheet generated by user ${name.takeIf { it.isNotEmpty() }}",
        attachment = outputFile
    )
    document.save(outputFile)
    document.close()

    try {
        if (Desktop.isDesktopSupported()) {
            Desktop.getDesktop().open(outputFile)
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
