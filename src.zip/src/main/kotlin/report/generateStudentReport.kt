import androidx.compose.runtime.snapshots.SnapshotStateList
import org.apache.pdfbox.pdmodel.PDDocument
import org.apache.pdfbox.pdmodel.PDPage
import org.apache.pdfbox.pdmodel.PDPageContentStream
import org.apache.pdfbox.pdmodel.common.PDRectangle
import org.apache.pdfbox.pdmodel.font.PDFont
import org.apache.pdfbox.pdmodel.font.PDType1Font
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject
import java.awt.Desktop
import java.io.File
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

fun generateStudentReport(student: Student, grades: List<Grade>, modules: SnapshotStateList<Module>) {
    val maxNameFontSize = 12f
    val minNameFontSize = 8f
    val margin = 50f
    val lineSpacing = 18f
    val cellHeight = 20f
    val textPaddingTop = 5f
    val nameFont = PDType1Font.TIMES_ROMAN
    val baseFontSize = 12f
    val suffixFontSize = 7f
    val suffixYOffset = 4f

    val document = PDDocument()
    val pageSize = PDRectangle(PDRectangle.LETTER.height, PDRectangle.LETTER.width) // Landscape
    val pageWidth = pageSize.width
    val pageHeight = pageSize.height

    val pages = mutableListOf<PDPage>()
    var currentPage = PDPage(pageSize)
    document.addPage(currentPage)
    pages.add(currentPage)
    var contentStream = PDPageContentStream(document, currentPage)
    var yPosition = pageHeight - margin

    fun newPage() {
        contentStream.close()
        currentPage = PDPage(pageSize)
        document.addPage(currentPage)
        pages.add(currentPage)
        contentStream = PDPageContentStream(document, currentPage)
        yPosition = pageHeight - margin
    }

    // Automatic page break
    fun ensureSpace(requiredHeight: Float) {
        if (yPosition - requiredHeight < margin + 50f) {
            newPage()
        }
    }

    fun drawCenteredText(text: String, font: PDFont, fontSize: Float, yOffset: Float) {
        val textWidth = font.getStringWidth(text) / 1000 * fontSize
        val x = (pageWidth - textWidth) / 2
        contentStream.beginText()
        contentStream.setFont(font, fontSize)
        contentStream.newLineAtOffset(x, yOffset)
        contentStream.showText(text)
        contentStream.endText()
    }

    fun drawTableHeader() {
        val colTitles = listOf("Module Code", "Module Name", "Credit", "Grade", "Points", "GPA")
        val colWidths = listOf(80f, 350f, 45f, 45f, 90f, 60f)
        val colX = colWidths.runningFold(margin) { acc, w -> acc + w }.dropLast(1)

        contentStream.setFont(PDType1Font.TIMES_BOLD, 12f)
        contentStream.setStrokingColor(java.awt.Color.BLACK)
        contentStream.setLineWidth(1f)
        for (i in colTitles.indices) contentStream.addRect(colX[i], yPosition - cellHeight, colWidths[i], cellHeight)
        contentStream.stroke()
        for (i in colTitles.indices) {
            contentStream.beginText()
            contentStream.newLineAtOffset(colX[i] + 2f, yPosition - cellHeight + textPaddingTop)
            contentStream.showText(colTitles[i])
            contentStream.endText()
        }
        yPosition -= cellHeight
        contentStream.setFont(PDType1Font.TIMES_ROMAN, 12f)
    }

    fun calculateGrade(grade: Grade?, ntaLevel: Int?): Triple<String, Double, Double>? {
        if (grade == null) return null
        val caMark = grade.caMark
        val examMark = grade.examMark.toDoubleOrNull() ?: 0.0
        val totalMark = grade.total
        val gradeText = when {
            caMark < 30 -> return null
            examMark < 20 -> "TS"
            ntaLevel != 6 -> when {
                totalMark >= 80 -> "A"
                totalMark >= 65 -> "B"
                totalMark >= 50 -> "C"
                totalMark >= 40 -> "D"
                else -> "F"
            }
            else -> when {
                totalMark >= 75 -> "A"
                totalMark >= 65 -> "B+"
                totalMark >= 55 -> "B"
                totalMark >= 45 -> "C"
                totalMark >= 35 -> "D"
                else -> "F"
            }
        }
        return Triple(gradeText, totalMark, examMark)
    }

    fun drawRow(module: Module, gradeTriple: Triple<String, Double, Double>) {
        ensureSpace(cellHeight + 40f)
        val colWidths = listOf(80f, 350f, 45f, 45f, 90f, 60f)
        val colX = colWidths.runningFold(margin) { acc, w -> acc + w }.dropLast(1)
        val (gradeText, totalMark, ueMark) = gradeTriple
        val credit = module.credit.trim().toDoubleOrNull() ?: 0.0
        val point = getPoint(module.level.trim().toInt(), totalMark, ueMark)
        val values = listOf(
            module.code,
            module.name,
            module.credit,
            gradeText,
            (credit * point).toBigDecimal().setScale(1, RoundingMode.HALF_UP).toString(),
            ""
        )
        for (i in values.indices) contentStream.addRect(colX[i], yPosition - cellHeight, colWidths[i], cellHeight)
        contentStream.stroke()

        for (i in values.indices) {
            val fontSize = if (i == 1) {
                val textWidth = PDType1Font.TIMES_ROMAN.getStringWidth(values[i]) / 1000
                val maxWidth = colWidths[i] - 4f
                (maxNameFontSize.coerceAtMost((maxWidth / textWidth))).coerceAtLeast(minNameFontSize)
            } else 12f
            val xOffset = colX[i] + 2f
            contentStream.beginText()
            contentStream.setFont(PDType1Font.TIMES_ROMAN, fontSize)
            contentStream.newLineAtOffset(xOffset, yPosition - cellHeight + textPaddingTop)
            contentStream.showText(values[i])
            contentStream.endText()
        }
        yPosition -= cellHeight
    }

    fun drawTableFooter(levelTotalCredit: Double, levelTotalPoints: Double) {
        ensureSpace(cellHeight + 40f)
        val colWidths = listOf(80f, 350f, 45f, 45f, 90f, 60f)
        val colX = colWidths.runningFold(margin) { acc, w -> acc + w }.dropLast(1)
        val gpa = if (levelTotalCredit != 0.0) BigDecimal(levelTotalPoints / levelTotalCredit).setScale(1, RoundingMode.HALF_UP) else BigDecimal.ZERO
        val colFooters = listOf(
            "",
            "SUB TOTAL",
            BigDecimal(levelTotalCredit).setScale(1, RoundingMode.HALF_UP).toString(),
            "",
            BigDecimal(levelTotalPoints).setScale(1, RoundingMode.HALF_UP).toString(),
            gpa.toString()
        )
        contentStream.setFont(PDType1Font.TIMES_BOLD, 12f)
        contentStream.setStrokingColor(java.awt.Color.BLACK)
        contentStream.setLineWidth(1f)
        for (i in colFooters.indices) contentStream.addRect(colX[i], yPosition - cellHeight, colWidths[i], cellHeight)
        contentStream.stroke()

        for (i in colFooters.indices) {
            val fontSize = 12f
            val xOffset = if (i == 1) {
                val textWidth = PDType1Font.TIMES_BOLD.getStringWidth(colFooters[i]) / 1000 * fontSize
                colX[i] + colWidths[i] - textWidth - 2f
            } else colX[i] + 2f
            contentStream.beginText()
            contentStream.setFont(PDType1Font.TIMES_BOLD, fontSize)
            contentStream.newLineAtOffset(xOffset, yPosition - cellHeight + textPaddingTop)
            contentStream.showText(colFooters[i])
            contentStream.endText()
        }
        yPosition -= cellHeight
        contentStream.setFont(PDType1Font.TIMES_ROMAN, 12f)
    }

    fun drawHeader() {
        drawCenteredText("BIHARAMULO COLLEGE OF BUSINESS AND TECHNOLOGY ( BCBT )", PDType1Font.TIMES_BOLD, 12f, yPosition)
        yPosition -= 25f
        val resourceStream = object {}.javaClass.getResourceAsStream("/logo.png")
        if (resourceStream != null) {
            val tempLogoFile = File.createTempFile("logo", ".png")
            tempLogoFile.deleteOnExit()
            tempLogoFile.outputStream().use { output -> resourceStream.copyTo(output) }
            val pdImage = PDImageXObject.createFromFileByContent(tempLogoFile, document)
            val imgWidth = 70f
            val imgHeight = (pdImage.height.toFloat() / pdImage.width.toFloat()) * imgWidth
            val imgX = (pageWidth - imgWidth) / 2
            val imgY = yPosition - imgHeight
            contentStream.drawImage(pdImage, imgX, imgY, imgWidth, imgHeight)
            yPosition = imgY - 20f
        }
        drawCenteredText("DEPARTMENT OF ${student.program}", PDType1Font.TIMES_BOLD, 12f, yPosition)
        yPosition -= lineSpacing + 30f
    }

    drawHeader()

    val levels = listOf(4, 5, 6)
    for (level in levels) {
        ensureSpace(200f)
        val levelModules = modules.filter { it.level.trim().toIntOrNull() == level }
        val gradedModules = levelModules.filter { module ->
            grades.any { it.moduleCode == module.code && it.studentId == student.regNo }
        }
        if (gradedModules.isEmpty()) continue

        val programText = when (level) {
            4 -> "Certificate Level"
            5 -> "Diploma Level I"
            6 -> "Diploma Level II"
            else -> "Progress Report"
        }

        contentStream.setFont(PDType1Font.TIMES_BOLD, 14f)
        contentStream.beginText()
        contentStream.newLineAtOffset(margin, yPosition)
        contentStream.showText(programText)
        contentStream.endText()
        yPosition -= 10f

        drawTableHeader()

        var levelTotalCredit = 0.0
        var levelTotalPoints = 0.0

        for (module in gradedModules.distinctBy { it.code }) {
            val grade = grades.find { it.moduleCode == module.code && it.studentId == student.regNo }
            val gradeTriple = calculateGrade(grade, grade?.ntaLevel?.toIntOrNull())
            if (gradeTriple != null) {
                val (gradeText, totalMark, ueMark) = gradeTriple
                val credit = module.credit.trim().toDoubleOrNull() ?: 0.0
                val point = getPoint(module.level.trim().toInt(), totalMark, ueMark)
                levelTotalCredit += credit
                levelTotalPoints += credit * point
                drawRow(module, gradeTriple)
            }
        }
        if (levelTotalCredit > 0.0) drawTableFooter(levelTotalCredit, levelTotalPoints)
        yPosition -= 30f
    }

    ensureSpace(250f)
    yPosition -= 20f

// Bold title
    contentStream.setFont(PDType1Font.TIMES_BOLD, 14f)
    contentStream.beginText()
    contentStream.newLineAtOffset(margin, yPosition)
    contentStream.showText("KEY TO GRADES AND CLASSIFICATION")
    contentStream.endText()

    yPosition -= 20f

// Normal text
    contentStream.setFont(PDType1Font.TIMES_ROMAN, 12f)

    contentStream.beginText()
    contentStream.newLineAtOffset(margin, yPosition)
    contentStream.showText("1. This record is not official unless it bears the original signature and the College seal.")
    contentStream.endText()

    yPosition -= 20f

    contentStream.beginText()
    contentStream.newLineAtOffset(margin, yPosition)
    contentStream.showText("2. Key to grades.")
    contentStream.endText()

    yPosition -= 30f


    fun drawGradesSection(title: String, tables: List<List<String>>) {
        val requiredHeight = (tables.size + 1) * cellHeight + 20f
        ensureSpace(requiredHeight)

        // 🔹 Make the section title bold
        contentStream.setFont(PDType1Font.TIMES_BOLD, 14f)
        contentStream.beginText()
        contentStream.newLineAtOffset(margin, yPosition)
        contentStream.showText(title)
        contentStream.endText()
        yPosition -= 15f

        // 🔹 Normal font for table content
        contentStream.setFont(PDType1Font.TIMES_ROMAN, 12f)

        for (table in tables) {
            ensureSpace(cellHeight + 10f)
            val colWidths = List(table.size) { 100f }
            val colX = colWidths.runningFold(margin) { acc, w -> acc + w }.dropLast(1)

            // Draw table grid
            for (i in table.indices) {
                contentStream.addRect(colX[i], yPosition - cellHeight, colWidths[i], cellHeight)
            }
            contentStream.stroke()

            // Write cell text
            for (i in table.indices) {
                contentStream.beginText()
                contentStream.newLineAtOffset(colX[i] + 2f, yPosition - cellHeight + textPaddingTop)
                contentStream.showText(table[i])
                contentStream.endText()
            }

            yPosition -= cellHeight
        }

        yPosition -= 20f
    }

    drawGradesSection(
        "Certificate Level",
        listOf(
            listOf("Mark", "80-100", "65-79", "50-64", "40-49", "0-39"),
            listOf("Grade", "A", "B", "C", "D", "F"),
            listOf("Points", "4", "3", "2", "1", "0"),
            listOf("Remarks", "Excellent", "Good", "Pass", "Poor", "Failure")
        )
    )

    drawGradesSection(
        "Diploma Level",
        listOf(
            listOf("Mark", "75-100", "65-74", "55-64", "45-54", "35-44", "0-34"),
            listOf("Grade", "A", "B+", "B", "C", "D", "F"),
            listOf("Points", "5", "4", "3", "2", "1", "0"),
            listOf("Remarks", "Excellent", "Very Good", "Good", "Pass", "Poor", "Failure")
        )
    )
    contentStream.beginText()
    contentStream.newLineAtOffset(margin, yPosition)
    contentStream.showText("3.Classification and Rating of Diploma and Certificates Awards.")
    contentStream.endText()
    yPosition -= 30f
    fun drawAwardsSection(title: String, tables: List<List<String>>) {
        val requiredHeight = (tables.size + 1) * cellHeight + 20f
        ensureSpace(requiredHeight)

        // Title
        contentStream.setFont(PDType1Font.TIMES_BOLD, 13f)
        contentStream.beginText()
        contentStream.newLineAtOffset(margin, yPosition)
        contentStream.showText(title)
        contentStream.endText()
        yPosition -= 20f

        for ((rowIndex, table) in tables.withIndex()) {
            ensureSpace(cellHeight + 10f)

            // Set up column widths (4 columns total)
            val colWidths = listOf(100f, 100f, 100f, 100f)
            val colX = colWidths.runningFold(margin) { acc, w -> acc + w }.dropLast(1)

            // Draw rectangles (skip for merged cells)
            if (rowIndex == 0) {
                // First row: Diploma spans 2 columns, Certificate spans 2 columns
                contentStream.addRect(colX[0], yPosition - cellHeight, colWidths[0] + colWidths[1], cellHeight)
                contentStream.addRect(colX[2], yPosition - cellHeight, colWidths[2] + colWidths[3], cellHeight)
            } else {
                // Normal rows
                for (i in 0 until 4) {
                    contentStream.addRect(colX[i], yPosition - cellHeight, colWidths[i], cellHeight)
                }
            }
            contentStream.stroke()

            // Draw text
            contentStream.setFont(PDType1Font.TIMES_ROMAN, 12f)
            when (rowIndex) {
                0 -> { // First row: merge text in wider cells
                    contentStream.beginText()
                    contentStream.newLineAtOffset(colX[0] + 50f, yPosition - cellHeight + textPaddingTop)
                    contentStream.showText(table[0]) // Diploma
                    contentStream.endText()

                    contentStream.beginText()
                    contentStream.newLineAtOffset(colX[2] + 50f, yPosition - cellHeight + textPaddingTop)
                    contentStream.showText(table[1]) // Certificate
                    contentStream.endText()
                }

                else -> { // Normal rows
                    for (i in table.indices) {
                        if (table[i].isNotBlank()) {
                            contentStream.beginText()
                            contentStream.newLineAtOffset(colX[i] + 2f, yPosition - cellHeight + textPaddingTop)
                            contentStream.showText(table[i])
                            contentStream.endText()
                        }
                    }
                }
            }

            yPosition -= cellHeight
        }

        yPosition -= 20f
    }

    drawAwardsSection(
        "Classification of Awards",
        listOf(
            listOf("Diploma", "Certificate"),
            listOf("Overall GPA", "Class", "Overall GPA", "Class"),
            listOf("4.4 - 5.0", "First", "3.5 - 4.0", "First"),
            listOf("3.5 - 4.3", "Upper Second", "3.0 - 3.4", "Second"),
            listOf("2.7 - 3.4", "Lower Second", "2.0 - 2.9", "Pass"),
            listOf("2.0 - 2.6", "Pass", "", ""),
        )
    )
    val formatter = DateTimeFormatter.ofPattern("dd MMMM,yy HH:mm")
    val timestamp = LocalDateTime.now().format(formatter)
    drawCenteredText("Generated from GradeMate App On $timestamp", nameFont, 8f, 40f)

    pages.forEachIndexed { index, page ->
        val footer = PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true)
        footer.beginText()
        footer.setFont(nameFont, 8f)
        val footerText = "Page ${index + 1} of ${pages.size}"
        val footerWidth = nameFont.getStringWidth(footerText) / 1000 * 8f
        footer.newLineAtOffset((pageWidth - footerWidth) / 2, 20f)
        footer.showText(footerText)
        footer.endText()
        footer.close()
    }

    contentStream.close()

    val safeRegNo = student.regNo.replace(Regex("[\\\\/:*?\"<>|]"), "_")
    val safeName = student.studentName.replace(Regex("[\\\\/:*?\"<>|]"), "_")
    val outputFile = File("Progress_Report_${safeName}_${safeRegNo}.pdf")

    document.save(outputFile)
    document.close()

    try {
        if (Desktop.isDesktopSupported()) Desktop.getDesktop().open(outputFile)
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
