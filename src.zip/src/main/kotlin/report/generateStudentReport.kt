package report

import Student
import org.apache.pdfbox.pdmodel.PDDocument
import org.apache.pdfbox.pdmodel.PDPage
import org.apache.pdfbox.pdmodel.PDPageContentStream
import org.apache.pdfbox.pdmodel.common.PDRectangle
import org.apache.pdfbox.pdmodel.font.PDFont
import org.apache.pdfbox.pdmodel.font.PDType1Font
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject
import java.awt.Desktop
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

fun generateStudentReport(student:Student){
    val maxNameFontSize = 12f
    val minNameFontSize = 8f

    val document = PDDocument()
    val pageSize = PDRectangle(PDRectangle.LETTER.height, PDRectangle.LETTER.width) // Landscape
    val pageWidth = pageSize.width
    val pageHeight = pageSize.height

    val pages = mutableListOf<PDPage>()
    var currentPage = PDPage(pageSize)
    document.addPage(currentPage)
    pages.add(currentPage)
    var contentStream = PDPageContentStream(document, currentPage)
    val margin = 50f
    var yPosition = pageHeight - margin
    val lineSpacing = 18f
    fun newPage() {
        contentStream.close()
        currentPage = PDPage(pageSize)
        document.addPage(currentPage)
        pages.add(currentPage)
        contentStream = PDPageContentStream(document, currentPage)
        yPosition = pageHeight - margin
    }
    fun drawCenteredText(text: String, font: PDFont, fontSize: Float, yOffset: Float) {
        val textWidth = font.getStringWidth(text) / 1000 * fontSize
        val x = (pageWidth - textWidth) / 2
        contentStream.beginText()
        contentStream.setFont(font, fontSize)
        contentStream.newLineAtOffset(x, yOffset)
        contentStream.showText(text)
        contentStream.endText()
    }
    drawCenteredText("BIHARAMULO COLLEGE OF BUSINESS AND TECHNOLOGY ( BCBT )", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= 25f
    val resourceStream = object {}.javaClass.getResourceAsStream("/logo.png")
    if (resourceStream != null) {
        val tempLogoFile = File.createTempFile("logo", ".png")
        tempLogoFile.deleteOnExit()
        tempLogoFile.outputStream().use { output -> resourceStream.copyTo(output) }
        val pdImage = PDImageXObject.createFromFileByContent(tempLogoFile, document)
        val imgWidth = 70f
        val imgHeight = (pdImage.height.toFloat() / pdImage.width.toFloat()) * imgWidth
        val imgX = (pageWidth - imgWidth) / 2
        val imgY = yPosition - imgHeight
        contentStream.drawImage(pdImage, imgX, imgY, imgWidth, imgHeight)
        yPosition = imgY - 20f
    }
    drawCenteredText("DEPARTMENT OF ${student.program}", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= lineSpacing
//SETTING THE YEAR (FIRST,SECOND,THIRD) APPEARANCE TABLE
    val colTitles = listOf("Module Code", "Module Name", "Credit", "Grade", "Points", "GPA")
    val colWidths = listOf(30f, 210f, 45f, 40f, 45f, 45f, 45f, 30f, 40f, 40f, 90f)
    val colX = colWidths.runningFold(margin) { acc, w -> acc + w }.dropLast(1)

    val cellHeight = 20f
    val textPaddingTop = 5f

    contentStream.setFont(PDType1Font.TIMES_BOLD, 12f)
    contentStream.setStrokingColor(java.awt.Color.BLACK)
    contentStream.setLineWidth(1f)

    // Header row
    for (i in colTitles.indices) {
        contentStream.addRect(colX[i], yPosition - cellHeight, colWidths[i], cellHeight)
    }
    contentStream.stroke()
    for (i in colTitles.indices) {
        contentStream.beginText()
        contentStream.newLineAtOffset(colX[i] + 2f, yPosition - cellHeight + textPaddingTop)
        contentStream.showText(colTitles[i])
        contentStream.endText()
    }
    yPosition -= cellHeight

    contentStream.setFont(PDType1Font.TIMES_ROMAN, 12f)
    //bottom info
    val today = java.time.LocalDate.now()
    val day = today.dayOfMonth
    val suffix = when {
        day in 11..13 -> "th"
        day % 10 == 1 -> "st"
        day % 10 == 2 -> "nd"
        day % 10 == 3 -> "rd"
        else -> "th"
    }

    val baseFontSize = 12f
    val suffixFontSize = 7f
    val suffixYOffset = 4f
    val nameFont = PDType1Font.TIMES_ROMAN
    contentStream.beginText()
    contentStream.setFont(nameFont, baseFontSize)
    contentStream.newLineAtOffset(50f, yPosition)
    contentStream.showText("Date: ")
    contentStream.endText()

    val dateX = 50f + nameFont.getStringWidth("Date: ") / 1000 * baseFontSize
    contentStream.beginText()
    contentStream.setFont(nameFont, baseFontSize)
    contentStream.newLineAtOffset(dateX, yPosition)
    contentStream.showText(day.toString())
    contentStream.endText()

    val suffixX = dateX + nameFont.getStringWidth(day.toString()) / 1000 * baseFontSize
    contentStream.beginText()
    contentStream.setFont(nameFont, suffixFontSize)
    contentStream.newLineAtOffset(suffixX, yPosition + suffixYOffset)
    contentStream.showText(suffix)
    contentStream.endText()

    val monthYearText = " ${today.month.name.lowercase().replaceFirstChar { it.uppercase() }}, ${today.year}"
    val monthYearX = suffixX + nameFont.getStringWidth(suffix) / 1000 * suffixFontSize
    contentStream.beginText()
    contentStream.setFont(nameFont, baseFontSize)
    contentStream.newLineAtOffset(monthYearX, yPosition)
    contentStream.showText(monthYearText)
    contentStream.endText()

    yPosition -= 20f

    val formatter = DateTimeFormatter.ofPattern("dd MMMM,yy HH:mm")
    val timestamp = LocalDateTime.now().format(formatter)
    drawCenteredText("Generated from GradeMate App On $timestamp", nameFont, 8f, 40f)

    pages.forEachIndexed { index, page ->
        val footer = PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true)
        footer.beginText()
        footer.setFont(nameFont, 8f)
        val footerText = "Page ${index + 1} of ${pages.size}"
        val footerWidth = nameFont.getStringWidth(footerText) / 1000 * 8f
        footer.newLineAtOffset((pageWidth - footerWidth) / 2, 20f)
        footer.showText(footerText)
        footer.endText()
        footer.close()
    }

    contentStream.close()

    val safeRegNo = student.regNo.replace(Regex("[\\\\/:*?\"<>|]"), "_")
    val safeName = student.studentName.replace(Regex("[\\\\/:*?\"<>|]"), "_")

    val outputFile = File("Progress_Report_${safeName}_${safeRegNo}.pdf")


    document.save(outputFile)
    document.close()

    try {
        if (Desktop.isDesktopSupported()) {
            Desktop.getDesktop().open(outputFile)
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
}
