import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.launch

@Composable
fun RecordAbsence(
    showDialog: Boolean,
    onDismiss: () -> Unit,
    onConfirm: suspend (List<Student>, String) -> Unit
) {
    if (!showDialog) return

    val coroutineScope = rememberCoroutineScope()
    val studentList = remember { mutableStateListOf<Student>() }
    val moduleList = remember { mutableStateListOf<Module>() }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        isLoading = true
        studentList.clear()
        studentList.addAll(fetchStudentsFromFirestore())
        moduleList.clear()
        moduleList.addAll(fetchModulesFromFirestore())
        isLoading = false
    }

    var searchQuery by remember { mutableStateOf("") }
    var selectedStudents by remember { mutableStateOf(setOf<String>()) } // regNo keys now
    var selectedSubject by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colors.background,
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .wrapContentHeight()
                .padding(24.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    "Record Student Absence",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.h6,
                    modifier = Modifier.padding(bottom = 20.dp)
                )

                if (isLoading) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator()
                    }
                } else {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Search by Name or Registration No") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    val filteredStudents = studentList.filter {
                        it.studentName.contains(searchQuery, ignoreCase = true) ||
                                it.regNo.contains(searchQuery, ignoreCase = true)
                    }.sortedBy { it.studentName }

                    if (filteredStudents.isEmpty()) {
                        Text(
                            "No students match your search.",
                            style = MaterialTheme.typography.body2,
                            modifier = Modifier.padding(vertical = 16.dp)
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .heightIn(max = 200.dp)
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            items(filteredStudents, key = { it.regNo }) { student ->
                                val selected = selectedStudents.contains(student.regNo)
                                Card(
                                    elevation = if (selected) 4.dp else 1.dp,
                                    backgroundColor = if (selected) MaterialTheme.colors.primary.copy(alpha = 0.1f) else MaterialTheme.colors.surface,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .clickable {
                                            selectedStudents = if (selected) selectedStudents - student.regNo else selectedStudents + student.regNo
                                        }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(12.dp)
                                    ) {
                                        Icon(
                                            painter = painterResource("person.png"),
                                            contentDescription = "Student Icon",
                                            tint = MaterialTheme.colors.primary,
                                            modifier = Modifier.size(30.dp)
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = student.studentName,
                                                style = MaterialTheme.typography.subtitle1.copy(fontWeight = FontWeight.SemiBold),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = student.regNo,
                                                style = MaterialTheme.typography.body2.copy(color = MaterialTheme.colors.onSurface.copy(alpha = 0.6f)),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (selectedStudents.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("Select Subject", style = MaterialTheme.typography.subtitle1)

                        val moduleNames = moduleList.map { "${it.code} ${it.name}" }

                        DropdownSelector(
                            label = "Subject",
                            options = moduleNames,
                            selectedOption = selectedSubject,
                            onOptionSelected = { selectedSubject = it }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    TextButton(
                        onClick = {
                            coroutineScope.launch {
                                val selectedList = studentList.filter { selectedStudents.contains(it.regNo) }
                                onConfirm(selectedList, selectedSubject)
                                onDismiss()  // dismiss only after confirm finishes
                            }
                        },
                        enabled = selectedStudents.isNotEmpty() && selectedSubject.isNotBlank()
                    ) {
                        Text("Confirm")
                    }
                }
            }
        }
    }
}


@Composable
fun DropdownSelector(
    label: String,
    options: List<String>,
    selectedOption: String,
    onOptionSelected: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        OutlinedTextField(
            value = selectedOption,
            onValueChange = {},
            label = { Text(label) },
            modifier = Modifier.fillMaxWidth(),
            readOnly = true,
            singleLine = true,
            trailingIcon = {
                IconButton(onClick = { expanded = !expanded }) {
                    Icon(
                        painter =  painterResource("down.png"),
                        contentDescription = null
                    )
                }
            }
        )
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.fillMaxWidth()
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    onClick = {
                        onOptionSelected(option)
                        expanded = false
                    }
                ) {
                    Text(option)
                }
            }
        }
    }
}
