import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import components.Constants.academicYear
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
fun RecordAbsence(
    showDialog: Boolean,
    onDismiss: () -> Unit,
    onConfirm: suspend (List<Student>, String, String) -> Unit
) {
    if (!showDialog) return

    val scope = rememberCoroutineScope()
    val students = remember { mutableStateListOf<Student>() }
    val modules = remember { mutableStateListOf<Module>() }

    var isLoading by remember { mutableStateOf(true) }
    var isSaving by remember { mutableStateOf(false) } // 👈 New state for confirm progress

    LaunchedEffect(Unit) {
        isLoading = true
        students.clear()
        students.addAll(fetchStudentsFromFirestore())
        modules.clear()
        modules.addAll(fetchModulesFromFirestore())
        isLoading = false
    }

    var searchQuery by remember { mutableStateOf("") }
    var selectedStudents by remember { mutableStateOf(setOf<String>()) }
    var selectedModule by remember { mutableStateOf("") }

    val currentYear = LocalDate.now().year
    val targetYear = "${currentYear - 1}/$currentYear"
    val targetIndex = academicYear.indexOf(targetYear).takeIf { it >= 0 } ?: 0
    var selectedYear by remember { mutableStateOf(academicYear[targetIndex]) }

    Dialog(onDismissRequest = {
        if (!isSaving) onDismiss() // prevent closing while saving
    }) {
        Card(
            shape = MaterialTheme.shapes.large,
            elevation = 8.dp,
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .wrapContentHeight()
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    "Record Student Absence",
                    style = MaterialTheme.typography.h5.copy(fontWeight = FontWeight.Bold),
                    color = GradeMateColors.Primary
                )

                Spacer(Modifier.height(16.dp))

                when {
                    isLoading -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            CircularProgressIndicator()
                        }
                    }

                    isSaving -> { // 👈 show saving progress
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(180.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator()
                                Spacer(Modifier.height(12.dp))
                                Text("Saving attendance records...", style = MaterialTheme.typography.subtitle1)
                            }
                        }
                    }

                    else -> {
                        // Search bar
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            label = { Text("Search students") },
                            leadingIcon = {
                                Icon(
                                    painterResource("search.png"),
                                    modifier = Modifier.size(22.dp),
                                    contentDescription = "Search"
                                )
                            },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(Modifier.height(12.dp))

                        val filteredStudents = students.filter {
                            it.studentName.contains(searchQuery, ignoreCase = true) ||
                                    it.regNo.contains(searchQuery, ignoreCase = true)
                        }.sortedBy { it.studentName }

                        if (filteredStudents.isEmpty()) {
                            Text(
                                "No matching students found.",
                                style = MaterialTheme.typography.subtitle1,
                                modifier = Modifier.padding(vertical = 16.dp)
                            )
                        } else {
                            LazyColumn(
                                modifier = Modifier
                                    .heightIn(max = 250.dp)
                                    .fillMaxWidth()
                            ) {
                                items(filteredStudents, key = { it.regNo }) { student ->
                                    val selected = selectedStudents.contains(student.regNo)
                                    Card(
                                        shape = MaterialTheme.shapes.medium,
                                        elevation = if (selected) 6.dp else 1.dp,
                                        backgroundColor =
                                            if (selected)
                                                GradeMateColors.Primary.copy(alpha = 0.15f)
                                            else MaterialTheme.colors.surface,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                            .clickable {
                                                selectedStudents = if (selected)
                                                    selectedStudents - student.regNo
                                                else
                                                    selectedStudents + student.regNo
                                            }
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(12.dp)
                                        ) {
                                            Icon(
                                                painterResource("person.png"),
                                                contentDescription = null,
                                                tint = GradeMateColors.Primary,
                                                modifier = Modifier.size(32.dp)
                                            )
                                            Spacer(Modifier.width(12.dp))
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = student.studentName,
                                                    style = MaterialTheme.typography.body1.copy(fontWeight = FontWeight.SemiBold),
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                Text(
                                                    text = student.regNo,
                                                    style = MaterialTheme.typography.body2.copy(color = MaterialTheme.colors.secondaryVariant),
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            if (selectedStudents.isNotEmpty()) {
                                Spacer(Modifier.height(16.dp))
                                Text("Select Subject", style = MaterialTheme.typography.subtitle2)
                                val moduleOptions = modules.map { "${it.code} ${it.name}" }
                                ModernDropdown(
                                    label = "Subject",
                                    options = moduleOptions,
                                    selected = selectedModule,
                                    onSelect = { selectedModule = it }
                                )

                                Spacer(Modifier.height(12.dp))
                                Text("Academic Year", style = MaterialTheme.typography.body1)
                                ModernDropdown(
                                    label = "Academic Year",
                                    options = academicYear,
                                    selected = selectedYear,
                                    onSelect = { selectedYear = it }
                                )
                            }
                        }

                        Spacer(Modifier.height(20.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = onDismiss) { Text("Cancel") }
                            Spacer(Modifier.width(16.dp))
                            Button(
                                onClick = {
                                    scope.launch {
                                        isSaving = true
                                        val selectedList = students.filter { selectedStudents.contains(it.regNo) }
                                        onConfirm(selectedList, selectedModule, selectedYear)
                                        isSaving = false
                                        onDismiss()
                                    }
                                },
                                enabled = selectedStudents.isNotEmpty() && selectedModule.isNotBlank()
                            ) {
                                Text("Confirm")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ModernDropdown(
    label: String,
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            label = { Text(label) },
            readOnly = true,
            trailingIcon = {
                IconButton(onClick = { expanded = !expanded }) {
                    Icon(
                        painterResource("down.png"),
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                        tint = GradeMateColors.Primary
                    )
                }
            },
            modifier = Modifier.fillMaxWidth()
        )

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier.fillMaxWidth()
        ) {
            options.forEach { option ->
                DropdownMenuItem(
                    onClick = {
                        onSelect(option)
                        expanded = false
                    }
                ) {
                    Text(option)
                }
            }
        }
    }
}
