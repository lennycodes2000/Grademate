import androidx.compose.ui.graphics.Color

object GradeMateColors {
    val Primary = Color(0xFF1976D2)    // Blue 500
    val Secondary = Color(0xFF66BB6A)  // Green 400
    val Background = Color(0xFFF5F5F5) // Gray 100
    val Surface = Color(0xFFFFFFFF)    // White
    val TextPrimary = Color(0xFF212121) // Gray 900
    val Accent = Color(0xFFFFCA28)     // Amber 400
    val Error = Color(0xFFE53935)      // Red 600
}
