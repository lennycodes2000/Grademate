import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import components.Constants
import components.InfoCard
import dialog.AddTutorDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*


@Composable
 fun MainScreen(
    students: SnapshotStateList<Student>,
    modules: SnapshotStateList<Module>,
    tutors:SnapshotStateList<Tutor>,
    publish:SnapshotStateList<Publish>,
    onGoToGrading: () -> Unit,
    goToManage:()-> Unit,
    signout:()->Unit
) {
    var showAddStudentDialog by remember { mutableStateOf(false) }
    var showAddTutorDialog by remember { mutableStateOf(false) }
    var showAddModuleDialog by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var status by remember { mutableStateOf(true) }
    var showDialog by remember { mutableStateOf(false) }
    var logoutClicked by remember { mutableStateOf(false) }
    if (showDialog) {
        TimedDialog(status) {
            showDialog = false
        }
    }
    if(logoutClicked){
   AlertDialog(onDismissRequest = {
       logoutClicked = false
   },
       title = { Text(text = "Confirm Logout", color = GradeMateColors.Primary, fontWeight = FontWeight.Bold) },
       text = {
           Text("Are you sure you want to logout?")
       },
       confirmButton = {
           Button(
               colors = androidx.compose.material.ButtonDefaults.buttonColors(
               contentColor = GradeMateColors.Background,
               backgroundColor = GradeMateColors.Primary
           ),
               onClick = signout
           ){
               Text("Yes")
           }
       },
       dismissButton = {
           Button(colors = androidx.compose.material.ButtonDefaults.buttonColors(
               contentColor = GradeMateColors.Primary,
               backgroundColor = GradeMateColors.Background
           ),
               onClick = {
               logoutClicked = false
           }){
               Text("No")
           }
       }
       )
    }

    LaunchedEffect(Unit) {
        //fetch modules
        val fetchedModules = fetchModulesFromFirestore().filter { module ->
            Global.role.value == "Admin" || module.courses.contains(Global.department.value)
        }
        modules.clear()
        modules.addAll(fetchedModules)
        //fetch students
        val fetchedStudents = fetchStudentsFromFirestore()
            .filter { student ->
                student.status != Constants.statuList[3] &&
                        (Global.role.value == "Admin" || student.program.contains(Global.department.value) )
            }
        students.clear()
        students.addAll(fetchedStudents)
        //fetch tutors
        val fetchedTutors = fetchTutorsFromFirestore().filter { tutor ->
            Global.role.value == "Admin" || tutor.dept == Global.department.value
        }
        tutors.clear()
        tutors.addAll(fetchedTutors)
        //setting the name
        name = getTutorNameByEmail(Global.currentEmail.value).toString()
        // Take the first word
     name = name.trim().split("\\s+".toRegex()).firstOrNull().orEmpty()

// Format: first letter uppercase, rest lowercase
        name = name.lowercase().replaceFirstChar { it.titlecase() }
        //load the publish
        publish.clear()
        val fetchedPublish = fetchPublishFromFirestore()
        publish.addAll(fetchedPublish)
    }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF81d4fa), Color(0xFFe1f5fe))
                )
            )
            .padding(horizontal = 40.dp, vertical = 24.dp)
    ) {
      Row (
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
      ){
          if(name.isNotEmpty()){
              Text(
                  "Welcome Back, $name" ,
                  fontSize = 20.sp,
                  fontWeight = FontWeight.ExtraBold,
                  color = Color(0xFF01579b)
              )
          }

          Spacer(modifier = Modifier.weight(1f))
          //setting the date
          val today = LocalDate.now()
          val formatter = DateTimeFormatter.ofPattern("EEEE, dd MMMM,yy",Locale.US)
          val formattedDate  = today.format(formatter)
          Text(
              formattedDate,
              fontSize = 17.sp,
              fontWeight = FontWeight.ExtraBold,
              color = Color(0xFF01579b)
          )
          Spacer(modifier = Modifier.width(8.dp))
          IconButton(onClick = {
              logoutClicked = true
          }){
              Icon(painter = painterResource("logout.png"),
                  tint = GradeMateColors.Primary,
                  contentDescription = null,
                  modifier = Modifier.size(25.dp))
          }
      }

        Spacer(Modifier.height(32.dp))
        if(Global.role.value == "Admin" || Global.role.value == "HOD"){
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                InfoCard(
                    painter = painterResource("student.jpeg"),
                    title = "Add Student",
                    modifier = Modifier.weight(1f),
                    onClick = { showAddStudentDialog = true }
                )
                InfoCard(
                    painter = painterResource("module.jpg"),
                    title = "Add Module",
                    modifier = Modifier.weight(1f),
                    onClick = { showAddModuleDialog = true }
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            if(Global.role.value == "Admin" || Global.role.value == "HOD"){
                InfoCard(
                    painter = painterResource("tutor.jpg"),
                    title = "Add Tutor",
                    modifier = Modifier.weight(1f),
                    onClick = { showAddTutorDialog = true }
                )
            }

            if(modules.isNotEmpty() &&
                Global.currentEmail.value.isNotEmpty() && students.isNotEmpty()){
                InfoCard(
                    painter = painterResource("users.jpeg"),
                    title = "Users && Results",
                    modifier = Modifier.weight(1f),
                    onClick = goToManage
                )
            }

        }

        Spacer(Modifier.height(32.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),

            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if(modules.isNotEmpty() && Global.currentEmail.value.isNotEmpty() && students.isNotEmpty()){
                Button(
                    onClick = onGoToGrading,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Go to Grading")
                }
            }
            else {
                Row (
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ){
                    CircularProgressIndicator()

                }
            }

        }

    }
    //setting the show student Dialog
            if (showAddStudentDialog) {
        AddStudentDialog(
            onDismiss = { showAddStudentDialog = false },
            onAddStudent = { student ->  // <-- receive student here
                students.add(student)     // update your local list

                CoroutineScope(Dispatchers.IO).launch {
                    val success = addStudentToFirestoreAndAuth(student= student)
                    println(if (success) "✅ Saved to Firestore" else "❌ Save failed")
                    status = success
                    showDialog=true
                }
            }
        )

    }
    //setting the show tutor dialog
    if(showAddTutorDialog){
    AddTutorDialog(onDismiss = {showAddTutorDialog = false},
        onAddTutor = {tutor->
          tutors.add(tutor) //add to local list
            CoroutineScope(Dispatchers.IO).launch {
                val success = addTutorToFirestoreAndAuth(tutor)
                println(if (success) "✅ Tutor saved to Firestore" else "❌ Failed to save tutor")
                status = success
                showDialog = true
            }
        })
    }
    //setting the show module dialog
    if (showAddModuleDialog) {
        AddModuleDialog(
            onDismiss = { showAddModuleDialog = false },
            onAddModule = { module ->
                modules.add(module) // Add to local list

                CoroutineScope(Dispatchers.IO).launch {
                    val success = addModuleToFirestore(module)
                    println(if (success) "✅ Module saved to Firestore" else "❌ Failed to save module")
                    status = success
                    showDialog = true
                }
            }
        )
    }


}


















