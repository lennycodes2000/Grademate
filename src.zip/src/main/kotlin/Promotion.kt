import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import components.Constants.moduleCourseList
import components.Constants.ntaLevelsFrom
import components.Constants.ntaLevelsTo
import components.SmallerDropDownMenuWithLabel
import kotlinx.coroutines.launch

@Composable
fun Promotion(
    onFinish: () -> Unit,
    onPromote: (fromLevel: String, toLevel: String, selected: List<Student>) -> Unit = { _, _, _ -> },
    promotionList: SnapshotStateList<Student>
) {
    val status by remember { mutableStateOf(true) }
    var showDialog by remember { mutableStateOf(false) }
    var promoteClicked by remember { mutableStateOf(false) }
        //setting the dialog
    if (showDialog) {
        TimedDialog(status) {
            showDialog = false
        }
    }
    val coroutineScope = rememberCoroutineScope()
    var ntaLevel by remember { mutableStateOf("") }
    var ntaLevelIndex by remember { mutableStateOf(0) }
    val ntaRequester = remember { FocusRequester() }

    var ntaLevelTo by remember { mutableStateOf("") }
    var ntaLevelIndexTo by remember { mutableStateOf(0) }
    val ntaRequesterTo = remember { FocusRequester() }
    var sortCourse by remember { mutableStateOf("") }

    var allStudentsChecked by remember { mutableStateOf(false) }

    // Regex to extract level and semester
    val regex = Regex("(\\d+) Semester (\\d+)")
    val (sortLevel, sortSemester) = regex.find(ntaLevel)
        ?.destructured
        ?.let { (level, semester) -> level.toInt() to semester.toInt() }
        ?: (0 to 0)
    val (newLevel, newSemester) = regex.find(ntaLevelTo)
        ?.destructured
        ?.let { (level, semester) -> level.toInt() to semester.toInt() }
        ?: (0 to 0)
    //Controlling the selection
    val selectedRegNos = remember { mutableStateListOf<String>() }

    // Filtering function
    fun matchesFilter(student: Student): Boolean {
        val levelOk = student.ntaLevel.trim().toIntOrNull() == sortLevel
        val semesterOk = student.semester.trim().toIntOrNull() == sortSemester
        val courseOk = if (sortCourse != "All") {
            student.program.trim() == sortCourse
        } else {
            true
        }
        return levelOk && semesterOk && courseOk
    }

    // Cache filtered list
    val filteredStudents by remember(ntaLevel, sortCourse, sortLevel, sortSemester, promotionList) {
        mutableStateOf(promotionList.filter(::matchesFilter))
    }

    // Toggle select all
    fun toggleSelectAll(checked: Boolean) {
        allStudentsChecked = checked
        if (checked) {
            selectedRegNos.clear()
            selectedRegNos.addAll(filteredStudents.map { it.regNo })
        } else {
           selectedRegNos.clear()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp)
    ) {
        // 🔙 Top bar
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = onFinish,
                colors = ButtonDefaults.buttonColors(containerColor = GradeMateColors.Primary)
            ) {
                Icon(
                    painter = painterResource("back.png"),
                    contentDescription = "Go Back",
                    tint = GradeMateColors.Background,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text("Go Back", color = GradeMateColors.Background)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Title
        Text(
            "Students Promotion",
            style = MaterialTheme.typography.headlineSmall,
            color = GradeMateColors.Primary,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Promotion Row (From ➡ To ➡ Course)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            SmallerDropDownMenuWithLabel(
                label = "From Level",
                options = ntaLevelsFrom,
                selectedOption = ntaLevel,
                onOptionSelected = {
                    ntaLevel = ntaLevelsFrom[it]
                    ntaLevelIndex = it
                },
                currentAction = ntaRequester,
                nextAction = {}
                , modifier = Modifier.weight(1f)
            )

            Spacer(Modifier.width(12.dp))

            Icon(
                painter = painterResource("forward.png"),
                contentDescription = "To",
                tint = GradeMateColors.Primary,
                modifier = Modifier.size(28.dp)
            )

            Spacer(Modifier.width(12.dp))

            SmallerDropDownMenuWithLabel(
                label = "To Level",
                options = ntaLevelsTo,
                selectedOption = ntaLevelTo,
                onOptionSelected = {
                    ntaLevelTo = ntaLevelsTo[it]
                    ntaLevelIndexTo = it
                },
                currentAction = ntaRequesterTo,
                nextAction = {},
                modifier = Modifier.weight(1f)
            )

            Spacer(Modifier.width(12.dp))

            SmallerDropDownMenuWithLabel(
                label = "Course",
                options = moduleCourseList,
                selectedOption = sortCourse,
                onOptionSelected = { sortCourse = moduleCourseList[it] },
                currentAction = ntaRequesterTo,
                nextAction = {},
                modifier = Modifier.weight(1f)

            )
        }

        Spacer(Modifier.height(20.dp))

        // Info or Filters
        if (ntaLevelIndex == 0 || sortCourse.isEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    "Please Select NTA Level and Course",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray
                )
            }
        } else {
            // Select All
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Checkbox(
                    checked = allStudentsChecked,
                    onCheckedChange = { toggleSelectAll(it) }
                )
                Text(
                    if (allStudentsChecked) "All Selected" else "All Not Selected",
                    fontWeight = FontWeight.Bold,
                    color = GradeMateColors.Primary
                )
            }

            Spacer(Modifier.height(16.dp))

            Text(
                "Students to be promoted",
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                color = Color(0xFF0277bd)
            )

            Spacer(Modifier.height(12.dp))

            Divider()

            Spacer(Modifier.height(8.dp))

            // Student list
            if (filteredStudents.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No students found for this filter", color = Color.Gray)
                }
            } else {

                LazyColumn {
                    items(
                        items = filteredStudents,
                        key = { it.regNo } // stable key
                    ) { student ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(
                                checked = student.regNo in selectedRegNos,
                                onCheckedChange = { checked ->
                                    if (checked) selectedRegNos.add(student.regNo)
                                    else selectedRegNos.remove(student.regNo)
                                    allStudentsChecked = selectedRegNos.size == filteredStudents.size
                                }
                            )
                            Text(student.studentName)
                            Spacer(modifier = Modifier.weight(1f))
                            Text(student.regNo)
                        }
                    }
                }


            }
        }

        Spacer(Modifier.height(16.dp))

        // Promote Button
        if (
            ntaLevelIndex > 0 && ntaLevelIndexTo >0 &&
            ntaLevelIndexTo > ntaLevelIndex && (ntaLevelIndexTo - ntaLevelIndex) == 1 &&
            ntaLevel != ntaLevelTo &&
            selectedRegNos.isNotEmpty() && ntaLevelIndex != 6 && !promoteClicked
        ) {
            Button(
                onClick = {
                    promoteClicked = true
                    coroutineScope.launch {
                        val studentsToPromote = promotionList.filter(::matchesFilter)
                            .filter { it.regNo in selectedRegNos }
                        onPromote(ntaLevel, ntaLevelTo, studentsToPromote)
                        for (student in studentsToPromote) {
                            val success =
                                promoteStudentInFirestore(student, newLevel.toString(), newSemester.toString())

                            if (success) {
                                println("✅ ${student.studentName} promoted")
                                showDialog=true
                            } else {
                                println("❌ Failed to promote ${student.studentName}")
                            }
                        }
                        // reload after updates
                        val updatedStudents = fetchStudentsFromFirestore()
                        promotionList.clear()
                        promotionList.addAll(updatedStudents)
                        promoteClicked = false
                        allStudentsChecked = false
                        ntaLevelIndexTo = 0
                        ntaLevelTo = ""
                        ntaLevelIndex = 0
                        ntaLevel = ""
                        sortCourse = ""
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = GradeMateColors.Primary),
                modifier = Modifier.align(Alignment.End)
            ) {
                Text("Promote", color = GradeMateColors.Background, fontWeight = FontWeight.Bold)
            }
        }
    }
}

