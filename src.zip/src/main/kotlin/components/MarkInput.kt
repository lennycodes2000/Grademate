
import androidx.compose.foundation.layout.width
import androidx.compose.material.LocalTextStyle
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.Text
import androidx.compose.material.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp

@Composable
fun markInput(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    currentFocus: FocusRequester,
    nextFocus: FocusRequester?,
    maxAllowed: Double = 60.0,
    onAttemptExceed: (() -> Unit)? = null
) {
    OutlinedTextField(
        value = value,
        onValueChange = { newValue ->
            val filtered = newValue.replace(",", ".")
            val doubleVal = filtered.toDoubleOrNull()

            if (filtered.isEmpty() || doubleVal == null || doubleVal <= maxAllowed) {
                onValueChange(filtered)
            } else {
                onAttemptExceed?.invoke()
            }
        },
        label = { Text(label) },
        modifier = Modifier
            .width(100.dp)
            .focusRequester(currentFocus)
            .onPreviewKeyEvent { keyEvent ->
                if (keyEvent.key == Key.Tab && keyEvent.type == KeyEventType.KeyDown) {
                    nextFocus?.requestFocus()
                    true
                } else false
            },
        singleLine = true,
        textStyle = LocalTextStyle.current.copy(textAlign = TextAlign.Center),
        colors = TextFieldDefaults.outlinedTextFieldColors(
            focusedBorderColor = Color(0xFF4A90E2),
            focusedLabelColor = Color(0xFF4A90E2),
            cursorColor = Color(0xFF4A90E2)
        )
    )
}







