package components

import java.time.LocalDate

object Constants {
    val email = "gradematedesktopapp@gmail.com"
    val appPass = "tlbinldwbqwceivv"
    val recipients = listOf(
    "bcbtictdepartment@gmail.com","bcbtbadepartment@gmail.com","uncleaziri@gmail.com"
    )
    val courseList = listOf("Pick Course ","ICT","BA")
    val deptList = listOf("Pick Department ","ICT","BA")
    val moduleCourseList = listOf("ICT","BA","All")
    val roleList = listOf("Admin","HOD","Tutor")
    val ntaLevels = listOf("Pick Level","4", "5", "6")
    val statuList = listOf("Pick Status","ACTIVE","DROPPED","GRADUATED")
    val ntaLevelsFrom = buildList {
        add("Pick Level")
        (4..6).forEach { level ->          // levels 4 to 6
            (1..2).forEach { semester ->   // semester 1 and 2
                add("$level Semester $semester")
            }
        }
    }
    val ntaLevelsTo = buildList {
        add("Pick Level")
        (4..6).forEach{level->
            (1..2).forEach{semester->
                add("$level Semester $semester")
            }

        }
    }
    val genders = listOf("Pick Gender","Male", "Female")
    val semesters = listOf("Pick semester","1","2")
    val startYear = 2024
    val endYear = 2059
    val academicYear = buildList {
        for (year in startYear.. endYear)
       add("$year/${year.plus(1)}")
    }
    val intake = listOf("September","March")

}