import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ModuleGradesStateView(
    selectedModule: Module?,
    filteredStudents: List<Student>,
    students: List<Student>,
    initialModuleCode: String,
    onShow: @Composable ()->Unit
) {
    val showEmptyModule = selectedModule?.code == null
    val showLoading = filteredStudents.isEmpty() && students.isNotEmpty() && selectedModule?.code != initialModuleCode

    AnimatedContent(
        targetState = when {
            showEmptyModule -> "empty"
            showLoading -> "loading"
            else -> {}
        },
        transitionSpec = {
            fadeIn() + slideInVertically(initialOffsetY = { it / 2 }) togetherWith
                    fadeOut() + slideOutVertically(targetOffsetY = { -it / 2 })
        },
        label = "Module Grades View Transition"
    ) { state ->
        when (state) {
            "empty" -> EmptyModuleView()
            "loading" -> LoadingModuleView()
            else -> {
                onShow()
            } // Grades
        }
    }
}

@Composable
private fun EmptyModuleView() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
               painter = painterResource("info.png"),
                contentDescription = null,
                tint = GradeMateColors.Primary.copy(alpha = 0.7f),
                modifier = Modifier.size(64.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Select a module to view grades",
                color = GradeMateColors.Primary,
                fontWeight = FontWeight.Medium,
                fontSize = 18.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Choose a module from the list to see student results.",
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                fontSize = 14.sp
            )
        }
    }
}

@Composable
private fun LoadingModuleView() {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(
                color = GradeMateColors.Primary,
                strokeWidth = 4.dp,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Loading student grades...",
                color = GradeMateColors.Primary,
                fontWeight = FontWeight.Medium,
                fontSize = 16.sp
            )
        }
    }
}
