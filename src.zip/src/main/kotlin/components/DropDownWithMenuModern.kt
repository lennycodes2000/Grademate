
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp


@Composable
fun DropdownMenuWithLabelModern(
    label: String,
    options: List<String>,
    selectedOption: String,
    onOptionSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    var currentLabel by remember { mutableStateOf(selectedOption) }
    val rotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing)
    )

    Box(modifier = modifier) {
        OutlinedTextField(
            value = currentLabel,
            onValueChange = {},
            readOnly = true,
            label = { Text(label, fontWeight = FontWeight.Medium) },
            trailingIcon = {
                Icon(
                    tint = GradeMateColors.Primary,
                    painter = painterResource("down.png"),
                    contentDescription = "Dropdown Arrow",
                    modifier = Modifier.size(15.dp).rotate(rotation)
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedBorderColor = Color(0xFF4A90E2),
                unfocusedBorderColor = Color(0xFFB0BEC5),
                focusedLabelColor = Color(0xFF4A90E2),
                cursorColor = Color(0xFF4A90E2)
            )
        )
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
        ) {
            options.forEachIndexed { index, text ->
                DropdownMenuItem(onClick = {
                    currentLabel = text
                    expanded = false
                    onOptionSelected(index)
                }) {
                    Text(text)
                }
            }
        }
        Spacer(
            modifier = Modifier
                .matchParentSize()
                .clickable { expanded = true }
        )
    }
}