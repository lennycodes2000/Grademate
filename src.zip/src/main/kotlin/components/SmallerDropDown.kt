package components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp

@Composable
fun SmallerDropDownMenuWithLabel(
    label: String,
    options: List<String>,
    selectedOption: String,
    onOptionSelected: (Int) -> Unit,
    nextAction: () -> Unit,
    currentAction: FocusRequester,
    modifier: Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        OutlinedTextField(
            value = selectedOption,
            onValueChange = {},
            readOnly = true,
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { nextAction() }),
            label = { Text(label) },
            trailingIcon = {
                Icon(
                    painter = painterResource("down.png"),
                    tint = GradeMateColors.Primary,
                    contentDescription = null,
                    modifier = Modifier
                        .size(15.dp)
                        .clickable { expanded = !expanded }
                )
            },
            modifier = Modifier
                .clickable { expanded = !expanded }
                .focusRequester(currentAction),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedBorderColor = Color(0xFF0288d1),
                unfocusedBorderColor = Color(0xFF81d4fa),
                cursorColor = Color(0xFF0288d1),
                focusedLabelColor = Color(0xFF0288d1)
            )
        )
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
        ) {
            options.forEachIndexed { index, option ->
                DropdownMenuItem(
                    onClick = {
                        expanded = false
                        onOptionSelected(index)
                    }
                ) {
                    Text(option)
                }
            }
        }
    }
}