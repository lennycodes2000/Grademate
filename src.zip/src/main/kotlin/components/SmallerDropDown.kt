
import GradeMateColors
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp

@Composable
fun SmallerDropDownMenuWithLabel(
    label: String,
    options: List<String>,
    selectedOption: String,
    onOptionSelected: (Int) -> Unit,
    nextAction: () -> Unit,
    currentAction: FocusRequester,
    modifier: Modifier = Modifier,
    labelIcon: Painter? = null, // optional icon for label
    itemIcons: List<Painter?> = emptyList() // optional icons for dropdown items
) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = modifier) {
        OutlinedTextField(
            value = selectedOption,
            onValueChange = {},
            readOnly = true,
            singleLine = true,
            keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Next),
            keyboardActions = KeyboardActions(onNext = { nextAction() }),
            label = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    labelIcon?.let {
                        Icon(it, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                    }
                    Text(label)
                }
            },
            trailingIcon = {
                Icon(
                    painter = painterResource("down.png"),
                    tint = GradeMateColors.Primary,
                    contentDescription = "Dropdown",
                    modifier = Modifier
                        .size(15.dp)
                        .clickable { expanded = !expanded }
                )
            },
            modifier = Modifier
                .clickable { expanded = !expanded }
                .focusRequester(currentAction)
                .then(modifier),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedBorderColor = Color(0xFF0288d1),
                unfocusedBorderColor = Color(0xFF81d4fa),
                cursorColor = Color(0xFF0288d1),
                focusedLabelColor = Color(0xFF0288d1)
            )
        )

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEachIndexed { index, option ->
                DropdownMenuItem(
                    content = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (index < itemIcons.size) {
                                itemIcons[index]?.let {
                                    Icon(it, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                }
                            }
                            Text(option)
                        }
                    },
                    onClick = {
                        expanded = false
                        onOptionSelected(index)
                    }
                )
            }
        }
    }
}
