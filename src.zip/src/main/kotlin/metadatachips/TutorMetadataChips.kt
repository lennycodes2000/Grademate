package metadatachips

import Tutor
import androidx.compose.foundation.layout.*
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

@Composable
fun TutorMetadataChips(tutor: Tutor) {
    val chipData = listOfNotNull(
        "gender.png" to tutor.gender,
        if (Global.role.value == "Admin") "dept.png" to "Dept: ${tutor.dept}" else null,
        "role.png" to tutor.role,
        "phone.png" to tutor.phone
    )


    Column(modifier = Modifier.fillMaxWidth()) {
        var rowChips = mutableListOf<@Composable () -> Unit>()
        var rowCount = 0

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            var tempRow = mutableListOf<@Composable () -> Unit>()

            chipData.forEach { (icon, label) ->
                tempRow.add {
                    AssistChip(
                        onClick = {},
                        label = { Text(label) },
                        leadingIcon = {
                            Icon(
                                painter = painterResource(icon),
                                modifier = Modifier.size(20.dp),
                                contentDescription = null
                            )
                        }
                    )
                }
                rowCount++

                // Wrap after 3 chips in a row (adjust as needed)
                if (rowCount >= 3) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        tempRow.forEach { it() }
                    }
                    tempRow.clear()
                    rowCount = 0
                }
            }

            // Remaining chips
            if (tempRow.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    tempRow.forEach { it() }
                }
            }
        }
    }
}
