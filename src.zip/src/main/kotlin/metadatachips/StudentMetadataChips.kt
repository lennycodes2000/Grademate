package metadatachips

import Global
import Student
import androidx.compose.foundation.layout.*
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

@Composable
fun MetadataChips(student: Student) {
    val chipData = listOfNotNull(
        "gender.png" to student.gender,
        "school.png" to "Level: ${student.ntaLevel}",
        "daterange.png" to "Semester: ${student.semester}",
        if (Global.role.value == "Admin") "book.png" to student.program else null,
        "intake.png" to "${student.intake} Intake"
    )


    Column(modifier = Modifier.fillMaxWidth()) {
        var rowChips = mutableListOf<@Composable () -> Unit>()

        chipData.forEach { (icon, label) ->
            val chipComposable: @Composable () -> Unit = {
                AssistChip(
                    onClick = {},
                    label = { Text(label) },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(icon),
                            modifier = Modifier.size(20.dp),
                            contentDescription = null
                        )
                    }
                )
            }
            rowChips.add(chipComposable)
        }

        // Simple wrapped layout using Column + Row
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            var tempRow = mutableListOf<@Composable () -> Unit>()
            var rowCount = 0

            rowChips.forEach { chip ->
                tempRow.add(chip)
                rowCount++

                // After certain number of chips, wrap to next row
                if (rowCount >= 3) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        tempRow.forEach { it() }
                    }
                    tempRow.clear()
                    rowCount = 0
                }
            }

            // Add leftover chips
            if (tempRow.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    tempRow.forEach { it() }
                }
            }
        }
    }
}
