package metadatachips

import Student
import androidx.compose.foundation.layout.*
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

@Composable
fun MetadataChips(student: Student) {
    val chipData = listOf(
        Pair("gender.png", student.gender),
        Pair("school.png", "Level: ${student.ntaLevel}"),
        Pair("daterange.png", "Semester: ${student.semester}"),
        Pair("book.png", student.program),
        Pair("intake.png", "${student.intake} Intake")
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        var rowChips = mutableListOf<@Composable () -> Unit>()
        var currentRowWidth = 0.dp
        val maxWidth = 300.dp // adjust as needed or pass as parameter

        chipData.forEach { (icon, label) ->
            val chipComposable: @Composable () -> Unit = {
                AssistChip(
                    onClick = {},
                    label = { Text(label) },
                    leadingIcon = {
                        Icon(
                            painter = painterResource(icon),
                            modifier = Modifier.size(20.dp),
                            contentDescription = null
                        )
                    }
                )
            }
            rowChips.add(chipComposable)
        }

        // Simple wrapped layout using Column + Row
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            var tempRow = mutableListOf<@Composable () -> Unit>()
            var rowCount = 0

            rowChips.forEach { chip ->
                tempRow.add(chip)
                rowCount++

                // After certain number of chips, wrap to next row
                if (rowCount >= 3) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        tempRow.forEach { it() }
                    }
                    tempRow.clear()
                    rowCount = 0
                }
            }

            // Add leftover chips
            if (tempRow.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    tempRow.forEach { it() }
                }
            }
        }
    }
}
