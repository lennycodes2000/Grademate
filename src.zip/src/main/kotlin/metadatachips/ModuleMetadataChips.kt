
import androidx.compose.foundation.layout.*
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

@Composable
fun ModuleMetadataChips(module: Module) {
    val chipData = listOf(
        Pair("star.png", "Credit: ${module.credit}"),
        Pair("school.png", "Level: ${module.level}"),
        Pair("daterange.png", "Semester: ${module.semester}")
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        var rowCount = 0
        var tempRow = mutableListOf<@Composable () -> Unit>()

        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            chipData.forEach { (icon, label) ->
                tempRow.add {
                    AssistChip(
                        onClick = {},
                        label = { Text(label) },
                        leadingIcon = {
                            Icon(
                                painter = painterResource(icon),
                                modifier = Modifier.size(20.dp),
                                contentDescription = null
                            )
                        }
                    )
                }
                rowCount++

                // Wrap after 3 chips (adjust as needed)
                if (rowCount >= 3) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        tempRow.forEach { it() }
                    }
                    tempRow.clear()
                    rowCount = 0
                }
            }

            // Remaining chips
            if (tempRow.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    tempRow.forEach { it() }
                }
            }
        }
    }
}
