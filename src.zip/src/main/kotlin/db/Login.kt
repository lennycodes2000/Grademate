package db

import Global
import GradeMateColors
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import components.Constants
import getHodEmailsByDepartment
import getTutorDeptByEmail
import getTutorRoleByEmail
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import signWithEmail

@Composable
fun Login(
    onFinish: () -> Unit
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var showPass by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()
    val emailFocusRequester = remember { FocusRequester() }
    val passwdFocusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        emailFocusRequester.requestFocus()
    }

    fun doLogin() {
        if (isLoading) return
        scope.launch {
            if (username.isBlank() || password.isBlank()) {
                message = "Fields cannot be empty"
                return@launch
            }
            isLoading = true
            try {
                val idToken = withContext(Dispatchers.IO) {
                    signWithEmail(username, password)
                }

                if (idToken != null) {
                    // Store idToken for later use (changePassword)
                    Global.idtoken.value = idToken
                    Global.currentEmail.value = username
                    Global.pd.value = password
                    Global.role.value = getTutorRoleByEmail(username).toString()
                    Global.department.value = getTutorDeptByEmail(username).toString()
                     if(Global.department.value.isNotBlank()){
                         val tutorEmails = getHodEmailsByDepartment(Global.department.value)

// Merge both lists (HOD + current user)
                         val allEmails = tutorEmails + listOfNotNull(Global.currentEmail.value)

// Clear old list and add unique ones only
                         Constants.recipient.clear()
                         Constants.recipient.addAll(allEmails.distinctBy { it.lowercase() })
                         println(Constants.recipient)
                     }
                    if (Global.role.value.isNotBlank()) {
                        onFinish()
                        println("${Global.role.value} ${Global.department.value} ")
                    }
                } else {
                    message = "Login failed"
                }

            } catch (e: Exception) {
                message = "Error: ${e.message}"
            } finally {
                isLoading = false
            }
        }


    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GradeMateColors.Primary),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Column(
            modifier = Modifier
                .clip(RoundedCornerShape(32.dp))
                .size(500.dp)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(Color(0xFF81d4fa), Color(0xFFe1f5fe))
                    )
                )
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource("logo.png"),
                contentScale = ContentScale.Crop,
                contentDescription = null,
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                "Welcome to GradeMate",
                fontWeight = FontWeight.Bold,
                fontSize = 1.2.em,
                color = GradeMateColors.Primary
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Username
            OutlinedTextField(
                value = username,
                onValueChange = {
                    if (it.length <= 40) username = it
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email,
                    imeAction = ImeAction.Next
                ),
                keyboardActions = KeyboardActions(
                    onNext = { passwdFocusRequester.requestFocus() }
                ),
                label = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            painter = painterResource("email.png"),
                            modifier = Modifier.size(15.dp),
                            contentDescription = null,
                            tint = GradeMateColors.Primary
                        )
                        Spacer(modifier = Modifier.size(4.dp))
                        Text("e-mail") }
                    }
                 ,
                trailingIcon = {
                    Icon(
                        painter = painterResource("email.png"),
                        modifier = Modifier.size(25.dp),
                        contentDescription = null,
                        tint = GradeMateColors.Primary
                    )
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .focusRequester(emailFocusRequester)
            )

            // Password
            OutlinedTextField(
                value = password,
                onValueChange = {
                    if (it.length <= 20) password = it
                },
                visualTransformation = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = { showPass = !showPass }) {
                        Icon(
                            painter = if (showPass) painterResource("hide.png") else painterResource("show.png"),
                            modifier = Modifier.size(25.dp),
                            contentDescription = null,
                            tint = GradeMateColors.Primary
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = { doLogin() }
                ),
                label = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            painter = painterResource("lock.png"),
                            modifier = Modifier.size(15.dp),
                            contentDescription = null,
                            tint = GradeMateColors.Primary
                        )
                        Spacer(modifier = Modifier.size(4.dp))
                        Text("password") }
                        },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .focusRequester(passwdFocusRequester)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Login Button
            Button(
                onClick = { doLogin() },
                enabled = !isLoading,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        color = GradeMateColors.Primary,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(20.dp)
                    )
                } else {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Login")
                        Spacer(modifier = Modifier.width(5.dp))
                        Icon(
                            painter = painterResource("login.png"),
                            modifier = Modifier.size(25.dp),
                            contentDescription = null,
                            tint = Color.White
                        )
                    }
                }
            }

            if (message.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(message, color = Color.Red)
            }
        }
    }
}


