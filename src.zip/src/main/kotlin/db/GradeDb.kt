import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import jdk.internal.net.http.common.Log
import kotlinx.coroutines.coroutineScope
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive

suspend fun saveGradeToFirestore(projectId: String, grade: Grade): Boolean = coroutineScope {
    val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    val docId = "${grade.studentId}_${grade.moduleCode}".replace("/", "_")
    val url = "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/grades/$docId"

    val caMarkValue = listOf(
        grade.assignmentMark,
        grade.quizMark,
        grade.attendanceMark,
        grade.testOneMark,
        grade.testTwoMark
    ).sumOf { it.replace(",", ".").toDoubleOrNull() ?: 0.0 }
    val total: Double = (grade.examMark.toDoubleOrNull() ?: 0.0) + caMarkValue

    val payload = FirestoreGradeDocument(
        fields = GradeFields(
            studentId = FirestoreString(grade.studentId),
            moduleCode = FirestoreString(grade.moduleCode),
            assignmentMark = FirestoreString(grade.assignmentMark),
            quizMark = FirestoreString(grade.quizMark),
            attendanceMark = FirestoreString(grade.attendanceMark),
            testOneMark = FirestoreString(grade.testOneMark),
            testTwoMark = FirestoreString(grade.testTwoMark),
            caMark = FirestoreDouble(caMarkValue),
            examMark = FirestoreString(grade.examMark),
            total = FirestoreDouble(total),
            ntaLevel = FirestoreString(grade.ntaLevel),
            semester = FirestoreString(grade.semester),
            academicYear = FirestoreString(grade.academicYear),

            )
    )
    try {
        client.patch(url) {
            contentType(ContentType.Application.Json)
            setBody(payload)
        }
        println("Saved grade for ${grade.studentId}")
        true
    } catch (e: Exception) {
        println("❌ Failed to save grade for ${grade.studentId}: ${e.message}")
        false
    } finally {
        client.close()
    }
}
//load grades
suspend fun loadGradesForModule(
    projectId: String,
    moduleCode: String,
    academicYear: String
): List<Grade> {
    val client = HttpClient(CIO) {
        install(ContentNegotiation) { json(Json { ignoreUnknownKeys = true }) }
    }

    val url =
        "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents:runQuery"

    val requestBody = """
        {
          "structuredQuery": {
            "from": [{ "collectionId": "grades" }],
            "where": {
              "compositeFilter": {
                "op": "AND",
                "filters": [
                  {
                    "fieldFilter": {
                      "field": { "fieldPath": "moduleCode" },
                      "op": "EQUAL",
                      "value": { "stringValue": "$moduleCode" }
                    }
                  },
                  {
                    "fieldFilter": {
                      "field": { "fieldPath": "academicYear" },
                      "op": "EQUAL",
                      "value": { "stringValue": "$academicYear" }
                    }
                  }
                ]
              }
            }
          }
        }
    """.trimIndent()

    return try {
        val response = client.post(url) {
            contentType(ContentType.Application.Json)
            setBody(requestBody)
        }

        val results = response.body<List<FirestoreQueryResponse>>()

        results.mapNotNull { queryResp ->
            val fields = queryResp.document?.fields ?: return@mapNotNull null
            fields.toGrade()
        }
    } catch (e: Exception) {
        println("❌ Failed to load grades: ${e.message}")
        emptyList()
    } finally {
        client.close()
    }
}


