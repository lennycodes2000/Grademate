package db

import Database
import FirestoreDocument
import FirestoreFields
import FirestoreStringValue
import NetworkClient
import Student
import hashPassword
import io.ktor.client.request.*
import io.ktor.http.*
import kotlinx.coroutines.coroutineScope

//promote students
suspend fun promoteStudentInFirestore(
    student: Student,
    newLevel: String,
    newSemester: String
): Boolean = coroutineScope {
    val projectId = Database.projectId

    try {
        val firestoreUrl =
            "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/students/${student.regNo.replace("/", "_")}"

        val hashedPassword = hashPassword(student.regNo)

        val firestorePayload = FirestoreDocument(
            fields = FirestoreFields(
                studentName = FirestoreStringValue(student.studentName),
                regNo = FirestoreStringValue(student.regNo),
                gender = FirestoreStringValue(student.gender),
                ntaLevel = FirestoreStringValue(newLevel),     // updated
                semester = FirestoreStringValue(newSemester), // updated
                program = FirestoreStringValue(student.program),
                passHash = FirestoreStringValue(hashedPassword),
                intake = FirestoreStringValue(student.intake),
                status = FirestoreStringValue(student.status)
            )
        )
        NetworkClient.http.patch(firestoreUrl) {
            contentType(ContentType.Application.Json)
            setBody(firestorePayload)
        }

        println("✅ Student ${student.studentName} promoted to $newLevel - Semester $newSemester")
        true
    } catch (e: Exception) {
        println("❌ Error promoting ${student.studentName}: ${e.message}")
        false
    }
}


