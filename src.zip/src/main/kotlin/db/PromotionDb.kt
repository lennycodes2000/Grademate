import io.ktor.client.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.coroutines.coroutineScope
import kotlinx.serialization.json.Json

//promote students
suspend fun promoteStudentInFirestore(
    student: Student,
    newLevel: String,
    newSemester: String
): Boolean = coroutineScope {
    val projectId = Database.projectId
    val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    try {
        val firestoreUrl =
            "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/students/${student.regNo.replace("/", "_")}"

        val hashedPassword = hashPassword(student.regNo) // still preserved if you want

        val firestorePayload = FirestoreDocument(
            fields = FirestoreFields(
                studentName = FirestoreStringValue(student.studentName),
                regNo = FirestoreStringValue(student.regNo),
                gender = FirestoreStringValue(student.gender),
                ntaLevel = FirestoreStringValue(newLevel),   // 👈 updated
                semester = FirestoreStringValue(newSemester), // 👈 updated
                program = FirestoreStringValue(student.program),
                passHash = FirestoreStringValue(hashedPassword),
                intake = FirestoreStringValue(student.intake),

            )
        )

        client.patch(firestoreUrl) {
            contentType(ContentType.Application.Json)
            setBody(firestorePayload)
        }

        println("✅ Student ${student.studentName} promoted to $newLevel - Semester $newSemester")
        true
    } catch (e: Exception) {
        println("❌ Error promoting ${student.studentName}: ${e.message}")
        false
    } finally {
        client.close()
    }
}

