import kotlinx.serialization.Serializable
    @Serializable
    data class FirestoreString(val stringValue: String)

    @Serializable
    data class FirestoreArray(val arrayValue: FirestoreList)

    @Serializable
    data class FirestoreList(val values: List<FirestoreString>)
    @Serializable
    data class FirebaseAuthResponse(
        val idToken:String,
        val localId:String,
        val email: String
    )
    @Serializable
    data class Student(
        val id: Int,
        val studentName: String,
        val regNo: String,        // actual reg number
        val gender: String,
        val ntaLevel: String,
        val semester:String,
        val program: String,
        val intake:String,
        val status: String = "ACTIVE"
    )

    @Serializable
    data class Tutor(
        val id: String = "",
        var tutorName:String,
        val email:String,
        val phone:String,
        val gender: String,
        val dept:String,
        val role:String
    )
@Serializable
data class Publish(
    val coursework:String,
    val courseworkNtaLevel:String,
    val courseworkSemester:String,
    val results: String,
    val resultsNtaLevel:String,
    val resultsSemester:String
)
@Serializable
data class FirestoreTutorFields(
    val tutorName: FirestoreStringValue,
    val email: FirestoreStringValue,
    val phone: FirestoreStringValue,
    val gender: FirestoreStringValue,
    val dept: FirestoreStringValue,
    val role: FirestoreStringValue,

)
@Serializable
data class AbsenceFields(
    val studentRegNo: FirestoreString,
    val studentName: FirestoreString,
    val moduleCode: FirestoreString,
    val moduleName: FirestoreString,
    val absenceDate: FirestoreString,
    val academicYear:FirestoreString
)

@Serializable
data class AbsenceDocument(
    val fields: AbsenceFields
)
@Serializable
data class FirestoreDouble(
    val doubleValue: Double? = null,
    val integerValue: String? = null
) {
    fun toDouble(): Double {
        return when {
            doubleValue != null -> doubleValue
            integerValue != null -> integerValue.toDoubleOrNull() ?: 0.0
            else -> 0.0
        }
    }
}
@Serializable
data class GradeFields(
    val studentId: FirestoreString? = null,
    val moduleCode: FirestoreString? = null,
    val assignmentMark: FirestoreString? = null,
    val quizMark: FirestoreString? = null,
    val attendanceMark: FirestoreString? = null,
    val testOneMark: FirestoreString? = null,
    val testTwoMark: FirestoreString? = null,
    val caMark: FirestoreDouble? = null,
    val examMark: FirestoreString? = null,
    val total: FirestoreDouble? = null,
    val ntaLevel: FirestoreString? = null,
    val semester: FirestoreString? = null,
    val academicYear: FirestoreString? = null,
)
fun GradeFields.toGrade(): Grade {
    return Grade(
        studentId = studentId?.stringValue.orEmpty(),
        moduleCode = moduleCode?.stringValue.orEmpty(),
        assignmentMark = assignmentMark?.stringValue.orEmpty(),
        quizMark = quizMark?.stringValue.orEmpty(),
        attendanceMark = attendanceMark?.stringValue.orEmpty(),
        testOneMark = testOneMark?.stringValue.orEmpty(),
        testTwoMark = testTwoMark?.stringValue.orEmpty(),
        examMark = examMark?.stringValue.orEmpty()
    )
}

@Serializable
data class FirestoreQueryResponse(
    val document: FirestoreDocumentGrade? = null,
    val readTime: String? = null
)

@Serializable
data class FirestoreStringValue(val stringValue: String)
@Serializable
data class FirebaseAuthRequest(
    val email: String,
    val password: String,
    val returnSecureToken: Boolean = true
)
@Serializable
data class FirestoreFields(
    val studentName: FirestoreStringValue,
    val regNo: FirestoreStringValue,
    val gender: FirestoreStringValue,
    val ntaLevel: FirestoreStringValue,
    val semester: FirestoreStringValue,
    val program: FirestoreStringValue,
    val passHash: FirestoreStringValue,
    val intake: FirestoreStringValue,
    val status: FirestoreStringValue,

)

@Serializable
data class FirestoreDocument(val fields: FirestoreFields)
@Serializable
data class FirestoreTutorDocument(val fields: FirestoreTutorFields)
@Serializable
data class FirestoreDocumentGrade(
    val name: String,
    val fields: GradeFields
)
data class StudentPromotion(
    val id: String,
    val studentName: String,
    val ntaLevel: String,
    var isSelected: Boolean = false
)
@Serializable
data class ModuleFields(
    val code: FirestoreString,
    val name: FirestoreString,
    val credit: FirestoreString,
    val level: FirestoreString,
    val semester: FirestoreString,
    val courses: FirestoreArray,
    val tutor: FirestoreString
)

@Serializable
data class ModuleDocument(val fields: ModuleFields)

@Serializable
data class Module(
    val code: String,
    val name: String,
    val credit: String,
    val courses: List<String>,
    val tutor: String
) {
    val level: String get() = extractNumbers(code).getOrNull(1)?.toString() ?: "-"
    val semester: String get() = extractNumbers(code).getOrNull(2)?.toString() ?: "-"
}

fun extractNumbers(input: String) = input.filter { it.isDigit() }