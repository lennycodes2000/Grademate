
import components.Constants
import io.ktor.client.call.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import kotlinx.coroutines.coroutineScope
import kotlinx.serialization.json.*

//adding student to firestore
suspend fun addStudentToFirestoreAndAuth(student: Student): Boolean = coroutineScope {
    val projectId = Database.projectId
    val firebaseApiKey = Database.firebaseAPIKey

    val lastName = student.studentName.trim().split("\\s+".toRegex()).lastOrNull()
    if (lastName.isNullOrBlank()) {
        println("❌ Cannot extract last name from '${student.studentName}'")
        return@coroutineScope false
    }

    val email = "${student.regNo.replace("/", "").lowercase()}@gmail.com"
    val plainPassword = if (lastName.length < 6) lastName.padEnd(6, '1') else lastName
    val hashedPassword = hashPassword(plainPassword)

    // Step 1: Firebase Auth (create account)
    val localId: String = try {
        val authResponse = NetworkClient.http.post("https://identitytoolkit.googleapis.com/v1/accounts:signUp") {
            parameter("key", firebaseApiKey)
            contentType(ContentType.Application.Json)
            setBody(FirebaseAuthRequest(email, plainPassword))
        }

        val responseText = authResponse.bodyAsText()
        if (authResponse.status == HttpStatusCode.OK) {
            val authObj = Json.decodeFromString<JsonObject>(responseText)
            val id = authObj["localId"]?.jsonPrimitive?.content
            println("✅ Firebase Auth user created: $email | Password: $plainPassword")
            id ?: return@coroutineScope false
        } else {
            println("⚠️ Firebase Auth response: ${authResponse.status}")
            println("🔍 Firebase response body: $responseText")
            return@coroutineScope false
        }
    } catch (e: Exception) {
        val message = e.message ?: ""
        return@coroutineScope if ("EMAIL_EXISTS" in message) {
            println("❌ Student already exists in Firebase Auth: $email")
            false
        } else {
            println("❌ Auth error: $message")
            false
        }
    }

    // Step 2: Firestore duplicate check
    val firestoreDocId = student.regNo.replace("/", "_")
    val firestoreUrl =
        "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/students/$firestoreDocId"

    val exists = try {
        val checkResponse = NetworkClient.http.get(firestoreUrl)
        checkResponse.status == HttpStatusCode.OK // Already exists
    } catch (e: Exception) {
        false // Not found, safe
    }

    if (exists) {
        println("❌ Student already exists in Firestore with RegNo: ${student.regNo}")

        // Rollback: delete Auth user we just created
        try {
            NetworkClient.http.post("https://identitytoolkit.googleapis.com/v1/accounts:delete") {
                parameter("key", firebaseApiKey)
                contentType(ContentType.Application.Json)
                setBody(mapOf("localId" to localId))
            }
            println("🗑️ Rolled back Firebase Auth account for $email")
        } catch (ex: Exception) {
            println("⚠️ Failed to rollback Firebase Auth user: ${ex.message}")
        }

        return@coroutineScope false
    }

    // Step 3: Firestore insert
    val firestorePayload = FirestoreDocument(
        fields = FirestoreFields(
            studentName = FirestoreStringValue(student.studentName),
            regNo = FirestoreStringValue(student.regNo),
            gender = FirestoreStringValue(student.gender),
            ntaLevel = FirestoreStringValue(student.ntaLevel),
            semester = FirestoreStringValue(student.semester),
            program = FirestoreStringValue(student.program),
            passHash = FirestoreStringValue(hashedPassword),
            intake = FirestoreStringValue(student.intake),
            status = FirestoreStringValue(student.status)
        )
    )

    try {
        NetworkClient.http.patch(firestoreUrl) {
            contentType(ContentType.Application.Json)
            setBody(firestorePayload)
        }
        println("✅ Student added to Firestore")
        true
    } catch (e: Exception) {
        println("❌ Failed to add to Firestore: ${e.message}")

        // Rollback Auth if Firestore insert failed
        try {
            NetworkClient.http.post("https://identitytoolkit.googleapis.com/v1/accounts:delete") {
                parameter("key", firebaseApiKey)
                contentType(ContentType.Application.Json)
                setBody(mapOf("localId" to localId))
            }
            println("🗑️ Rolled back Firebase Auth account for $email due to Firestore failure")
        } catch (ex: Exception) {
            println("⚠️ Failed to rollback Firebase Auth user: ${ex.message}")
        }

        false
    }
}


//deleting student
suspend fun onDeleteStudent(student: Student): Boolean = coroutineScope {
    val projectId = Database.projectId
    val firestoreUrl =
        "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/students/${student.regNo.replace("/", "_")}"

    try {
        NetworkClient.http.delete(firestoreUrl)
        println("✅ Student deleted successfully: ${student.regNo}")
        true
    } catch (e: Exception) {
        println("❌ Failed to delete student: ${e.message}")
        false
    }
}

//fetch from students
suspend fun fetchStudentsFromFirestore(): List<Student> = coroutineScope {
    val projectId = Database.projectId

    val baseUrl = "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/students"
    val allStudents = mutableListOf<Student>()
    var nextPageToken: String? = null

    try {
        do {
            val url = buildString {
                append("$baseUrl?pageSize=300")
                nextPageToken?.let { append("&pageToken=$it") }
            }

            val response: JsonObject = NetworkClient.http.get(url).body()
            val documents = response["documents"]?.jsonArray ?: JsonArray(emptyList())
            nextPageToken = response["nextPageToken"]?.jsonPrimitive?.contentOrNull

            val students = documents.mapNotNull { doc ->
                try {
                    val fields = doc.jsonObject["fields"]?.jsonObject ?: return@mapNotNull null
                    val id = fields["id"]?.jsonObject?.get("integerValue")?.jsonPrimitive?.intOrNull
                    val studentName = fields["studentName"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: return@mapNotNull null
                    val regNo = fields["regNo"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""
                    val gender = fields["gender"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""
                    val ntaLevel = fields["ntaLevel"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""
                    val semester = fields["semester"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""
                    val program = fields["program"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""
                    val intake = fields["intake"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""
                    val status = fields["status"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""

                    Student(
                        id = id ?: 0,
                        studentName = studentName,
                        regNo = regNo,
                        gender = gender,
                        ntaLevel = ntaLevel,
                        semester = semester,
                        program = program,
                        intake = intake,
                        status = status
                    )
                } catch (e: Exception) {
                    println("⚠️ Failed to parse student: ${e.message}")
                    null
                }
            }

            val filteredStudents = students.sortedWith(
                compareBy<Student> { it.status != Constants.statuList[3] }
                    .thenBy { it.studentName.lowercase() }
            )

            allStudents.addAll(filteredStudents)

        } while (nextPageToken != null)

        allStudents
    } catch (e: Exception) {
        println("❌ Failed to fetch students: ${e.message}")
        emptyList()
    }
}



//updateStudentsInFirestore
suspend fun updateStudentInFirestore(student: Student): Boolean = coroutineScope {
    val projectId = Database.projectId

    try {
        val firestoreUrl =
            "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/students/${student.regNo.replace("/", "_")}"

        val hashedPassword = hashPassword(student.regNo) // optional, depending on your logic

        val firestorePayload = FirestoreDocument(
            fields = FirestoreFields(
                studentName = FirestoreStringValue(student.studentName),
                regNo = FirestoreStringValue(student.regNo),
                gender = FirestoreStringValue(student.gender),
                ntaLevel = FirestoreStringValue(student.ntaLevel),
                semester = FirestoreStringValue(student.semester),
                program = FirestoreStringValue(student.program),
                passHash = FirestoreStringValue(hashedPassword),
                intake = FirestoreStringValue(student.intake),
                status = FirestoreStringValue(student.status)
            )
        )

        NetworkClient.http.patch(firestoreUrl) {
            contentType(ContentType.Application.Json)
            setBody(firestorePayload)
        }

        println("✅ Student updated successfully")
        true
    } catch (e: Exception) {
        println("❌ Error updating student: ${e.message}")
        false
    }
}

//Add Absence
suspend fun addAbsenceToFirestore(
    absence: AbsenceFields
): Boolean = coroutineScope {
    val projectId = Database.projectId

    // unique doc id (student + module + date)
    val docId = "${absence.studentRegNo.stringValue}_${absence.moduleCode.stringValue}_${absence.absenceDate.stringValue}"
        .replace("/", "_")

    val url = "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/absent/$docId"

    val payload = AbsenceDocument(fields = absence)

    return@coroutineScope try {
        NetworkClient.http.patch(url) {
            contentType(ContentType.Application.Json)
            setBody(payload)
        }
        println("✅ Absence record added: ${absence.studentRegNo.stringValue}")
        true
    } catch (e: Exception) {
        println("❌ Failed to add absence record: ${e.message}")
        false
    }
}

//fetch absence
suspend fun fetchAbsencesForModule(
    moduleCode: String,
    academicYear: String
): List<String> = coroutineScope {
    val projectId = Database.projectId
    val url = "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents:runQuery"

    val queryPayload = buildJsonObject {
        putJsonObject("structuredQuery") {
            putJsonArray("from") {
                add(buildJsonObject { put("collectionId", "absent") })
            }
            putJsonObject("where") {
                putJsonObject("compositeFilter") {
                    put("op", "AND")
                    putJsonArray("filters") {
                        add(buildJsonObject {
                            putJsonObject("fieldFilter") {
                                putJsonObject("field") { put("fieldPath", "moduleCode") }
                                put("op", "EQUAL")
                                putJsonObject("value") { put("stringValue", moduleCode) }
                            }
                        })
                        add(buildJsonObject {
                            putJsonObject("fieldFilter") {
                                putJsonObject("field") { put("fieldPath", "academicYear") }
                                put("op", "EQUAL")
                                putJsonObject("value") { put("stringValue", academicYear) }
                            }
                        })
                    }
                }
            }
        }
    }

    try {
        val response: JsonArray = NetworkClient.http.post(url) {
            contentType(ContentType.Application.Json)
            setBody(queryPayload)
        }.body()

        response.mapNotNull { jsonElement ->
            jsonElement.jsonObject["document"]
                ?.jsonObject
                ?.get("fields")
                ?.jsonObject
                ?.get("studentRegNo")
                ?.jsonObject
                ?.get("stringValue")
                ?.jsonPrimitive
                ?.content
        }
    } catch (e: Exception) {
        println("❌ Failed to fetch absences for $moduleCode in $academicYear: ${e.message}")
        emptyList()
    }
}


