
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.coroutines.coroutineScope
import kotlinx.serialization.json.*

//adding student to firestore
suspend fun addStudentToFirestoreAndAuth(student: Student): Boolean = coroutineScope {
    val projectId = Database.projectId
    val firebaseApiKey = Database.firebaseAPIKey

    val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    val lastName = student.studentName.trim().split("\\s+".toRegex()).lastOrNull()
    if (lastName.isNullOrBlank()) {
        println("❌ Cannot extract last name from '${student.studentName}'")
        return@coroutineScope false
    }

    val email = "${student.regNo.replace("/", "").lowercase()}@gmail.com"
    val plainPassword = if (lastName.length < 6) lastName.padEnd(6, '1') else lastName
    val hashedPassword = hashPassword(plainPassword)

    // Step 1: Firebase Auth
    val authResult = try {
        val authResponse: HttpResponse = client.post("https://identitytoolkit.googleapis.com/v1/accounts:signUp") {
            parameter("key", firebaseApiKey)
            contentType(ContentType.Application.Json)
            setBody(FirebaseAuthRequest(email, plainPassword))
        }

        val responseText = authResponse.bodyAsText()
        if (authResponse.status == HttpStatusCode.OK) {
            println("✅ Firebase Auth user created: $email | Password: $plainPassword")
        } else {
            println("⚠️ Firebase Auth response: ${authResponse.status}")
            println("🔍 Firebase response body: $responseText")
        }

        true
    } catch (e: Exception) {
        val message = e.message ?: ""
        if ("EMAIL_EXISTS" in message) {
            println("⚠️ User already exists in Firebase Auth: $email")
            true
        } else {
            println("❌ Auth error: $message")
            false
        }
    }

    if (!authResult) {
        client.close()
        return@coroutineScope false
    }

    // Step 2: Firestore
    val firestoreUrl =
        "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/students/${student.regNo.replace("/", "_")}"

    val firestorePayload = FirestoreDocument(
        fields = FirestoreFields(
            studentName = FirestoreStringValue(student.studentName),
            regNo = FirestoreStringValue(student.regNo),
            gender = FirestoreStringValue(student.gender),
            ntaLevel = FirestoreStringValue(student.ntaLevel),
            semester = FirestoreStringValue(student.semester),
            program = FirestoreStringValue(student.program),
            passHash = FirestoreStringValue(hashedPassword),
            intake = FirestoreStringValue(student.intake),
        )
    )

    try {
        client.patch(firestoreUrl) {
            contentType(ContentType.Application.Json)
            setBody(firestorePayload)
        }

        println("✅ Student added to Firestore")
        true
    } catch (e: Exception) {
        println("❌ Failed to add to Firestore: ${e.message}")
        false
    } finally {
        client.close()
    }
}
//deleting student
suspend fun onDeleteStudent(student: Student): Boolean = coroutineScope {
    val projectId = Database.projectId
    val client = HttpClient(CIO)

    val firestoreUrl = "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/students/${student.regNo.replace("/", "_")}"

    try {
        client.delete(firestoreUrl)
        println("✅ Student deleted successfully")
        true
    } catch (e: Exception) {
        println("❌ Failed to delete student: ${e.message}")
        false
    } finally {
        client.close()
    }
}
//fetch from students
suspend fun fetchStudentsFromFirestore(): List<Student> = coroutineScope {
    val projectId = Database.projectId
    val client = HttpClient(CIO) {
        install(ContentNegotiation) { json(Json { ignoreUnknownKeys = true }) }
    }

    val baseUrl = "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/students"

    val allStudents = mutableListOf<Student>()
    var nextPageToken: String? = null

    try {
        do {
            val url = buildString {
                append("$baseUrl?pageSize=300")
                nextPageToken?.let { append("&pageToken=$it") }
            }

            val response: JsonObject = client.get(url).body()
            val documents = response["documents"]?.jsonArray ?: JsonArray(emptyList())
            nextPageToken = response["nextPageToken"]?.jsonPrimitive?.contentOrNull

            val students = documents.mapNotNull { doc ->
                try {
                    val fields = doc.jsonObject["fields"]?.jsonObject ?: return@mapNotNull null
                    val id = fields["id"]?.jsonObject?.get("integerValue")?.jsonPrimitive?.intOrNull
                    val studentName = fields["studentName"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: return@mapNotNull null
                    val regNo = fields["regNo"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""
                    val gender = fields["gender"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""
                    val ntaLevel = fields["ntaLevel"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""
                    val semester = fields["semester"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""
                    val program = fields["program"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""
                    val intake = fields["intake"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""

                    Student(
                        id = id ?: 0,
                        studentName = studentName,
                        regNo = regNo,
                        gender = gender,
                        ntaLevel = ntaLevel,
                        semester = semester,
                        program = program,
                        intake = intake
                    )
                } catch (e: Exception) {
                    println("⚠️ Failed to parse student: ${e.message}")
                    null
                }
            }

            allStudents.addAll(students)

        } while (nextPageToken != null)

        allStudents
    } catch (e: Exception) {
        println("❌ Failed to fetch students: ${e.message}")
        emptyList()
    } finally {
        client.close()
    }
}

//updateStudentsInFirestore
suspend fun updateStudentInFirestore(student: Student): Boolean = coroutineScope {
    val projectId = Database.projectId
    val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    try {
        val firestoreUrl =
            "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/students/${student.regNo.replace("/", "_")}"

        val hashedPassword = hashPassword(student.regNo) // if needed for password updates

        val firestorePayload = FirestoreDocument(
            fields = FirestoreFields(
                studentName = FirestoreStringValue(student.studentName),
                regNo = FirestoreStringValue(student.regNo),
                gender = FirestoreStringValue(student.gender),
                ntaLevel = FirestoreStringValue(student.ntaLevel),
                semester = FirestoreStringValue(student.semester),
                program = FirestoreStringValue(student.program),
                passHash = FirestoreStringValue(hashedPassword),
                intake = FirestoreStringValue(student.intake),
            )
        )

        client.patch(firestoreUrl) {
            contentType(ContentType.Application.Json)
            setBody(firestorePayload)
        }

        println("✅ Student updated successfully")
        true
    } catch (e: Exception) {
        println("❌ Error updating student: ${e.message}")
        false
    } finally {
        client.close()
    }
}
//Add Absence
suspend fun addAbsenceToFirestore(
    absence: AbsenceFields
): Boolean = coroutineScope {
    val projectId = Database.projectId
    val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    val docId = "${absence.studentRegNo.stringValue}_${absence.moduleCode.stringValue}_${absence.absenceDate.stringValue}"
        .replace("/", "_")

    val url = "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/absent/$docId"

    val payload = AbsenceDocument(fields = absence)

    try {
        client.patch(url) {
            contentType(ContentType.Application.Json)
            setBody(payload)
        }
        println("✅ Absence record added: ${absence.studentRegNo.stringValue}")
        true
    } catch (e: Exception) {
        println("❌ Failed to add absence record: ${e.message}")
        false
    } finally {
        client.close()
    }
}
//fetch absence
suspend fun fetchAbsencesForModule(moduleCode: String, academicYear: String): List<String> = coroutineScope {
    val projectId = Database.projectId
    val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    val url = "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents:runQuery"

    val queryPayload = buildJsonObject {
        putJsonObject("structuredQuery") {
            putJsonArray("from") {
                add(buildJsonObject {
                    put("collectionId", "absent")
                })
            }
            putJsonObject("where") {
                // composite filter for moduleCode AND academicYear
                putJsonObject("compositeFilter") {
                    put("op", "AND")
                    putJsonArray("filters") {
                        // filter for moduleCode
                        add(buildJsonObject {
                            putJsonObject("fieldFilter") {
                                putJsonObject("field") { put("fieldPath", "moduleCode") }
                                put("op", "EQUAL")
                                putJsonObject("value") { put("stringValue", moduleCode) }
                            }
                        })
                        // filter for academicYear
                        add(buildJsonObject {
                            putJsonObject("fieldFilter") {
                                putJsonObject("field") { put("fieldPath", "academicYear") }
                                put("op", "EQUAL")
                                putJsonObject("value") { put("stringValue", academicYear) }
                            }
                        })
                    }
                }
            }
        }
    }

    try {
        // Deserialize response as JsonArray
        val response: JsonArray = client.post(url) {
            contentType(ContentType.Application.Json)
            setBody(queryPayload)
        }.body()

        // Extract studentRegNo strings from each document in the response
        val regNos = response.mapNotNull { jsonElement ->
            val doc = jsonElement.jsonObject["document"]?.jsonObject
            val fields = doc?.get("fields")?.jsonObject
            val studentRegNoField = fields?.get("studentRegNo")?.jsonObject
            studentRegNoField?.get("stringValue")?.jsonPrimitive?.content
        }

        regNos
    } catch (e: Exception) {
        println("❌ Failed to fetch absences: ${e.message}")
        emptyList()
    } finally {
        client.close()
    }
}
