
import FirebaseAuthResponse
import FirestoreArray
import FirestoreGradeDocument
import FirestoreGradesListResponse
import FirestoreList
import FirestoreString
import Grade
import ModuleDocument
import ModuleFields
import components.Constants
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.coroutines.coroutineScope
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.*
import java.security.MessageDigest
@Serializable
data class SignInRequest(
    val email: String,
    val password: String,
    val returnSecureToken: Boolean = true
)
object Database {
    val projectId = "chatter-b4660"
    val firebaseAPIKey = "AIzaSyDkm4Yo-J6nAauKquRvWnEDWDPUDrT74kk"
}
suspend fun signWithEmail(email: String, password: String): String? {
    val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    return try {
        val response: FirebaseAuthResponse = client.post(
            "https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=${Database.firebaseAPIKey}"
        ) {
            contentType(ContentType.Application.Json)
            setBody(SignInRequest(email, password))
        }.body()

        response.idToken
    } catch (e: Exception) {
        e.printStackTrace()
        null
    } finally {
        client.close()
    }
}

fun hashPassword(password: String): String {
    val digest = MessageDigest.getInstance("SHA-256")
    val hashedBytes = digest.digest(password.toByteArray())
    return hashedBytes.joinToString("") { "%02x".format(it) }
}
sealed class FirestoreValue {
    @Serializable
    @SerialName("stringValue")
    data class StringVal(val stringValue: String) : FirestoreValue()

    companion object {
        fun extractString(value: FirestoreValue?): String? = when (value) {
            is StringVal -> value.stringValue
            else -> null
        }
    }
}






//**********************************Module Section***************************************
//adding modules to firestore
suspend fun addModuleToFirestore(module: Module): Boolean = coroutineScope {
    val projectId = Database.projectId
    val docId = module.code.replace("/", "_")
    val url = "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/modules/$docId"

    // Step 1: Firestore duplicate check
    val exists = try {
        val checkResponse = NetworkClient.http.get(url)
        checkResponse.status == HttpStatusCode.OK
    } catch (e: Exception) {
        false
    }

    if (exists) {
        println("❌ Module already exists with code: ${module.code}")
        return@coroutineScope false // ⛔ Block duplicate
    }

    // Step 2: Firestore insert
    val payload = ModuleDocument(
        fields = ModuleFields(
            code = FirestoreString(module.code),
            name = FirestoreString(module.name),
            credit = FirestoreString(module.credit),
            level = FirestoreString(module.level),
            semester = FirestoreString(module.semester),
            courses = FirestoreArray(
                arrayValue = FirestoreList(
                    values = module.courses.map { FirestoreString(it) }
                )
            ),
            tutor = FirestoreString(module.tutor)
        )
    )

    try {
        NetworkClient.http.patch(url) {
            contentType(ContentType.Application.Json)
            setBody(payload)
        }
        println("✅ Module added to Firestore")
        true
    } catch (e: Exception) {
        println("❌ Failed to add module: ${e.message}")

        // Step 3: Rollback (delete module if partially created)
        try {
            NetworkClient.http.delete(url)
            println("🗑️ Rolled back module creation for code: ${module.code}")
        } catch (ex: Exception) {
            println("⚠️ Failed to rollback module: ${ex.message}")
        }

        false
    }
}


//deleting module
suspend fun onDeleteModule(module: Module): Boolean = coroutineScope {
    val projectId = Database.projectId

    val url =
        "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/modules/${module.code.replace("/", "_")}"

    try {
        NetworkClient.http.delete(url)
        println("✅ Module deleted successfully")
        true
    } catch (e: Exception) {
        println("❌ Failed to delete module: ${e.message}")
        false
    }
}

//fetch modules from firestore
suspend fun fetchModulesFromFirestore(): Collection<Module> = coroutineScope {
    val projectId = Database.projectId

    val url =
        "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/modules"

    try {
        val response: JsonObject = NetworkClient.http.get(url).body()
        val documents = response["documents"]?.jsonArray ?: return@coroutineScope emptyList()

        documents.mapNotNull { doc ->
            try {
                val fields = doc.jsonObject["fields"]?.jsonObject ?: return@mapNotNull null
                val code = fields["code"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: return@mapNotNull null
                val name = fields["name"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""
                val tutor = fields["tutor"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""
                val credit = fields["credit"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: "0.0"
                val courseArray = fields["courses"]?.jsonObject
                    ?.get("arrayValue")?.jsonObject
                    ?.get("values")?.jsonArray

                val courses = courseArray?.mapNotNull {
                    it.jsonObject["stringValue"]?.jsonPrimitive?.content
                } ?: emptyList()

                Module(code = code, name = name, credit = credit, courses = courses, tutor = tutor)
            } catch (e: Exception) {
                println("⚠️ Failed to parse module: ${e.message}")
                null
            }
        }.sortedBy { it.name.lowercase() }
    } catch (e: Exception) {
        println("❌ Failed to fetch modules: ${e.message}")
        emptyList()
    }
}


//update Module
suspend fun updateModuleInFirestore(module: Module): Boolean = coroutineScope {
    val projectId = Database.projectId

    try {
        val payload = buildJsonObject {
            put("fields", buildJsonObject {
                put("code", buildJsonObject { put("stringValue", module.code) })
                put("name", buildJsonObject { put("stringValue", module.name) })
                put("tutor", buildJsonObject { put("stringValue", module.tutor) })
                put("credit", buildJsonObject { put("stringValue", module.credit) })
                put("level", buildJsonObject { put("stringValue", module.level) })
                put("semester", buildJsonObject { put("stringValue", module.semester) })
                put("courses", buildJsonObject {
                    put("arrayValue", buildJsonObject {
                        put("values", JsonArray(module.courses.map {
                            buildJsonObject { put("stringValue", it) }
                        }))
                    })
                })
            })
        }

        val url =
            "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/modules/${module.code.replace("/", "_")}"

        NetworkClient.http.patch(url) {
            contentType(ContentType.Application.Json)
            setBody(payload)
        }

        println("✅ Module updated in Firestore")
        true
    } catch (e: Exception) {
        println("❌ Error updating module: ${e.message}")
        false
    }
}












