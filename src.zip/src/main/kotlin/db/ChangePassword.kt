import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

// Example: replace with your own Firebase constants
const val BASE_URL = "https://identitytoolkit.googleapis.com/v1/accounts"


suspend fun changePassword(newPassword: String): Boolean {
    val idToken = Global.idtoken.value ?: return false
    val userEmail = Global.currentEmail.value ?: return false

    return try {
        // 1️⃣ Change password via Firebase Auth REST API
        val response = NetworkClient.http.post("$BASE_URL:update?key=${Database.firebaseAPIKey}") {
            contentType(ContentType.Application.Json)
            setBody(ChangePasswordRequest(
                idToken = idToken,
                password = newPassword,
                returnSecureToken = true
            ))
        }

        if (response.status.isSuccess()) {
            val updated = response.body<FirebaseAuthResponse>()
            Global.idtoken.value = updated.idToken // update token

            // 2️⃣ Save new password to Firestore "credentials" collection
            val firestoreResponse = NetworkClient.http.patch(
                "https://firestore.googleapis.com/v1/projects/${Database.projectId}/databases/(default)/documents/credentials/${userEmail}"
            ) {
                contentType(ContentType.Application.Json)
                setBody(
                    buildJsonObject {
                        put("fields", buildJsonObject {
                            put("email", buildJsonObject { put("stringValue", userEmail) })
                            put("password", buildJsonObject { put("stringValue", newPassword) })
                        })
                    }
                )
            }

            if (firestoreResponse.status.isSuccess()) {
                println("✅ Password updated in Auth and Firestore")
                true
            } else {
                println("⚠️ Password updated in Auth but failed to update Firestore")
                true // Auth succeeded, so still return true
            }
        } else {
            val error = response.body<FirebaseErrorResponse>()
            println("❌ Failed to change password: ${error.error.message}")
            false
        }
    } catch (e: Exception) {
        e.printStackTrace()
        false
    }
}




@Serializable
data class FirebaseErrorResponse(
    val error: FirebaseErrorDetail
)

@Serializable
data class FirebaseErrorDetail(
    val code: Int,
    val message: String,
    val errors: List<FirebaseErrorItem>? = null
)

@Serializable
data class FirebaseErrorItem(
    val message: String,
    val domain: String? = null,
    val reason: String? = null
)
@Serializable
data class ChangePasswordRequest(
    val idToken: String,
    val password: String,
    val returnSecureToken: Boolean = true
)
