import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.coroutines.coroutineScope
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.*


@Serializable
data class PublishFields(
    val coursework: FirestoreString,
    val courseworkNtaLevel: FirestoreString,
    val courseworkSemester: FirestoreString,
    val results: FirestoreString,
    val resultsNtaLevel: FirestoreString,
    val resultsSemester: FirestoreString
)

@Serializable
data class PublishDocument(
    val fields: PublishFields
)
suspend fun updatePublishSettings(
    projectId: String,
    courseworkPublished: Boolean,
    courseworkNta: String,
    courseworkSem: String,
    resultsPublished: Boolean,
    resultsNta: String,
    resultsSem: String
): Boolean = coroutineScope {
    val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    val payload = PublishDocument(
        fields = PublishFields(
            coursework = FirestoreString(if (courseworkPublished) "allowed" else "pending"),
            courseworkNtaLevel = FirestoreString(courseworkNta),
            courseworkSemester = FirestoreString(courseworkSem),
            results = FirestoreString(if (resultsPublished) "allowed" else "pending"),
            resultsNtaLevel = FirestoreString(resultsNta),
            resultsSemester = FirestoreString(resultsSem)
        )
    )

    val url = "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/publish/settings"

    try {
        client.patch(url) {
            contentType(ContentType.Application.Json)
            setBody(payload)
        }
        println("✅ Updated publish settings")
        true
    } catch (e: Exception) {
        println("❌ Failed to update publish settings: ${e.message}")
        false
    } finally {
        client.close()
    }
}
// fetch from tutors
suspend fun fetchPublishFromFirestore(): List<Publish> = coroutineScope {
    val projectId = Database.projectId
    val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    val url =
        "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/publish"

    try {
        val response: JsonObject = client.get(url).body()
        val documents = response["documents"]?.jsonArray ?: return@coroutineScope emptyList()

        return@coroutineScope documents.mapNotNull { doc ->
            try {
                val fields = doc.jsonObject["fields"]?.jsonObject ?: return@mapNotNull null

                val coursework = fields["coursework"]?.jsonObject
                    ?.get("stringValue")?.jsonPrimitive?.content ?: return@mapNotNull null
                val courseworkNtaLevel = fields["courseworkNtaLevel"]?.jsonObject
                    ?.get("stringValue")?.jsonPrimitive?.content.orEmpty()
                val courseworkSemester = fields["courseworkSemester"]?.jsonObject
                    ?.get("stringValue")?.jsonPrimitive?.content.orEmpty()
                val results = fields["results"]?.jsonObject
                    ?.get("stringValue")?.jsonPrimitive?.content.orEmpty()
                val resultsNtaLevel = fields["resultsNtaLevel"]?.jsonObject
                    ?.get("stringValue")?.jsonPrimitive?.content.orEmpty()
                val resultsSemester = fields["resultsSemester"]?.jsonObject
                    ?.get("stringValue")?.jsonPrimitive?.content.orEmpty()

                Publish(
                    coursework = coursework,
                    courseworkNtaLevel = courseworkNtaLevel,
                    courseworkSemester = courseworkSemester,
                    results = results,
                    resultsNtaLevel = resultsNtaLevel,
                    resultsSemester = resultsSemester
                )

            } catch (e: Exception) {
                println("⚠️ Failed to parse Publish: ${e.message}")
                null
            }
        }
    } catch (e: Exception) {
        println("❌ Failed to fetch publish: ${e.message}")
        emptyList()
    } finally {
        client.close()
    }
}

