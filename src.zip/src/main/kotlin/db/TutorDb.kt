import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import io.ktor.http.*
import io.ktor.serialization.kotlinx.json.*
import kotlinx.coroutines.coroutineScope
import kotlinx.serialization.json.*

//adding student to firestore
suspend fun addTutorToFirestoreAndAuth(tutor: Tutor): Boolean = coroutineScope {
    val projectId = Database.projectId
    val firebaseApiKey = Database.firebaseAPIKey

    val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    val lastName = tutor.tutorName.trim().split("\\s+".toRegex()).lastOrNull() //use ad password initially
    if (lastName.isNullOrBlank()) {
        println("❌ Cannot extract last name from '${tutor.tutorName}'")
        return@coroutineScope false
    }
    val plainPassword = if (lastName.length < 6) lastName.padEnd(6, '1') else lastName
    // Step 1: Firebase Auth
    val authResult = try {
        val authResponse: HttpResponse = client.post("https://identitytoolkit.googleapis.com/v1/accounts:signUp") {
            parameter("key", firebaseApiKey)
            contentType(ContentType.Application.Json)
            setBody(FirebaseAuthRequest(tutor.email, plainPassword))
        }

        val responseText = authResponse.bodyAsText()
        if (authResponse.status == HttpStatusCode.OK) {
            println("✅ Firebase Auth user created: ${tutor.email} | Password: $plainPassword")
        } else {
            println("⚠️ Firebase Auth response: ${authResponse.status}")
            println("🔍 Firebase response body: $responseText")
        }

        true
    } catch (e: Exception) {
        val message = e.message ?: ""
        if ("EMAIL_EXISTS" in message) {
            println("⚠️ User already exists in Firebase Auth: ${tutor.email}")
            true
        } else {
            println("❌ Auth error: $message")
            false
        }
    }

    if (!authResult) {
        client.close()
        return@coroutineScope false
    }

    // Step 2: Firestore
    val firestoreUrl =
        "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/tutors/${tutor.email}"

    val firestorePayload = FirestoreTutorDocument(
        fields = FirestoreTutorFields(
            tutorName = FirestoreStringValue(tutor.tutorName),
            email = FirestoreStringValue(tutor.email),
            gender = FirestoreStringValue(tutor.gender),
            role = FirestoreStringValue(tutor.role),
            phone = FirestoreStringValue(tutor.phone),
            dept = FirestoreStringValue(tutor.dept),
        )
    )

    try {
        client.patch(firestoreUrl) {
            contentType(ContentType.Application.Json)
            setBody(firestorePayload)
        }

        println("✅ Tutor added to Firestore")
        true
    } catch (e: Exception) {
        println("❌ Failed to add to Firestore: ${e.message}")
        false
    } finally {
        client.close()
    }
}
//fetch the tutor role
suspend fun getTutorRoleByEmail(email: String): String? {
    val projectId = Database.projectId

    val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    val firestoreUrl =
        "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/tutors/${email.encodeURLPath()}"


    return try {
        val doc: FirestoreTutorDocument = client.get(firestoreUrl).body()
        doc.fields.role.stringValue

    } catch (e: Exception) {
        println("❌ Failed to fetch tutor role: ${e.message}")
        null
    } finally {
        client.close()
    }
}
//fetch the tutor Name
suspend fun getTutorNameByEmail(email: String): String? {
    val projectId = Database.projectId

    val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    val firestoreUrl =
        "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/tutors/$email"

    return try {
        val doc: FirestoreTutorDocument = client.get(firestoreUrl).body()
        val name = doc.fields?.tutorName?.stringValue
        println("✅ Found tutorName for $email → $name")
        name
    } catch (e: Exception) {
        println("❌ Failed to fetch tutor name: ${e.message}")
        null
    } finally {
        client.close()
    }
}
//deleting tutor
suspend fun onDeleteTutor(tutor: Tutor): Boolean = coroutineScope {
    val projectId = Database.projectId
    val client = HttpClient(CIO)

    val firestoreUrl = "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/tutors/${tutor.email}}"

    try {
        client.delete(firestoreUrl)
        println("✅ Tutor deleted successfully")
        true
    } catch (e: Exception) {
        println("❌ Failed to delete tutor: ${e.message}")
        false
    } finally {
        client.close()
    }
}
//fetch from tutors
suspend fun fetchTutorsFromFirestore(): List<Tutor> = coroutineScope {
    val projectId = Database.projectId
    val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json(Json { ignoreUnknownKeys = true })
        }
    }

    val baseUrl =
        "https://firestore.googleapis.com/v1/projects/$projectId/databases/(default)/documents/tutors"

    val tutors = mutableListOf<Tutor>()
    var pageToken: String? = null

    try {
        do {
            val url = buildString {
                append(baseUrl)
                if (pageToken != null) {
                    append("?pageToken=$pageToken")
                }
            }

            val response: JsonObject = client.get(url).body()
            val documents = response["documents"]?.jsonArray ?: JsonArray(emptyList())

            // Parse tutors
            tutors += documents.mapNotNull { doc ->
                try {
                    val fields = doc.jsonObject["fields"]?.jsonObject ?: return@mapNotNull null
                    val id = fields["id"]?.jsonObject?.get("integerValue")?.jsonPrimitive?.intOrNull
                    val tutorName = fields["tutorName"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content
                        ?: return@mapNotNull null
                    val role = fields["role"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""
                    val gender = fields["gender"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""
                    val email = fields["email"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""
                    val phone = fields["phone"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""
                    val dept = fields["dept"]?.jsonObject?.get("stringValue")?.jsonPrimitive?.content ?: ""

                    Tutor(
                        id = id ?: 0,
                        tutorName = tutorName,
                        role = role,
                        gender = gender,
                        email = email,
                        phone = phone,
                        dept = dept
                    )
                } catch (e: Exception) {
                    println("⚠️ Failed to parse tutor: ${e.message}")
                    null
                }
            }

            // Update pageToken if there are more results
            pageToken = response["nextPageToken"]?.jsonPrimitive?.contentOrNull
        } while (pageToken != null)

        tutors
    } catch (e: Exception) {
        println("❌ Failed to fetch tutors: ${e.message}")
        emptyList()
    } finally {
        client.close()
    }
}

