import androidx.compose.material.MaterialTheme
import androidx.compose.material.lightColors
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.WindowPlacement
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import db.Login

object Global{
    val role = mutableStateOf("")
    val currentEmail = mutableStateOf("")
    var refresh = mutableStateOf(false)
}
enum class Screen {
    Splash,
    Login,
    Main,
    Grading,
    Publish,
    Results,
    Manage,
    Promotion
}

fun main() = application {
    val students = remember { mutableStateListOf<Student>() }
    val modules = remember { mutableStateListOf<Module>() }
    val tutors = remember { mutableStateListOf<Tutor>() }
    val publish = remember { mutableStateListOf<Publish>() }
   // val grades = remember { mutableStateListOf<Grade>() }

    var currentScreen by remember { mutableStateOf(Screen.Splash) }

    Window(
        onCloseRequest = ::exitApplication,
        undecorated = true,
        state = rememberWindowState(
            placement = WindowPlacement.Maximized
        )
    ) {
        MaterialTheme(
            colors = lightColors(
                primary = Color(0xFF1976D2),
                primaryVariant = Color(0xFF1565C0),
                secondary = Color(0xFF26A69A)
            )
        ) {
            when (currentScreen) {
                Screen.Splash -> SplashScreen(
                    onFinish = { currentScreen = Screen.Login }
                )
                Screen.Login -> Login(
                    onFinish = { currentScreen = Screen.Main }
                )
                Screen.Promotion->Promotion(
                    onFinish = {currentScreen = Screen.Manage},
                    promotionList = students
                )
                Screen.Manage -> Manage(
                    onBack = {
                        currentScreen = Screen.Main

                    },
                    students = students,
                    tutors = tutors,
                    modules = modules,
                    onPublishResults = {currentScreen = Screen.Publish},
                    onViewResults = {currentScreen = Screen.Results},
                    publish = publish,
                    onAcademicPromotion = {currentScreen = Screen.Promotion}
                )
                Screen.Publish -> PublishScreen(
                    projectId = Database.projectId, // replace with your actual project ID
                    onBack = {
                        currentScreen = Screen.Manage
                    },
                    publish = publish
                )
                Screen.Results -> Results(
                    onBack = { currentScreen = Screen.Manage }
                )

                Screen.Main -> MainScreen(
                    students = students,
                    modules = modules,
                    tutors = tutors,
                    onGoToGrading = { currentScreen = Screen.Grading },
                    goToManage = {currentScreen = Screen.Manage},
                    publish = publish,
                    signout = {
                        currentScreen = Screen.Splash
                    }
                )
                Screen.Grading -> GradingScreen(
                    students = students,
                    modules = modules,
                    projectId = Database.projectId,
                    onBack = { currentScreen = Screen.Main }
                )
            }
        }
    }
}



