import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.WindowPlacement
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import db.Login

object Global{
    val role = mutableStateOf("")
    val currentEmail = mutableStateOf("")
    var refresh = mutableStateOf(false)
}
enum class Screen {
    Splash,
    Login,
    Main,
    Grading,
    Publish,
    Results,
    Manage,
    Promotion
}

fun main() = application {
    val students = remember { mutableStateListOf<Student>() }
    val modules = remember { mutableStateListOf<Module>() }
    val tutors = remember { mutableStateListOf<Tutor>() }
    val publish = remember { mutableStateListOf<Publish>() }
   // val grades = remember { mutableStateListOf<Grade>() }

    var currentScreen by remember { mutableStateOf(Screen.Splash) }
    var requestClose by remember {
        mutableStateOf(false)
    }


    Window(
        onCloseRequest = {
            requestClose = true
        },
        undecorated = true,
        state = rememberWindowState(
            placement = WindowPlacement.Maximized
        )
    ) {
        MaterialTheme(
            colors = lightColors(
                primary = Color(0xFF1976D2),
                primaryVariant = Color(0xFF1565C0),
                secondary = Color(0xFF26A69A)
            )
        ) {
            when (currentScreen) {
                Screen.Splash -> SplashScreen(
                    onFinish = { currentScreen = Screen.Login }
                )
                Screen.Login -> Login(
                    onFinish = { currentScreen = Screen.Main }
                )
                Screen.Promotion->Promotion(
                    onFinish = {currentScreen = Screen.Manage},
                    promotionList = students
                )
                Screen.Manage -> Manage(
                    onBack = {
                        currentScreen = Screen.Main

                    },
                    students = students,
                    tutors = tutors,
                    modules = modules,
                    onPublishResults = {currentScreen = Screen.Publish},
                    onViewResults = {currentScreen = Screen.Results},
                    publish = publish,
                    onAcademicPromotion = {currentScreen = Screen.Promotion}
                )
                Screen.Publish -> PublishDashboardScreen(
                    projectId = Database.projectId, // replace with your actual project ID
                    onBack = {
                        currentScreen = Screen.Manage
                    },
                    publish = publish
                )
                Screen.Results -> Results(
                    onBack = { currentScreen = Screen.Manage }
                )

                Screen.Main -> MainScreen(
                    students = students,
                    modules = modules,
                    tutors = tutors,
                    onGoToGrading = { currentScreen = Screen.Grading },
                    goToManage = {currentScreen = Screen.Manage},
                    publish = publish,
                    signout = {
                        currentScreen = Screen.Splash
                    }
                )
                Screen.Grading -> GradingScreen(
                    students = students,
                    modules = modules,
                    projectId = Database.projectId,
                    onBack = { currentScreen = Screen.Main }
                )
            }
        }
        //onCloseRequest = ::exitApplication
        //setting the close request dialog
        if (requestClose) {
            AlertDialog(
                onDismissRequest = { requestClose = false },
                title = {
                    Text(
                        "Exit Grademate",
                        color = GradeMateColors.Primary,
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Text(if(currentScreen != Screen.Login && currentScreen != Screen.Splash)"Exit Grademate? Unsaved changes will be lost." else "Exit Grademate ?")
                },
                confirmButton = {
                    Button(
                        colors = ButtonDefaults.buttonColors(
                            contentColor = GradeMateColors.Background,
                            backgroundColor = GradeMateColors.Primary
                        ),
                        onClick = {
                            exitApplication() // 👈 actually close app
                        }
                    ) {
                        Text("Yes")
                    }
                },
                dismissButton = {
                    Button(
                        colors = ButtonDefaults.buttonColors(
                            contentColor = GradeMateColors.Primary,
                            backgroundColor = GradeMateColors.Background
                        ),
                        onClick = { requestClose = false }
                    ) {
                        Text("No")
                    }
                }
            )
        }
    }
}



