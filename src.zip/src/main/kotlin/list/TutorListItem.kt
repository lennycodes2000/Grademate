import Tutor
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun TutorListItem(
    index: Int,
    tutor: Tutor,
    onEditClick: (Tutor) -> Unit,
    onTutorDeleted: (List<Tutor>) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Confirm Deletion") },
            text = { Text("Are you sure you want to delete '${tutor.tutorName}'?") },
            confirmButton = {
                TextButton(onClick = {
                    showDialog = false
                    coroutineScope.launch {
                        val success = onDeleteTutor(tutor)
                        if (success) {
                            val updatedTutors = fetchTutorsFromFirestore()
                            onTutorDeleted(updatedTutors)
                        }
                    }
                }) {
                    Text("Yes", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("No", fontWeight = FontWeight.Bold)
                }
            }
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp, horizontal = 12.dp),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        Box(
            modifier = Modifier
                .background(
                    Brush.horizontalGradient(
                        listOf(Color(0xFFE3F2FD), Color(0xFFF7FAFF))
                    ),
                    shape = RoundedCornerShape(16.dp)
                )
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Header
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        painter = painterResource("person.png"),
                        contentDescription = "Tutor Icon",
                        tint = GradeMateColors.Primary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "$index. ${tutor.tutorName} - ${tutor.email}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = GradeMateColors.Primary
                        )
                    )
                }

                // Metadata Chips
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AssistChip(
                        onClick = {}, label = { Text(tutor.gender) },
                        leadingIcon = { Icon(painter = painterResource("gender.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = null) }
                    )
                    AssistChip(
                        onClick = {}, label = { Text("Dept: ${tutor.dept}") },
                        leadingIcon = { Icon(painter = painterResource("dept.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = null) }
                    )
                    AssistChip(
                        onClick = {}, label = { Text(tutor.role) },
                        leadingIcon = { Icon(painter = painterResource("role.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = null) }
                    )
                    AssistChip(
                        onClick = {}, label = { Text(tutor.phone) },
                        leadingIcon = { Icon(painter = painterResource("phone.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = null) }
                    )
                }

                Divider(color = Color(0xFFE0E0E0), thickness = 1.dp)

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { onEditClick(tutor) },
                        enabled = !showDialog,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).height(44.dp)
                    ) {
                        Icon(painter = painterResource("edit.png"), contentDescription = "Edit Tutor")
                        Spacer(Modifier.width(6.dp))
                        Text("Update", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { showDialog = true },
                        enabled = !showDialog,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f).height(44.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(painter = painterResource("delete.png"),
                            contentDescription = "Delete Tutor")
                        Spacer(Modifier.width(6.dp))
                        Text("Delete", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
