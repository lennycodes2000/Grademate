import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch


@Composable
fun StudentListItem(
    index: Int,
    student: Student,
    onEditClick: (Student) -> Unit,
    onStudentDeleted: (List<Student>) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Confirm Deletion") },
            text = { Text("Are you sure you want to delete '${student.studentName}'?") },
            confirmButton = {
                TextButton(onClick = {
                    showDialog = false
                    coroutineScope.launch {
                        val success = onDeleteStudent(student)
                        if (success) {
                            val updatedStudents = fetchStudentsFromFirestore()
                            onStudentDeleted(updatedStudents)
                        }
                    }
                }) {
                    Text("Yes")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("No")
                }
            }
        )
    }

    Card(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 4.dp, horizontal = 8.dp),
        elevation = 3.dp,
        shape = RoundedCornerShape(8.dp),
        backgroundColor = Color(0xFFbbdefb)
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth()
            ,
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)

        ) {
            Text("$index.", fontWeight = FontWeight.Bold, modifier = Modifier.width(32.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(text = student.studentName+" - ${student.regNo}", fontWeight = FontWeight.SemiBold)
                Text(
                    text = "Gender: ${student.gender} • NTA: ${student.ntaLevel} • Semester: ${student.semester} • ${student.program}",
                    style = MaterialTheme.typography.caption,
                    color = Color(0xFF37474F)
                )
            }

            Button(
                onClick = { onEditClick(student) },
                modifier = Modifier.height(40.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    backgroundColor = MaterialTheme.colors.primary,
                    contentColor = Color.White
                )
            ) {
                Text("Update", fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = { showDialog = true },
                modifier = Modifier.height(40.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    backgroundColor = MaterialTheme.colors.error,
                    contentColor = Color.White
                )
            ) {
                Text("Delete", fontWeight = FontWeight.Bold)
            }
        }
    }
}