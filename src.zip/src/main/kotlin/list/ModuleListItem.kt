import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun ModuleListItem(
    index: Int,
    module: Module,
    onEditClick: (Module) -> Unit,
    onModulesUpdated: (List<Module>) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var isDeleting by remember { mutableStateOf(false) }
    var tutorName by remember { mutableStateOf<String?>(null) }

    // Fetch tutor name
    LaunchedEffect(module.tutor) {
        tutorName = getTutorNameByEmail(module.tutor)
    }

    val coroutineScope = rememberCoroutineScope()

    if (showDialog) {
        DeleteConfirmationDialog(
            module = module,
            onConfirm = {
                showDialog = false
                isDeleting = true
                coroutineScope.launch {
                    val success = onDeleteModule(module)
                    if (success) {
                        val updatedModules = fetchModulesFromFirestore()
                        onModulesUpdated(updatedModules.toList())
                    }
                    isDeleting = false
                }
            },
            onDismiss = { showDialog = false }
        )
    }

    if (!isDeleting) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp, horizontal = 14.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color.Transparent
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            // Gradient Background
            Box(
                modifier = Modifier
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0xFFE3F2FD), Color(0xFFF7FAFF))
                        ),
                        shape = RoundedCornerShape(20.dp)
                    )
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Header
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            painter = painterResource("book.png"),
                            contentDescription = "Module",
                            tint = GradeMateColors.Primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = "$index. ${module.code} - ${module.name}",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 19.sp,
                                color = GradeMateColors.Primary
                            )
                        )
                    }
                     //metadatachips
                    ModuleMetadataChips(module)

                    // Courses
                    Column {
                        Text(
                            text = "Courses",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = GradeMateColors.Primary
                            )
                        )
                        Text(
                            text = module.courses.joinToString(),
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 14.sp,
                                color = Color.DarkGray
                            )
                        )
                    }

                    // Tutor
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            painter = painterResource("person.png"),
                            contentDescription = "Tutor",
                            tint = Color(0xFF37474F),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        if (tutorName == null) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("Fetching tutor…", fontSize = 13.sp, color = Color.Gray)
                        } else {
                            Text(
                                text = "Tutor: $tutorName",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Medium,
                                    color = Color(0xFF37474F)
                                )
                            )
                        }
                    }

                    // Divider + Actions
                    Divider(color = Color(0xFFE0E0E0), thickness = 1.dp)
                       if(Global.role.value == "Admin" || Global.role.value == "HOD"){
                           Row(
                               modifier = Modifier.fillMaxWidth(),
                               horizontalArrangement = Arrangement.spacedBy(12.dp),
                               verticalAlignment = Alignment.CenterVertically
                           ) {
                               OutlinedButton(
                                   onClick = { onEditClick(module) },
                                   enabled = !isDeleting,
                                   shape = RoundedCornerShape(12.dp),
                                   modifier = Modifier.weight(1f).height(45.dp)
                               ) {
                                   Icon(painter = painterResource("edit.png"),
                                       modifier = Modifier.size(20.dp),
                                       contentDescription = "Edit")
                                   Spacer(Modifier.width(6.dp))
                                   Text("Update", fontWeight = FontWeight.Bold)
                               }

                               Button(
                                   onClick = { showDialog = true },
                                   enabled = !isDeleting,
                                   shape = RoundedCornerShape(12.dp),
                                   modifier = Modifier.weight(1f).height(45.dp),
                                   colors = ButtonDefaults.buttonColors(
                                       containerColor = MaterialTheme.colorScheme.error,
                                       contentColor = Color.White
                                   )
                               ) {
                                   if (isDeleting) {
                                       CircularProgressIndicator(
                                           modifier = Modifier.size(20.dp),
                                           color = Color.White,
                                           strokeWidth = 2.dp
                                       )
                                   } else {
                                       Icon(painter = painterResource("delete.png"),
                                           modifier = Modifier.size(20.dp),
                                           contentDescription = "Delete")
                                       Spacer(Modifier.width(6.dp))
                                       Text("Delete", fontWeight = FontWeight.Bold)
                                   }
                               }
                           }
                       }

                }
            }
        }
    }
}



