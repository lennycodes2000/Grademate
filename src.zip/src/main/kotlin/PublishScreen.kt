import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@Composable
fun PublishScreen(
    projectId: String,
    onBack: () -> Unit,
    publish: SnapshotStateList<Publish>,

    ) {
    var courseworkPublished by remember { mutableStateOf(true) }
    var courseworkNta by remember { mutableStateOf("4") }
    var courseworkSem by remember { mutableStateOf("1") }

    var resultsPublished by remember { mutableStateOf(true) }
    var resultsNta by remember { mutableStateOf("4") }
    var resultsSem by remember { mutableStateOf("1") }

    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp)
    ) {
        LaunchedEffect(Unit){
            publish.clear()
            val publishList = fetchPublishFromFirestore()
            publish.addAll(publishList)
            println(publishList.toString())
            //setting the start values for publis results
            if(publish.isNotEmpty()){
               courseworkPublished = publish[0].coursework == "allowed"
                courseworkNta = publish[0].courseworkNtaLevel
                courseworkSem = publish[0].courseworkSemester
                resultsPublished = publish[0].results == "allowed"
                resultsNta = publish[0].resultsNtaLevel
                resultsSem = publish[0].resultsSemester
            }
        }
        // Top bar
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = GradeMateColors.Primary)
            ) {
                Text("⬅ Go Back", color = GradeMateColors.Background)
            }
            Spacer(modifier = Modifier.width(20.dp))
            Text(
                "Results Publication",
                style = MaterialTheme.typography.headlineMedium,
                color = GradeMateColors.Primary,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Coursework Section Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            if(publish.isNotEmpty()){
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        "Coursework Publication",
                        style = MaterialTheme.typography.headlineSmall,
                        color = GradeMateColors.Primary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = courseworkPublished,
                            onCheckedChange = {
                                courseworkPublished = it
                                scope.launch {
                                    updatePublishSettings(
                                        projectId,
                                        courseworkPublished, courseworkNta, courseworkSem,
                                        resultsPublished, resultsNta, resultsSem
                                    )
                                }
                            }
                        )
                        Text(
                            "Publish Coursework",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                        DropdownSelectorPublish(
                            label = "NTA Level",
                            options = listOf("4", "5", "6","All"),
                            selected = courseworkNta,
                            onSelect = {
                                courseworkNta = it
                                scope.launch {
                                    updatePublishSettings(
                                        projectId,
                                        courseworkPublished, courseworkNta, courseworkSem,
                                        resultsPublished, resultsNta, resultsSem
                                    )
                                }
                            }
                        )
                        DropdownSelectorPublish(
                            label = "Semester",
                            options = listOf("1", "2", "Both"),
                            selected = courseworkSem,
                            onSelect = {
                                courseworkSem = it
                                scope.launch {
                                    updatePublishSettings(
                                        projectId,
                                        courseworkPublished, courseworkNta, courseworkSem,
                                        resultsPublished, resultsNta, resultsSem
                                    )
                                }
                            }
                        )
                    }
                }
            }

        }

        Spacer(modifier = Modifier.height(32.dp))

        // Results Section Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    "Results Publication",
                    style = MaterialTheme.typography.headlineSmall,
                    color = GradeMateColors.Primary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = resultsPublished,
                        onCheckedChange = {
                            resultsPublished = it
                            scope.launch {
                                updatePublishSettings(
                                    projectId,
                                    courseworkPublished, courseworkNta, courseworkSem,
                                    resultsPublished, resultsNta, resultsSem
                                )
                            }
                        }
                    )
                    Text(
                        "Publish Results",
                        style = MaterialTheme.typography.bodyLarge
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                    DropdownSelectorPublish(
                        label = "NTA Level",
                        options = listOf("4", "5", "6","All"),
                        selected = resultsNta,
                        onSelect = {
                            resultsNta = it
                            scope.launch {
                                updatePublishSettings(
                                    projectId,
                                    courseworkPublished, courseworkNta, courseworkSem,
                                    resultsPublished, resultsNta, resultsSem
                                )
                            }
                        }
                    )
                    DropdownSelectorPublish(
                        label = "Semester",
                        options = listOf("1", "2", "Both"),
                        selected = resultsSem,
                        onSelect = {
                            resultsSem = it
                            scope.launch {
                                updatePublishSettings(
                                    projectId,
                                    courseworkPublished, courseworkNta, courseworkSem,
                                    resultsPublished, resultsNta, resultsSem
                                )
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun DropdownSelectorPublish(
    label: String,
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.height(4.dp))
        Box {
            Button(
                onClick = { expanded = true },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface),
                border = ButtonDefaults.outlinedButtonBorder,
                modifier = Modifier.width(140.dp)
            ) {
                Text(selected)
            }
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option) },
                        onClick = {
                            onSelect(option)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}


