import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PublishDashboardScreen(
    projectId: String,
    onBack: () -> Unit,
    publish: SnapshotStateList<Publish>,
) {
    var courseworkPublished by remember { mutableStateOf(true) }
    var courseworkNta by remember { mutableStateOf("4") }
    var courseworkSem by remember { mutableStateOf("1") }

    var resultsPublished by remember { mutableStateOf(true) }
    var resultsNta by remember { mutableStateOf("4") }
    var resultsSem by remember { mutableStateOf("1") }

    val scope = rememberCoroutineScope()
    var selectedTab by remember { mutableStateOf(0) }
    val tabData = listOf(
        "Coursework" to painterResource("assign.png"),
        "Results" to painterResource("results.png")
    )

    LaunchedEffect(Unit) {
        publish.clear()
        val publishList = fetchPublishFromFirestore()
        publish.addAll(publishList)

        if (publish.isNotEmpty()) {
            courseworkPublished = publish[0].coursework == "allowed"
            courseworkNta = publish[0].courseworkNtaLevel
            courseworkSem = publish[0].courseworkSemester
            resultsPublished = publish[0].results == "allowed"
            resultsNta = publish[0].resultsNtaLevel
            resultsSem = publish[0].resultsSemester
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("📊 Publish Dashboard", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(painterResource("back.png"),
                            tint = Color.White,
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = GradeMateColors.Primary)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = GradeMateColors.Primary,
                indicator = { tabPositions ->
                    TabRowDefaults.Indicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = GradeMateColors.Primary,
                        height = 4.dp
                    )
                }
            ) {
                tabData.forEachIndexed { index, (title, icon) ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = { Text(title, fontWeight = FontWeight.Medium) },
                        icon = { Image(icon, modifier = Modifier.size(30.dp), contentDescription = title) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            when (selectedTab) {
                0 -> CourseworkTab(courseworkPublished, courseworkNta, courseworkSem, projectId,
                    onPublishedChange = {
                        courseworkPublished = it
                        scope.launch { updatePublishSettings(projectId, courseworkPublished, courseworkNta, courseworkSem, resultsPublished, resultsNta, resultsSem) }
                    },
                    onNtaChange = {
                        courseworkNta = it
                        scope.launch { updatePublishSettings(projectId, courseworkPublished, courseworkNta, courseworkSem, resultsPublished, resultsNta, resultsSem) }
                    },
                    onSemChange = {
                        courseworkSem = it
                        scope.launch { updatePublishSettings(projectId, courseworkPublished, courseworkNta, courseworkSem, resultsPublished, resultsNta, resultsSem) }
                    }
                )

                1 -> ResultsTab(resultsPublished, resultsNta, resultsSem, projectId,
                    onPublishedChange = {
                        resultsPublished = it
                        scope.launch { updatePublishSettings(projectId, courseworkPublished, courseworkNta, courseworkSem, resultsPublished, resultsNta, resultsSem) }
                    },
                    onNtaChange = {
                        resultsNta = it
                        scope.launch { updatePublishSettings(projectId, courseworkPublished, courseworkNta, courseworkSem, resultsPublished, resultsNta, resultsSem) }
                    },
                    onSemChange = {
                        resultsSem = it
                        scope.launch { updatePublishSettings(projectId, courseworkPublished, courseworkNta, courseworkSem, resultsPublished, resultsNta, resultsSem) }
                    }
                )
            }
        }
    }
}

@Composable
fun CourseworkTab(
    published: Boolean,
    nta: String,
    sem: String,
    projectId: String,
    onPublishedChange: (Boolean) -> Unit,
    onNtaChange: (String) -> Unit,
    onSemChange: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
            .padding(8.dp)
            .clip(MaterialTheme.shapes.medium),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(10.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("Coursework Publication",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
                color = GradeMateColors.Primary
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = published,
                    onCheckedChange = onPublishedChange,
                    colors = SwitchDefaults.colors(checkedThumbColor = GradeMateColors.Primary)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Publish Coursework", style = MaterialTheme.typography.bodyLarge)
            }
            Spacer(modifier = Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                DropdownSelectorPublish("NTA Level", listOf("4", "5", "6", "All"), nta, onNtaChange)
                DropdownSelectorPublish("Semester", listOf("1", "2", "Both"), sem, onSemChange)
            }
        }
    }
}

@Composable
fun ResultsTab(
    published: Boolean,
    nta: String,
    sem: String,
    projectId: String,
    onPublishedChange: (Boolean) -> Unit,
    onNtaChange: (String) -> Unit,
    onSemChange: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .animateContentSize()
            .padding(8.dp)
            .clip(MaterialTheme.shapes.medium),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(10.dp)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("Results Publication",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
                color = GradeMateColors.Primary
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(
                    checked = published,
                    onCheckedChange = onPublishedChange,
                    colors = SwitchDefaults.colors(checkedThumbColor = GradeMateColors.Primary)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Publish Results", style = MaterialTheme.typography.bodyLarge)
            }
            Spacer(modifier = Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                DropdownSelectorPublish("NTA Level", listOf("4", "5", "6", "All"), nta, onNtaChange)
                DropdownSelectorPublish("Semester", listOf("1", "2", "Both"), sem, onSemChange)
            }
        }
    }
}

@Composable
fun DropdownSelectorPublish(
    label: String,
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.height(4.dp))
        Box {
            Button(
                onClick = { expanded = true },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onSurface),
                border = ButtonDefaults.outlinedButtonBorder,
                modifier = Modifier.width(140.dp)
            ) {
                Text(selected)
            }
            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(option) },
                        onClick = {
                            onSelect(option)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}
