import androidx.compose.foundation.layout.*
import androidx.compose.material.Icon
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.delay

@Composable
fun TimedDialog(success: Boolean, onDismiss: () -> Unit) {
    var showDialog by remember { mutableStateOf(true) }

    val icon = if (success) "agree.svg" else "error.svg"
    val iconTint = if (!success)  MaterialTheme.colors.error else MaterialTheme.colors.primary

    // Auto-dismiss after 4 seconds
    LaunchedEffect(Unit) {
        delay(1500)
        showDialog = false
        onDismiss() // callback to tell parent that dialog was dismissed
    }

    if (showDialog) {
        Dialog(onDismissRequest = {
            showDialog = false
            onDismiss()
        }) {
            Surface(
                shape = MaterialTheme.shapes.medium,
                elevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .width(250.dp),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        painter = painterResource(icon),
                        tint = iconTint,
                        contentDescription = null,
                        modifier = Modifier.size(100.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (success) "Success!" else "Error!",
                        style = MaterialTheme.typography.h6
                    )
                }
            }
        }
    }
}
