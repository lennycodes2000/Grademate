
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.*

@Composable
fun GenerateSheetDialog(
    onDismiss: () -> Unit,
    onGenerate: (instructorName: String, hodName: String, examOfficerName: String) -> Unit
) {
    var instructorName by remember { mutableStateOf("") }
    val instructorNameRequest = remember {
        FocusRequester()
    }
    var hodName by remember { mutableStateOf("") }
    val hodNameRequest = remember {
        FocusRequester()
    }
    var examOfficerName by remember { mutableStateOf("") }
    val examOfficerRequest = remember {
        FocusRequester()
    }
    LaunchedEffect(Unit){
        instructorNameRequest.requestFocus()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Enter Sheet Details",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = Color(0xFF263238)
            )
        },
        text = {
            Column {
                OutlinedTextField(
                    value = instructorName.uppercase(Locale.getDefault()),
                    onValueChange = { instructorName = it },
                    label = { Text("Instructor's Name") },
                    modifier = Modifier.fillMaxWidth().focusRequester(instructorNameRequest),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = {hodNameRequest.requestFocus()}),
                    shape = RoundedCornerShape(14.dp),
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color(0xFF4A90E2),
                        focusedLabelColor = Color(0xFF4A90E2),
                        cursorColor = Color(0xFF4A90E2)
                    )
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = hodName.uppercase(Locale.getDefault()),
                    onValueChange = { hodName = it },
                    label = { Text("HOD's Name") },
                    modifier = Modifier.fillMaxWidth().focusRequester(hodNameRequest),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = {examOfficerRequest.requestFocus()}),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color(0xFF4A90E2),
                        focusedLabelColor = Color(0xFF4A90E2),
                        cursorColor = Color(0xFF4A90E2)
                    )
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = examOfficerName.uppercase(Locale.getDefault()),
                    onValueChange = { examOfficerName = it },
                    label = { Text("Examination Officer's Name") },
                    modifier = Modifier.fillMaxWidth().focusRequester(examOfficerRequest),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            if (instructorName.isNotBlank() && hodName.isNotBlank() && examOfficerName.isNotBlank()) {
                                onGenerate(instructorName.uppercase(Locale.getDefault()),
                                    hodName.uppercase(Locale.getDefault()), examOfficerName.uppercase(Locale.getDefault())
                                )
                            }
                        }),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color(0xFF4A90E2),
                        focusedLabelColor = Color(0xFF4A90E2),
                        cursorColor = Color(0xFF4A90E2)
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (instructorName.isNotBlank() && hodName.isNotBlank() && examOfficerName.isNotBlank()) {
                        onGenerate(instructorName.uppercase(Locale.getDefault()),
                            hodName.uppercase(Locale.getDefault()), examOfficerName.uppercase(Locale.getDefault())
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF4A90E2)),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.height(40.dp)
            ) {
                Text("Generate", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel", fontWeight = FontWeight.Medium)
            }
        },
        shape = RoundedCornerShape(20.dp),
        backgroundColor = Color(0xFFF9FAFB),
        modifier = Modifier.padding(24.dp)
    )
}