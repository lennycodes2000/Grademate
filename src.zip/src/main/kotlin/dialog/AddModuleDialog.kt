import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import components.Constants
import dialog.ModernDropdown


@Composable
fun AddModuleDialog(
    onDismiss: () -> Unit,
    onAddModule: (Module) -> Unit
) {
    val tutors = remember { mutableStateListOf<Tutor>() }



    var code by remember { mutableStateOf("") }
    var credit by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    val nameRequest = remember {
        FocusRequester()
    }
    val codeRequest = remember {
        FocusRequester()
    }
    val creditRequest = remember {
        FocusRequester()
    }
    val tutorRequest = remember {
        FocusRequester()
    }
    var selectedTutor by remember { mutableStateOf<Tutor?>(null) }
    val selectedCourses = remember { mutableStateListOf<String>() }

    val numericCode = extractNumbers(code)
    val level = numericCode.getOrNull(1)?.toString() ?: "-"
    val semester = numericCode.getOrNull(2)?.toString() ?: "-"
    LaunchedEffect(Unit) {
        codeRequest.requestFocus()
        val fetchedTutors = fetchTutorsFromFirestore()
        tutors.clear()
        tutors.addAll(fetchedTutors.sortedBy { it.tutorName })
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Add Module",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = GradeMateColors.Primary
                )
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val moduleCodePattern = Regex("""^[A-Z]{3}0[456]\d{3}$""")
                var code by remember { mutableStateOf("") }
                var isCodeValid by remember { mutableStateOf(true) }

                OutlinedTextField(
                    value = code.uppercase(),
                    onValueChange = { input ->
                        if(input.length <= 8){
                            code = input.uppercase()
                            isCodeValid = moduleCodePattern.matches(code)
                        }

                    },
                    label = { Text("Module Code") },
                    leadingIcon = {
                        Icon(
                            painter = painterResource("badge.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Module Code"
                        )
                    },
                    isError = code.isNotBlank() && !isCodeValid,
                    supportingText = {
                        if (code.isNotBlank() && !isCodeValid) {
                            Text(
                                "Invalid code format. Example: ITT04209",
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = {
                        nameRequest.requestFocus()
                    }),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(codeRequest),
                    singleLine = true
                )


                OutlinedTextField(
                    value = name.uppercase(),
                    onValueChange = { name = it },
                    label = { Text("Module Name") },
                    leadingIcon = {
                        Icon(
                            painter = painterResource("book.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Module Name"
                        )
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = {
                        creditRequest.requestFocus()
                    }),
                    modifier = Modifier.fillMaxWidth().focusRequester(nameRequest),
                    singleLine = true
                )

                OutlinedTextField(
                    value = credit,
                    onValueChange = { input ->
                        if (input.matches(Regex("^\\d{0,2}(\\.\\d?)?$")) || input.isEmpty()) {
                            credit = input
                        }
                    },
                    label = { Text("Module Credit") },
                    leadingIcon = {
                        Icon(
                            painter = painterResource("star.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Module Credit"
                        )
                    },
                    modifier = Modifier.fillMaxWidth().focusRequester(creditRequest),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
                )

                ModernDropdown(
                    label = "Tutor",
                    options = tutors.map { it.tutorName },
                    selected = selectedTutor?.tutorName ?: "",
                    leadingIcon = {
                        Icon(
                            painter = painterResource("person.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Tutor"
                        )
                    }
                ) { selectedName ->
                    selectedTutor = tutors.find { it.tutorName == selectedName }
                }


                Spacer(Modifier.height(8.dp))

                Text(
                    "Select Courses:",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                )
                var selectedCourse by remember { mutableStateOf<String?>(null) }

                Constants.moduleOption.forEach { course ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedCourse = if (selectedCourse == course) null else course
                            }
                            .padding(vertical = 4.dp)
                    ) {
                        Checkbox(
                            checked = selectedCourse == course,
                            onCheckedChange = {
                                selectedCourse = if (it) course else null
                            }
                        )
                        Text(course, fontSize = 16.sp)
                    }
                }

                Spacer(Modifier.height(8.dp))

                Text(
                    "NTA Level: $level    |    Semester: $semester",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                )
            }
        },
        confirmButton = {
            Button(
                colors = ButtonDefaults.buttonColors(
                    containerColor = GradeMateColors.Primary
                ),
                onClick = {
                    if (code.isNotBlank() && name.isNotBlank() && credit.isNotBlank() && selectedCourses.isNotEmpty()) {
                        onAddModule(
                            Module(
                                code = code.trim().uppercase(),
                                name = name.trim().uppercase(),
                                credit = credit.trim(),
                                courses = selectedCourses.toList(),
                                tutor = selectedTutor?.email.toString()
                            )
                        )
                        onDismiss()
                    }
                },
                modifier = Modifier.defaultMinSize(minWidth = 100.dp)
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

