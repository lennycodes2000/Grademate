import FirestoreArray
import FirestoreString
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import components.Constants
import kotlinx.serialization.Serializable

@Serializable
data class ModuleFields(
    val code: FirestoreString,
    val name: FirestoreString,
    val credit:FirestoreString,
    val level: FirestoreString,
    val semester: FirestoreString,
    val courses: FirestoreArray
)

@Serializable
data class ModuleDocument(val fields: ModuleFields)

// Your data classes here:
@Serializable
data class Module(val code: String, val name: String,val credit:String, val courses: List<String>) {
    val level: String get() = extractNumbers(code).getOrNull(1)?.toString() ?: "-"
    val semester: String get() = extractNumbers(code).getOrNull(2)?.toString() ?: "-"
}

// Utility to extract digits only from string:
fun extractNumbers(input: String) = input.filter { it.isDigit() }

@Composable
fun AddModuleDialog(
    onDismiss: () -> Unit,
    onAddModule: (Module) -> Unit
) {
    var code by remember { mutableStateOf("") }
    var credit by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    val selectedCourses = remember { mutableStateListOf<String>() }

    val numericCode = extractNumbers(code)
    val level = numericCode.getOrNull(1)?.toString() ?: "-"
    val semester = numericCode.getOrNull(2)?.toString() ?: "-"

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Add Module",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = Color(0xFF0277bd)
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = code.toUpperCase(),
                    onValueChange = { code = it },
                    label = { Text("Module Code") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = name.toUpperCase(),
                    onValueChange = { name = it },
                    label = { Text("Module Name") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = credit,
                    onValueChange = { input ->
                        if (input.matches(Regex("^\\d{0,2}(\\.\\d?)?$")) || input.isEmpty()) {
                            credit = input
                        }
                    },
                    label = { Text("Module Credit") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number),
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color(0xFF4A90E2),
                        focusedLabelColor = Color(0xFF4A90E2),
                        cursorColor = Color(0xFF4A90E2)
                    )
                )

                Spacer(Modifier.height(8.dp))
                Text(
                    "Select Courses:",
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF01579b)
                )
                Spacer(Modifier.height(8.dp))
                var selectedCourse by remember { mutableStateOf<String?>(null) }

                Constants.moduleCourseList.forEach { course ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedCourse = if (selectedCourse == course) null else course }
                            .padding(vertical = 4.dp)
                    ) {
                        Checkbox(
                            checked = selectedCourse == course,
                            onCheckedChange = {
                                selectedCourse = if (selectedCourse == course) null else course
                            }
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(course, fontSize = 16.sp)
                    }
                }

                Spacer(Modifier.height(16.dp))

                Text(
                    "NTA Level: $level    |    Semester: $semester",
                    style = MaterialTheme.typography.body2,
                    color = Color(0xFF01579b),
                    fontWeight = FontWeight.Medium
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (code.isNotBlank() && name.isNotBlank() && selectedCourses.isNotEmpty()) {
                        onAddModule(
                            Module(
                                code = code.trim().toUpperCase(),
                                name = name.trim().toUpperCase(),
                                credit = credit.trim(),
                                courses = selectedCourses.toList()
                            )
                        )
                        onDismiss()
                    }
                },
                modifier = Modifier.defaultMinSize(minWidth = 100.dp)
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}