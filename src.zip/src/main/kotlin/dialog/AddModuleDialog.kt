import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import components.Constants
import kotlinx.serialization.Serializable

@Serializable
data class ModuleFields(
    val code: FirestoreString,
    val name: FirestoreString,
    val credit: FirestoreString,
    val level: FirestoreString,
    val semester: FirestoreString,
    val courses: FirestoreArray,
    val tutor: FirestoreString
)

@Serializable
data class ModuleDocument(val fields: ModuleFields)

@Serializable
data class Module(
    val code: String,
    val name: String,
    val credit: String,
    val courses: List<String>,
    val tutor: String
) {
    val level: String get() = extractNumbers(code).getOrNull(1)?.toString() ?: "-"
    val semester: String get() = extractNumbers(code).getOrNull(2)?.toString() ?: "-"
}

fun extractNumbers(input: String) = input.filter { it.isDigit() }

@Composable
fun AddModuleDialog(
    onDismiss: () -> Unit,
    onAddModule: (Module) -> Unit
) {
    val tutors = remember { mutableStateListOf<Tutor>() }

    LaunchedEffect(Unit) {
        val fetchedTutors = fetchTutorsFromFirestore()
        tutors.clear()
        tutors.addAll(fetchedTutors.sortedBy { it.tutorName })
    }

    var code by remember { mutableStateOf("") }
    var credit by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var selectedTutor by remember { mutableStateOf<Tutor?>(null) }
    val selectedCourses = remember { mutableStateListOf<String>() }

    val numericCode = extractNumbers(code)
    val level = numericCode.getOrNull(1)?.toString() ?: "-"
    val semester = numericCode.getOrNull(2)?.toString() ?: "-"

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Add Module",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = code.uppercase(),
                    onValueChange = { code = it },
                    label = { Text("Module Code") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = name.uppercase(),
                    onValueChange = { name = it },
                    label = { Text("Module Name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = credit,
                    onValueChange = { input ->
                        if (input.matches(Regex("^\\d{0,2}(\\.\\d?)?$")) || input.isEmpty()) {
                            credit = input
                        }
                    },
                    label = { Text("Module Credit") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number)
                )

                Spacer(Modifier.height(8.dp))

                // Tutor dropdown
                DropdownMenuWithLabelModern(
                    label = "Tutor",
                    options = tutors.map { it.tutorName },
                    selectedOption = selectedTutor?.tutorName ?: "",
                    onOptionSelected = { index ->
                        selectedTutor = tutors[index]
                    },
                    modifier = Modifier.fillMaxWidth()
                )


                Spacer(Modifier.height(12.dp))

                Text(
                    "Select Courses:",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                )

                Spacer(Modifier.height(8.dp))
                var selectedCourse by remember { mutableStateOf<String?>(null) }
                Constants.moduleCourseList.forEach { course ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedCourse = if (selectedCourse == course) null else course
                            }
                            .padding(vertical = 4.dp)
                    ) {
                        Checkbox(
                            checked = selectedCourse == course,
                            onCheckedChange = {
                                selectedCourse = if (it) course else null
                            }
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(course, fontSize = 16.sp)
                    }
                }

                Spacer(Modifier.height(16.dp))

                Text(
                    "NTA Level: $level    |    Semester: $semester",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (code.isNotBlank() && name.isNotBlank() && selectedCourses.isNotEmpty()) {
                        onAddModule(
                            Module(
                                code = code.trim().uppercase(),
                                name = name.trim().uppercase(),
                                credit = credit.trim(),
                                courses = selectedCourses.toList(),
                                tutor = selectedTutor?.email.toString()
                            )
                        )
                        onDismiss()
                    }
                },
                modifier = Modifier.defaultMinSize(minWidth = 100.dp)
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
