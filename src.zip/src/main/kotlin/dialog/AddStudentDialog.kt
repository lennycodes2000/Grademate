package dialog

import components.DropdownMenuWithLabel
import Student
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import components.Constants
import components.Constants.courseList
import components.Constants.genders
import components.Constants.intake
import components.Constants.ntaLevels
import components.Constants.semesters
import java.util.*

@Composable
fun AddStudentDialog(
    onDismiss: () -> Unit,
    onAddStudent: (Student) -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    val fullNameRequester = remember { FocusRequester() }

    var regNo by remember { mutableStateOf("") }
    val regNoRequester = remember { FocusRequester() }

    val regNoPattern = Regex("^[A-Z]{2}\\d{4}/\\d{4}/\\d{4}$")
    val isRegNoValid = regNo.matches(regNoPattern)
    val showRegNoError = regNo.isNotBlank() && !isRegNoValid

    var gender by remember { mutableStateOf(genders[0]) }
    val genderRequester = remember { FocusRequester() }

    var ntaLevel by remember { mutableStateOf(ntaLevels[0]) }
    val ntaRequester = remember { FocusRequester() }

    var semester by remember { mutableStateOf(semesters[0]) }
    val semesterRequester = remember { FocusRequester() }
    var selectedIntake by remember { mutableStateOf(intake[0]) }
    val intakeRequester = remember { FocusRequester() }
    var course by remember { mutableStateOf(courseList[0]) }
    val courseRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        fullNameRequester.requestFocus()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Add Student",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = Color(0xFF0277bd)
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = fullName.uppercase(),
                    onValueChange = { fullName = it },
                    label = { Text("Full Name") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(
                        onNext = { regNoRequester.requestFocus() }
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(fullNameRequester)
                )

                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = regNo.uppercase(Locale.getDefault()),
                    onValueChange = { regNo = it },
                    label = { Text("Registration Number") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { genderRequester.requestFocus() }),
                    isError = showRegNoError,
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(regNoRequester)
                )
                if (showRegNoError) {
                    Text(
                        text = "Invalid format. Use NS2345/0076/2022",
                        color = Color.Red,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }

                Spacer(Modifier.height(8.dp))

                DropdownMenuWithLabel(
                    label = "Gender",
                    options = genders,
                    selectedOption = gender,
                    onOptionSelected = { gender = genders[it] },
                    currentAction = genderRequester,
                    nextAction = { ntaRequester.requestFocus() }
                )

                Spacer(Modifier.height(8.dp))

                DropdownMenuWithLabel(
                    label = "NTA Level",
                    options = ntaLevels,
                    selectedOption = ntaLevel,
                    onOptionSelected = { ntaLevel = ntaLevels[it] },
                    currentAction = ntaRequester,
                    nextAction = { semesterRequester.requestFocus() }
                )

                Spacer(Modifier.height(8.dp))

                DropdownMenuWithLabel(
                    label = "Semester",
                    options = semesters,
                    selectedOption = semester,
                    onOptionSelected = { semester = semesters[it] },
                    currentAction = semesterRequester,
                    nextAction = { intakeRequester.requestFocus() }
                )

                Spacer(Modifier.height(8.dp))
                DropdownMenuWithLabel(
                    label = "Academic Intake",
                    options = intake,
                    selectedOption = selectedIntake,
                    onOptionSelected = { selectedIntake = intake[it] },
                    currentAction = intakeRequester,
                    nextAction = { courseRequester.requestFocus() }
                )
                Spacer(Modifier.height(8.dp))

                DropdownMenuWithLabel(
                    label = "Course",
                    options = courseList,
                    selectedOption = course,
                    onOptionSelected = { course = courseList[it] },
                    currentAction = courseRequester,
                    nextAction = {}
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (
                        fullName.isNotBlank() &&
                        regNo.isNotBlank() &&
                        isRegNoValid &&
                        gender != genders[0] &&
                        ntaLevel != ntaLevels[0] &&
                        semester != semesters[0] &&
                        course != courseList[0] && selectedIntake.isNotBlank()
                    ) {
                        onAddStudent(
                            Student(
                                id = System.currentTimeMillis().toInt(),
                                studentName = fullName.trim().uppercase(Locale.getDefault()),
                                regNo = regNo.trim().uppercase(Locale.getDefault()),
                                gender = gender,
                                ntaLevel = ntaLevel,
                                semester = semester,
                                program = course,
                                intake = selectedIntake
                            )
                        )
                        onDismiss()
                    }
                },
                modifier = Modifier.defaultMinSize(minWidth = 100.dp)
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}