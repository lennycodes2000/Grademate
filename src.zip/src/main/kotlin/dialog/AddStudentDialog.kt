import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import components.Constants.courseList
import components.Constants.genders
import components.Constants.intake
import components.Constants.ntaLevels
import components.Constants.semesters
import dialog.ModernDropdown
import java.util.*

@Composable
fun AddStudentDialog(
    onDismiss: () -> Unit,
    onAddStudent: (Student) -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var regNo by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf(genders.first()) }
    var ntaLevel by remember { mutableStateOf(ntaLevels.first()) }
    var semester by remember { mutableStateOf(semesters.first()) }
    var selectedIntake by remember { mutableStateOf(intake.first()) }
    var course by remember { mutableStateOf(courseList.first()) }

    val regNoPattern = Regex("^[A-Z]{2}\\d{4}/\\d{4}/\\d{4}$")
    val isRegNoValid = regNo.matches(regNoPattern)

    val fullNameRequester = remember { FocusRequester() }
    val regNoRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) { fullNameRequester.requestFocus() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Add Student",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = GradeMateColors.Primary
                )
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("Full Name") },
                    singleLine = true,
                    leadingIcon = { Icon(painter = painterResource("person.png"),
                        modifier = Modifier.size(20.dp), contentDescription = "Full Name") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(fullNameRequester),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { regNoRequester.requestFocus() })
                )

                OutlinedTextField(
                    value = regNo.uppercase(Locale.getDefault()),
                    onValueChange = { regNo = it },
                    label = { Text("Registration Number") },
                    singleLine = true,
                    leadingIcon = { Icon(painter = painterResource("badge.png"), modifier = Modifier.size(20.dp), contentDescription = "Reg No") },
                    isError = regNo.isNotBlank() && !isRegNoValid,
                    supportingText = {
                        if (regNo.isNotBlank() && !isRegNoValid) {
                            Text("Use format: NS2345/0076/2022", color = MaterialTheme.colorScheme.error)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(regNoRequester),
                    keyboardOptions = KeyboardOptions(
                        imeAction = ImeAction.Done,
                        keyboardType = KeyboardType.Text
                    )
                )

                // ModernDropdowns with icons
                ModernDropdown(
                    label = "Gender",
                    options = genders,
                    selected = gender,
                    leadingIcon = { Icon(painter = painterResource("gender.png"), modifier = Modifier.size(20.dp), contentDescription = "Gender") }
                ) { gender = it }

                ModernDropdown(
                    label = "NTA Level",
                    options = ntaLevels,
                    selected = ntaLevel,
                    leadingIcon = { Icon(painter = painterResource("school.png"), modifier = Modifier.size(20.dp), contentDescription = "Level") }
                ) { ntaLevel = it }

                ModernDropdown(
                    label = "Semester",
                    options = semesters,
                    selected = semester,
                    leadingIcon = { Icon(painter = painterResource("daterange.png"), modifier = Modifier.size(20.dp), contentDescription = "Semester") }
                ) { semester = it }

                ModernDropdown(
                    label = "Academic Intake",
                    options = intake,
                    selected = selectedIntake,
                    leadingIcon = { Icon(painter = painterResource("intake.png"), modifier = Modifier.size(20.dp), contentDescription = "Intake") }
                ) { selectedIntake = it }

                ModernDropdown(
                    label = "Course",
                    options = courseList,
                    selected = course,
                    leadingIcon = { Icon(painter = painterResource("book.png"), modifier = Modifier.size(20.dp), contentDescription = "Course") }
                ) { course = it }
            }
        },
        confirmButton = {
            Button(
                colors = ButtonDefaults.buttonColors(
                    containerColor = GradeMateColors.Primary
                ),
                onClick = {
                    if (
                        fullName.isNotBlank() &&
                        isRegNoValid &&
                        gender != genders.first() &&
                        ntaLevel != ntaLevels.first() &&
                        semester != semesters.first() &&
                        course != courseList.first() &&
                        selectedIntake.isNotBlank()
                    ) {
                        onAddStudent(
                            Student(
                                id = System.currentTimeMillis().toInt(),
                                studentName = fullName.trim().uppercase(Locale.getDefault()),
                                regNo = regNo.trim().uppercase(Locale.getDefault()),
                                gender = gender,
                                ntaLevel = ntaLevel,
                                semester = semester,
                                program = course,
                                intake = selectedIntake
                            )
                        )
                        onDismiss()
                    }
                },
                modifier = Modifier.defaultMinSize(minWidth = 100.dp)
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

