package dialog

import GradeMateColors
import Tutor
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import components.Constants.deptList
import components.Constants.genders
import components.Constants.roleList
import java.util.*

@Composable
fun AddTutorDialog(
    onDismiss: () -> Unit,
    onAddTutor: (Tutor) -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf(genders.first()) }
    var course by remember { mutableStateOf(deptList.first()) }
    var role by remember { mutableStateOf(roleList.first()) }

    val fullNameRequester = remember { FocusRequester() }
    val emailRequester = remember { FocusRequester() }
    val phoneRequester = remember { FocusRequester() }

    // Validation regex
    val emailPattern = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$")
    val phonePattern = Regex("^((\\+255)|0)\\d{9}$")

    val isEmailValid = email.matches(emailPattern)
    val isPhoneValid = phone.matches(phonePattern)

    LaunchedEffect(Unit) {
        fullNameRequester.requestFocus()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Add Tutor",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = GradeMateColors.Primary
                )
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("Full Name") },
                    leadingIcon = { Icon(painter = painterResource("person.png"),
                        modifier = Modifier.size(20.dp),
                        contentDescription = "Full Name") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(fullNameRequester),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { emailRequester.requestFocus() })
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    leadingIcon = { Icon(painter = painterResource("email.png"),
                        modifier = Modifier.size(20.dp),
                        contentDescription = "Email") },
                    singleLine = true,
                    isError = email.isNotBlank() && !isEmailValid,
                    supportingText = {
                        if (email.isNotBlank() && !isEmailValid) {
                            Text("Invalid email. Example: example@gmail.com", color = MaterialTheme.colorScheme.error)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(emailRequester),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { phoneRequester.requestFocus() })
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { if (it.length <= 13) phone = it },
                    label = { Text("Phone Number") },
                    leadingIcon = { Icon(painter = painterResource("phone.png"),
                        modifier = Modifier.size(20.dp),
                        contentDescription = "Phone") },
                    singleLine = true,
                    isError = phone.isNotBlank() && !isPhoneValid,
                    supportingText = {
                        if (phone.isNotBlank() && !isPhoneValid) {
                            Text("Invalid format. Example: +255686777093", color = MaterialTheme.colorScheme.error)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(phoneRequester),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next)
                )

                // Dropdowns with icons
                ModernDropdown(
                    label = "Gender",
                    options = genders,
                    selected = gender,
                    leadingIcon = { Icon(painter = painterResource("gender.png"),
                        modifier = Modifier.size(20.dp),
                        contentDescription = "Gender") }
                ) { gender = it }

                ModernDropdown(
                    label = "Department",
                    options = deptList,
                    selected = course,
                    leadingIcon = { Icon(painter = painterResource("school.png"),
                        modifier = Modifier.size(20.dp),
                        contentDescription = "Department") }
                ) { course = it }

                ModernDropdown(
                    label = "Role",
                    options = roleList,
                    selected = role,
                    leadingIcon = { Icon(painter = painterResource("role.png"),
                        modifier = Modifier.size(20.dp),
                        contentDescription = "Role") }
                ) { role = it }
            }
        },
        confirmButton = {
            Button(
                colors = ButtonDefaults.buttonColors(
                    containerColor = GradeMateColors.Primary
                ),
                onClick = {
                    if (
                        fullName.isNotBlank() &&
                        isEmailValid &&
                        isPhoneValid &&
                        gender != genders.first() &&
                        course != deptList.first() &&
                        role != roleList.first()
                    ) {
                        onAddTutor(
                            Tutor(
                                tutorName = fullName.trim().uppercase(Locale.getDefault()),
                                email = email.trim(),
                                phone = phone.trim(),
                                gender = gender,
                                dept = course,
                                role = role
                            )
                        )
                        onDismiss()
                    }
                },
                modifier = Modifier.defaultMinSize(minWidth = 100.dp)
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
