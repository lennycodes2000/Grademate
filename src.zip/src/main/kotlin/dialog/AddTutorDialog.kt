package dialog
import Tutor
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import components.Constants.courseList
import components.Constants.genders
import components.Constants.roleList
import components.DropdownMenuWithLabel
import java.util.*

@Composable
fun AddTutorDialog(
    onDismiss: () -> Unit,
    onAddTutor: (Tutor) -> Unit
) {
    var fullName by remember { mutableStateOf("") }
    val fullNameRequester = remember { FocusRequester() }
    var role by remember { mutableStateOf("") }
    val roleRequester = remember { FocusRequester() }
    //email pattern
    var email by remember { mutableStateOf("") }
    val emailRequester = remember { FocusRequester() }
    val emailPattern =Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$")

    val isEmailValid = email.matches(emailPattern)
    val showErrorOne = email.isNotBlank() && !isEmailValid

              //phone pattern
    var phone by remember { mutableStateOf("") }
    val phoneRequester = remember { FocusRequester() }
    val phonePattern =Regex("^((\\+255)|0)\\d{9}$")
    val isphoneValid = phone.matches(phonePattern)
    val showErrorTwo = phone.isNotBlank() && !isphoneValid

    var gender by remember { mutableStateOf(genders[0]) }
    val genderRequester = remember { FocusRequester() }
    var course by remember { mutableStateOf(courseList[0]) }
    val courseRequester = remember { FocusRequester() }
    LaunchedEffect(Unit){
        fullNameRequester.requestFocus()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Add Tutor",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = Color(0xFF0277bd)
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = fullName.uppercase(),
                    onValueChange = { fullName = it },
                    label = { Text("Full Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().focusRequester(fullNameRequester),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = {emailRequester.requestFocus()})
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email address") },
                    isError = showErrorOne,
                    modifier = Modifier.fillMaxWidth().focusRequester(emailRequester),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(
                        onNext = {
                            phoneRequester.requestFocus()
                        }
                    )
                )

                if (showErrorOne) {
                    Text(
                        text = "Invalid format. Use e.g example@gmail.com",
                        color = Color.Red,
                        fontSize = 12.sp
                    )
                }
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = phone,
                    onValueChange = {
                        if(it.length<=13){
                            phone = it
                        }
                        },
                    label = { Text("Phone Number") },
                    isError = showErrorTwo,
                    modifier = Modifier.fillMaxWidth().focusRequester(phoneRequester),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(
                        onNext = {
                            genderRequester.requestFocus()
                        }
                    )
                )

                if (showErrorTwo) {
                    Text(
                        text = "Invalid format. Use e.g +255686777093",
                        color = Color.Red,
                        fontSize = 12.sp
                    )
                }
                Spacer(Modifier.height(8.dp))
                DropdownMenuWithLabel(
                    label = "Gender",
                    options = genders,
                    selectedOption = gender,
                    onOptionSelected = { gender = genders[it] },
                    currentAction = genderRequester,
                    nextAction = {
                        courseRequester.requestFocus()
                    }
                )
                Spacer(Modifier.height(8.dp))
                DropdownMenuWithLabel(
                    label = "Department",
                    options = courseList,
                    selectedOption = course,
                    onOptionSelected = { course = courseList[it] },
                    currentAction = courseRequester,
                    nextAction = {
                        roleRequester.requestFocus()
                    }
                )
                Spacer(Modifier.height(8.dp))
                DropdownMenuWithLabel(
                    label = "Role",
                    options = roleList,
                    selectedOption = role,
                    onOptionSelected = { role = roleList[it] },
                    currentAction = roleRequester,
                    nextAction = {
                        if (fullName.isNotBlank() && role.isNotBlank() && email.isNotBlank() && phone.isNotBlank() && gender != genders[0] && course != courseList[0]) {
                            onAddTutor(
                                Tutor(
                                    id = System.currentTimeMillis().toInt(),
                                    tutorName = fullName.trim().uppercase(Locale.getDefault()),
                                    email = email,
                                    phone = phone,
                                    gender = gender,
                                    dept = course,
                                    role = role,
                                )
                            )
                            onDismiss()
                        }
                    }
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (fullName.isNotBlank() && role.isNotBlank() && email.isNotBlank() && phone.isNotBlank() && gender != genders[0] && course != courseList[0]) {
                        onAddTutor(
                            Tutor(
                                id = System.currentTimeMillis().toInt(),
                                tutorName = fullName.trim().uppercase(Locale.getDefault()),
                                email = email,
                                phone = phone,
                                gender = gender,
                                dept = course,
                                role = role,
                            )
                        )
                        onDismiss()
                    }

                },
                modifier = Modifier.defaultMinSize(minWidth = 100.dp)
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}