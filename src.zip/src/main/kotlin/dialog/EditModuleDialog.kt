
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import dialog.ModernDropdown
import kotlinx.coroutines.delay

@Composable
fun EditModuleDialog(
    module: Module,
    onDismiss: () -> Unit,
    onSave: (Module) -> Unit
) {
    var code by remember { mutableStateOf(module.code) }
    var name by remember { mutableStateOf(module.name) }
    var credit by remember { mutableStateOf(module.credit) }
    var courseList by remember { mutableStateOf(module.courses.joinToString(", ")) }

    val nameRequester = remember { FocusRequester() }
    val creditRequester = remember { FocusRequester() }
    val courseRequester = remember { FocusRequester() }

    val tutors = remember { mutableStateListOf<Tutor>() }
    var selectedTutor by remember { mutableStateOf<Tutor?>(null) }
    var isLoadingTutors by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        val fetchedTutors = fetchTutorsFromFirestore()
        tutors.clear()
        tutors.addAll(fetchedTutors.sortedBy { it.tutorName })

        selectedTutor = tutors.firstOrNull { it.email == module.tutor }
        isLoadingTutors = false

        delay(100)
        nameRequester.requestFocus()
    }

    if (isLoadingTutors) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Edit Module",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = code.uppercase(),
                    enabled = false,
                    onValueChange = { code = it },
                    label = { Text("Module Code") },
                    singleLine = true,
                    leadingIcon = {
                        Icon(
                            painter = painterResource("badge.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Module Code"
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Module Name") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(nameRequester),
                    leadingIcon = {
                        Icon(
                            painter = painterResource("book.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "book.png"
                        )
                    },
                    keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { creditRequester.requestFocus() })
                )

                OutlinedTextField(
                    value = credit,
                    onValueChange = { input ->
                        if (input.matches(Regex("^\\d{0,2}(\\.\\d?)?$")) || input.isEmpty()) {
                            credit = input
                        }
                    },
                    label = { Text("Module Credit") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(creditRequester),
                    keyboardOptions = KeyboardOptions.Default.copy(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Next
                    ),
                    leadingIcon = {
                        Icon(
                            painter = painterResource("star.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "star.png"
                        )
                    },
                    keyboardActions = KeyboardActions(onNext = { courseRequester.requestFocus() })
                )
                ModernDropdown(
                    label = "Tutor",
                    options = tutors.map { it.tutorName },
                    selected = selectedTutor?.tutorName ?: "",
                    leadingIcon = {
                        Icon(
                            painter = painterResource("person.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Tutor"
                        )
                    }
                ) { selectedName ->
                    selectedTutor = tutors.find { it.tutorName == selectedName }
                }



                OutlinedTextField(
                    value = courseList,
                    onValueChange = { courseList = it },
                    label = { Text("Courses (comma-separated)") },
                    leadingIcon = {
                        Icon(
                            painter = painterResource("school.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "course.png"
                        )
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(courseRequester),
                    keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            val updatedModule = Module(
                                code = code.trim().uppercase(),
                                name = name.trim().uppercase(),
                                credit = credit.trim(),
                                courses = courseList.split(",").map { it.trim() },
                                tutor = selectedTutor?.email ?: module.tutor
                            )
                            onSave(updatedModule)
                        }
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updatedModule = Module(
                        code = code.trim().uppercase(),
                        name = name.trim().uppercase(),
                        credit = credit.trim(),
                        courses = courseList.split(",").map { it.trim() },
                        tutor = selectedTutor?.email ?: module.tutor
                    )
                    onSave(updatedModule)
                }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
