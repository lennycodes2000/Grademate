package dialog

import Student
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import components.Constants.courseList
import components.Constants.genders
import components.Constants.intake
import components.Constants.ntaLevels
import components.Constants.semesters
import java.util.*

@Composable
fun EditStudentDialog(
    student: Student,
    onDismiss: () -> Unit,
    onSave: (Student) -> Unit
) {
    var fullName by remember { mutableStateOf(student.studentName) }
    var regNo by remember { mutableStateOf(student.regNo) }
    var gender by remember { mutableStateOf(student.gender) }
    var ntaLevel by remember { mutableStateOf(student.ntaLevel) }
    var semester by remember { mutableStateOf(student.semester) }
    var selectedIntake by remember { mutableStateOf(student.intake) }
    var course by remember { mutableStateOf(student.program) }

    val regNoPattern = Regex("^[A-Z]{2}\\d{4}/\\d{4}/\\d{4}$")
    val isRegNoValid = regNo.matches(regNoPattern)

    val nameRequester = remember { FocusRequester() }
    val regNoRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) { nameRequester.requestFocus() }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Edit Student",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = regNo.uppercase(Locale.getDefault()),
                    onValueChange = { regNo = it },
                    label = { Text("Registration Number") },
                    singleLine = true,
                    leadingIcon = {
                        Icon(
                            painter = painterResource("badge.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Registration Number"
                        )
                    },
                    isError = regNo.isNotBlank() && !isRegNoValid,
                    supportingText = {
                        if (regNo.isNotBlank() && !isRegNoValid) {
                            Text("Invalid format. Example: NS2345/0076/2022", color = MaterialTheme.colorScheme.error)
                        }
                    },
                    enabled = false,
                    modifier = Modifier.fillMaxWidth().focusRequester(regNoRequester),
                )

                OutlinedTextField(
                    value = fullName.uppercase(Locale.getDefault()),
                    onValueChange = { fullName = it },
                    label = { Text("Full Name") },
                    leadingIcon = {
                        Icon(
                            painter = painterResource("person.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Full Name"
                        )
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { }),
                    modifier = Modifier.fillMaxWidth().focusRequester(nameRequester)
                )

                ModernDropdown(
                    label = "Gender",
                    options = genders,
                    selected = gender,
                    leadingIcon = {
                        Icon(
                            painter = painterResource("gender.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Gender"
                        )
                    }
                ) { gender = it }

                ModernDropdown(
                    label = "NTA Level",
                    options = ntaLevels,
                    selected = ntaLevel,
                    leadingIcon = {
                        Icon(
                            painter = painterResource("school.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "NTA Level"
                        )
                    }
                ) { ntaLevel = it }

                ModernDropdown(
                    label = "Semester",
                    options = semesters,
                    selected = semester,
                    leadingIcon = {
                        Icon(
                            painter = painterResource("daterange.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Semester"
                        )
                    }
                ) { semester = it }

                ModernDropdown(
                    label = "Academic Intake",
                    options = intake,
                    selected = selectedIntake,
                    leadingIcon = {
                        Icon(
                            painter = painterResource("intake.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Intake"
                        )
                    }
                ) { selectedIntake = it }

                ModernDropdown(
                    label = "Course",
                    options = courseList,
                    selected = course,
                    leadingIcon = {
                        Icon(
                            painter = painterResource("book.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Course"
                        )
                    }
                ) { course = it }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (
                        fullName.isNotBlank() &&
                        isRegNoValid &&
                        gender != genders.first() &&
                        ntaLevel != ntaLevels.first() &&
                        semester != semesters.first() &&
                        course != courseList.first() &&
                        selectedIntake.isNotBlank()
                    ) {
                        onSave(
                            student.copy(
                                studentName = fullName.uppercase(Locale.getDefault()),
                                regNo = regNo.uppercase(Locale.getDefault()),
                                gender = gender.uppercase(Locale.getDefault()),
                                ntaLevel = ntaLevel,
                                semester = semester,
                                program = course.uppercase(Locale.getDefault()),
                                intake = selectedIntake
                            )
                        )
                    }
                },
                modifier = Modifier.defaultMinSize(minWidth = 100.dp)
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
