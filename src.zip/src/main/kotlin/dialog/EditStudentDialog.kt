package dialog
import Student
import androidx.compose.foundation.layout.Column
import androidx.compose.material.*
import androidx.compose.runtime.*
import java.util.*

@Composable
fun EditStudentDialog(
    student: Student,
    onDismiss: () -> Unit,
    onSave: (Student) -> Unit
) {
    var name by remember { mutableStateOf(student.studentName) }
    var regNo by remember { mutableStateOf(student.regNo) }
    var gender by remember { mutableStateOf(student.gender) }
    var ntaLevel by remember { mutableStateOf(student.ntaLevel) }
    var semester by remember { mutableStateOf(student.semester) }
    var program by remember { mutableStateOf(student.program) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Student") },
        text = {
            Column {
                OutlinedTextField(value = name.uppercase(Locale.getDefault()), onValueChange = { name = it }, label = { Text("Name") })
                OutlinedTextField(value = regNo.uppercase(Locale.getDefault()), onValueChange = { regNo = it }, label = { Text("Reg No") })
                OutlinedTextField(value = gender.uppercase(Locale.getDefault()), onValueChange = { gender = it }, label = { Text("Gender") })
                OutlinedTextField(value = ntaLevel, onValueChange = { ntaLevel = it }, label = { Text("NTA Level") })
                OutlinedTextField(value = semester, onValueChange = { semester = it }, label = { Text("Semester") })
                OutlinedTextField(value = program.uppercase(Locale.getDefault()), onValueChange = { program = it }, label = { Text("Program") })
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(
                    student.copy(
                        studentName = name.uppercase(Locale.getDefault()),
                        regNo = regNo.uppercase(Locale.getDefault()),
                        gender = gender.uppercase(Locale.getDefault()),
                        ntaLevel = ntaLevel,
                        semester = semester,
                        program = program.uppercase(Locale.getDefault())
                    )
                )
            }) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}