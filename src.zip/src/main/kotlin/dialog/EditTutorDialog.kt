import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import components.Constants.deptList
import components.Constants.genders
import components.Constants.roleList
import dialog.ModernDropdown
import java.util.*

@Composable
fun EditTutorDialog(
    tutor: Tutor,
    onDismiss: () -> Unit,
    onSave: (Tutor) -> Unit
) {
    var fullName by remember { mutableStateOf(tutor.tutorName) }
    var email by remember { mutableStateOf(tutor.email) }
    var gender by remember { mutableStateOf(tutor.gender) }
    var dept by remember { mutableStateOf(tutor.dept) }
    var role by remember { mutableStateOf(tutor.role) }
    var phone by remember { mutableStateOf(tutor.phone) }

    val emailPattern = Regex("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$")
    val phonePattern = Regex("^((\\+255)|0)\\d{9}$")

    val isEmailValid = email.matches(emailPattern)
    val isPhoneValid = phone.matches(phonePattern)

    val nameRequester = remember { FocusRequester() }
    val phoneRequester = remember { FocusRequester() }
    val emailRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        nameRequester.requestFocus()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Edit Tutor",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("E-mail address") },
                    singleLine = true,
                    leadingIcon = {
                        Icon(
                            painter = painterResource("email.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Email address"
                        )
                    },
                    isError = email.isNotBlank() && !isEmailValid,
                    supportingText = {
                        if (email.isNotBlank() && !isEmailValid) {
                            Text("Invalid format. Example: someone@example.com", color = MaterialTheme.colorScheme.error)
                        }
                    },
                    enabled = false,
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(emailRequester)
                )

                OutlinedTextField(
                    value = fullName.uppercase(Locale.getDefault()),
                    onValueChange = { fullName = it },
                    label = { Text("Full Name") },
                    leadingIcon = {
                        Icon(
                            painter = painterResource("person.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Full Name"
                        )
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { phoneRequester.requestFocus() }),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(nameRequester)
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = {
                        if(it.length <= 13){
                            phone = it
                        }
                                    },
                    label = { Text("Phone Number") },
                    leadingIcon = {
                        Icon(
                            painter = painterResource("phone.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Phone Number"
                        )
                    },
                    isError = phone.isNotBlank() && !isPhoneValid,
                    supportingText = {
                        if (phone.isNotBlank() && !isPhoneValid) {
                            Text("Invalid format. Example: +255686777093", color = MaterialTheme.colorScheme.error)
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(phoneRequester)
                )

                ModernDropdown(
                    label = "Gender",
                    options = genders,
                    selected = gender,
                    leadingIcon = {
                        Icon(
                            painter = painterResource("gender.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Gender"
                        )
                    }
                ) { gender = it }

                ModernDropdown(
                    label = "Department",
                    options = deptList,
                    selected = dept,
                    leadingIcon = {
                        Icon(
                            painter = painterResource("school.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Department"
                        )
                    }
                ) { dept = it }

                ModernDropdown(
                    label = "Role",
                    options = roleList,
                    selected = role,
                    leadingIcon = {
                        Icon(
                            painter = painterResource("role.png"),
                            modifier = Modifier.size(20.dp),
                            contentDescription = "Role"
                        )
                    }
                ) { role = it }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (
                        fullName.isNotBlank() &&
                        isEmailValid && isPhoneValid &&
                        gender != genders.first() &&
                        dept != deptList.first() &&
                        role.isNotBlank()
                    ) {
                        onSave(
                            tutor.copy(
                                tutorName = fullName.uppercase(Locale.getDefault()),
                                email = email,
                                gender = gender.uppercase(Locale.getDefault()),
                                dept = dept,
                                phone = phone,
                                role = role
                            )
                        )
                    }
                },
                modifier = Modifier.defaultMinSize(minWidth = 100.dp)
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
