import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


@Composable
fun ModuleListItem(
    index: Int,
    module: Module,
    onEditClick: (Module) -> Unit,
    onModulesUpdated: (List<Module>) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }
    var isDeleting by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    if (showDialog) {
        DeleteConfirmationDialog(
            module = module,
            onConfirm = {
                showDialog = false
                isDeleting = true

                coroutineScope.launch {
                    val success = onDeleteModule(module)
                    if (success) {
                        val updatedModules = fetchModulesFromFirestore()

                        // Pass updated modules to parent
                        withContext(Dispatchers.Main) {
                            onModulesUpdated(updatedModules)
                            // NOTE: Do NOT reset isDeleting here
                            // Let the parent recompose with updated list
                        }
                    } else {
                        withContext(Dispatchers.Main) {
                            isDeleting = false
                        }
                    }
                }
            },
            onDismiss = { showDialog = false }
        )
    }

    // This item will disappear when parent updates the module list
    if (!isDeleting) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp, horizontal = 8.dp),
            elevation = 3.dp,
            shape = RoundedCornerShape(8.dp),
            backgroundColor = Color(0xFFbbdefb)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("$index. ${module.code} - ${module.name} (${module.credit})", fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(4.dp))
                Text("Level: ${module.level}, Semester: ${module.semester}", fontSize = 12.sp, color = Color(0xFF01579b))
                Text("Courses: ${module.courses.joinToString()}", fontSize = 12.sp, color = Color(0xFF01579b))

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onEditClick(module) },
                        enabled = !isDeleting,
                        modifier = Modifier.height(40.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            backgroundColor = MaterialTheme.colors.primary,
                            contentColor = Color.White
                        )
                    ) {
                        Text("Update", fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { showDialog = true },
                        enabled = !isDeleting,
                        modifier = Modifier.height(40.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            backgroundColor = MaterialTheme.colors.error,
                            contentColor = Color.White
                        )
                    ) {
                        if (isDeleting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text("Delete", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}