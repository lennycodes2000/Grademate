// 🔹 Jetpack Compose
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// 🔹 Coroutines
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// 🔹 Your app-specific imports (you already had these)
import Global.refresh
import dialog.EditStudentDialog
// If you have ModuleListItem, StudentListItem, EditModuleDialog, etc. put them here

enum class ManageTab { STUDENTS, MODULES, TUTORS }

@Composable
fun Manage(
    onBack: () -> Unit,
    students: SnapshotStateList<Student>,
    modules: SnapshotStateList<Module>,
    tutors: SnapshotStateList<Tutor>,
    publish: SnapshotStateList<Publish>,
    onViewResults: () -> Unit,
    onPublishResults: () -> Unit,
    onAcademicPromotion: () -> Unit,
) {
    var status by remember { mutableStateOf(true) }
    var currentTab by remember { mutableStateOf(ManageTab.STUDENTS) }
    var studentToEdit by remember { mutableStateOf<Student?>(null) }
    var tutorToEdit by remember { mutableStateOf<Tutor?>(null) }
    var moduleToEdit by remember { mutableStateOf<Module?>(null) }
    var showDialog by remember { mutableStateOf(false) }
    var showAbsence by remember { mutableStateOf(false) }
    var showManage by remember { mutableStateOf(false) }
    val selectedAcademicYear by remember { mutableStateOf("") }

    if (showDialog) {
        TimedDialog(status) { showDialog = false }
    }

    // 🔹 Load all data
    suspend fun loadData() {
        showManage = true
        withContext(Dispatchers.IO) {
            val fetchedStudents = fetchStudentsFromFirestore()
            val fetchedPublish = fetchPublishFromFirestore()
            val fetchedModules = fetchModulesFromFirestore()
            val fetchedTutors = fetchTutorsFromFirestore()

            withContext(Dispatchers.Main) {
                students.clear(); students.addAll(fetchedStudents.sortedBy {
                    it.studentName
            })
                publish.clear(); publish.addAll(fetchedPublish)
                modules.clear(); modules.addAll(fetchedModules.sortedBy {
                    it.name
            })
                tutors.clear(); tutors.addAll(fetchedTutors.sortedBy {
                    it.tutorName
            })
            }
        }
    }

    // 🔹 Run once when the page starts
    LaunchedEffect(Unit) {
        loadData()
    }

    // 🔹 Run again whenever refresh.value == true
    LaunchedEffect(refresh.value) {
        if (refresh.value) {
            loadData()
            refresh.value = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp)
    ) {
        if (showManage) {
            // 🔹 Top Bar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = onBack,
                    colors = ButtonDefaults.buttonColors(containerColor = GradeMateColors.Primary)
                ) {
                    Text("⬅ Go Back", color = GradeMateColors.Background)
                }
                Spacer(modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.size(32.dp))

            // 🔹 Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                TabButton("Students", currentTab == ManageTab.STUDENTS) {
                    currentTab = ManageTab.STUDENTS
                }
                TabButton("Modules", currentTab == ManageTab.MODULES) {
                    currentTab = ManageTab.MODULES
                }
                TabButton("Tutors", currentTab == ManageTab.TUTORS) {
                    currentTab = ManageTab.TUTORS
                }
            }

            Spacer(modifier = Modifier.size(16.dp))

            // 🔹 Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Button(onClick = { showAbsence = true }, modifier = Modifier.weight(1f)) {
                    Text("Record Absence")
                }
                RecordAbsence(
                    showDialog = showAbsence,
                    onDismiss = { showAbsence = false },
                    onConfirm = { selectedStudents, subject ,academicYear->
                        val selectedModule = modules.find { "${it.code} ${it.name}" == subject }
                        if (selectedModule == null) {
                            println("❌ Selected module not found for subject: $subject")
                            return@RecordAbsence
                        }
                        val absenceDate = java.time.LocalDate.now().toString()
                        var allSuccessful = true
                        for (student in selectedStudents) {
                            val absence = AbsenceFields(
                                studentRegNo = FirestoreString(student.regNo),
                                studentName = FirestoreString(student.studentName),
                                moduleCode = FirestoreString(selectedModule.code),
                                moduleName = FirestoreString(selectedModule.name),
                                absenceDate = FirestoreString(absenceDate),
                                academicYear = FirestoreString(academicYear)
                            )
                            if (!addAbsenceToFirestore(absence)) {
                                allSuccessful = false
                            }
                        }
                        status = allSuccessful
                        showDialog = true
                    }
                )
                Button(onClick = onAcademicPromotion, modifier = Modifier.weight(1f)) {
                    Text("Students Promotion")
                }
                Button(onClick = onViewResults, modifier = Modifier.weight(1f)) {
                    Text("View Results")
                }
                if (publish.isNotEmpty()) {
                    Button(onClick = onPublishResults, modifier = Modifier.weight(1f)) {
                        Text("Publish Results")
                    }
                }
            }

            // 🔹 Show List by Tab
            when (currentTab) {
                ManageTab.STUDENTS -> EntityList(
                    title = "Students",
                    isLoading = refresh.value,
                    items = students,
                ) { index, student ->
                    StudentListItem(
                        index = index + 1,
                        student = student,
                        onEditClick = { studentToEdit = it },
                        onStudentDeleted = { updated ->
                            students.clear(); students.addAll(updated)
                        }
                    )
                }

                ManageTab.MODULES -> EntityList(
                    title = "Modules",
                    isLoading = refresh.value,
                    items = modules,
                ) { index, module ->
                    ModuleListItem(
                        index = index + 1,
                        module = module,
                        onEditClick = { moduleToEdit = it },
                        onModulesUpdated = { updated ->
                            modules.clear(); modules.addAll(updated)
                        }
                    )
                }

                ManageTab.TUTORS -> EntityList(
                    title = "Tutors",
                    isLoading = refresh.value,
                    items = tutors,
                ) { index, tutor ->
                    TutorListItem(
                        index = index + 1,
                        tutor = tutor,
                        onEditClick = { tutorToEdit = it },
                        onTutorDeleted = { updated ->
                            tutors.clear(); tutors.addAll(updated)
                        }
                    )
                }
            }
        } else {
            // 🔹 Global Loading
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) { CircularProgressIndicator() }
        }
    }

    // 🔹 Edit Dialogs
    studentToEdit?.let { student ->
        EditStudentDialog(
            student = student,
            onDismiss = { studentToEdit = null },
            onSave = { updated ->
                val index = students.indexOfFirst { it.id == updated.id }
                if (index != -1) students[index] = updated
                CoroutineScope(Dispatchers.IO).launch {
                    val success = updateStudentInFirestore(updated)
                    status = success; showDialog = true
                }
                studentToEdit = null
            }
        )
    }

    moduleToEdit?.let { module ->
        EditModuleDialog(
            module = module,
            onDismiss = { moduleToEdit = null },
            onSave = { updated ->
                val index = modules.indexOfFirst { it.code == updated.code }
                if (index != -1) modules[index] = updated
                CoroutineScope(Dispatchers.IO).launch {
                    val success = updateModuleInFirestore(updated)
                    status = success; showDialog = true
                }
                moduleToEdit = null
            }
        )
    }
}

@Composable
fun TabButton(text: String, isSelected: Boolean, onClick: () -> Unit) {
    Button(
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) GradeMateColors.Primary else Color.LightGray,
            contentColor = if (isSelected) Color.White else Color.Black
        ),
        onClick = onClick
    ) { Text(text) }
}

@Composable
fun <T> EntityList(
    title: String,
    isLoading: Boolean,
    items: List<T>,
    itemContent: @Composable (Int, T) -> Unit
) {
    if (isLoading) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) { CircularProgressIndicator() }
    } else {
        Spacer(Modifier.height(24.dp))
        Text(
            title,
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp,
            color = Color(0xFF0277bd)
        )
        Spacer(Modifier.height(12.dp))
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .border(1.dp, Color(0xFFb3e5fc), RoundedCornerShape(8.dp))
                .background(Color(0xFFE3F2FD), RoundedCornerShape(8.dp))
        ) {
            itemsIndexed(items) { index, item ->
                itemContent(index, item)
            }
        }
    }
}
