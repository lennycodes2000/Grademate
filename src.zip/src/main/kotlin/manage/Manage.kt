
import Global.refresh
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import components.Constants
import dialog.EditStudentDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

// If you have ModuleListItem, StudentListItem, EditModuleDialog, etc. put them here

enum class ManageTab { STUDENTS, MODULES, TUTORS }
@Composable
fun Manage(
    onBack: () -> Unit,
    students: SnapshotStateList<Student>,
    modules: SnapshotStateList<Module>,
    tutors: SnapshotStateList<Tutor>,
    publish: SnapshotStateList<Publish>,
    onViewResults: () -> Unit,
    onPublishResults: () -> Unit,
    onAcademicPromotion: () -> Unit,
) {
    var status by remember { mutableStateOf(true) }
    var currentTab by remember { mutableStateOf(ManageTab.STUDENTS) }
    var studentToEdit by remember { mutableStateOf<Student?>(null) }
    var tutorToEdit by remember { mutableStateOf<Tutor?>(null) }
    var moduleToEdit by remember { mutableStateOf<Module?>(null) }
    var showDialog by remember { mutableStateOf(false) }
    var showAbsence by remember { mutableStateOf(false) }
    var showManage by remember { mutableStateOf(false) }
    if (showDialog) {
        TimedDialog(status) { showDialog = false }
    }

    var searchIndex by remember {
        mutableStateOf(0)
    }

    // 🔹 Load Data Function
    fun loadData() {
        CoroutineScope(Dispatchers.IO).launch {
            withContext(Dispatchers.Main) {
                showManage = true
            }

            val fetchedPublish = fetchPublishFromFirestore()
            val fetchedModules = fetchModulesFromFirestore()
            val fetchedTutors = fetchTutorsFromFirestore()
            val fetchedStudents = fetchStudentsFromFirestore().filter {
                it.status != Constants.statuList[3]
            }

            withContext(Dispatchers.Main) {
                students.clear() // clear old snapshot immediately
                students.addAll(fetchedStudents)
                publish.clear(); publish.addAll(fetchedPublish)
                modules.clear(); modules.addAll(fetchedModules)
                tutors.clear(); tutors.addAll(fetchedTutors)
            }
        }
    }


    // 🔹 Run once when the page starts
    LaunchedEffect(Unit) {
        loadData()
    }

    // 🔹 Run again whenever refresh.value == true
    LaunchedEffect(refresh.value) {
        if (refresh.value) {
            loadData()
            refresh.value = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp)
    ) {
        if (showManage) {
            // 🔹 Top Bar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = onBack,
                    colors = ButtonDefaults.buttonColors(containerColor = GradeMateColors.Primary)
                ) {
                    Text("⬅ Go Back", color = GradeMateColors.Background)
                }
                Spacer(modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.size(4.dp))

            // 🔹 Tabs
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                TabButton("Students", currentTab == ManageTab.STUDENTS) {
                    searchIndex = 0
                    currentTab = ManageTab.STUDENTS

                }
                TabButton("Modules", currentTab == ManageTab.MODULES) {
                    searchIndex = 1
                    currentTab = ManageTab.MODULES
                }
                TabButton("Tutors", currentTab == ManageTab.TUTORS) {
                    searchIndex = 2
                    currentTab = ManageTab.TUTORS
                }
            }

            Spacer(modifier = Modifier.size(4.dp))

            // 🔹 Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Button(onClick = { showAbsence = true }, modifier = Modifier.weight(1f)) {
                    Text("Record Absence")
                }
                RecordAbsence(
                    showDialog = showAbsence,
                    onDismiss = { showAbsence = false },
                    onConfirm = { selectedStudents, subject, academicYear ->
                        val selectedModule = modules.find { "${it.code} ${it.name}" == subject }
                        if (selectedModule == null) {
                            println("❌ Selected module not found for subject: $subject")
                            return@RecordAbsence
                        }
                        val absenceDate = LocalDate.now().toString()
                        var allSuccessful = true
                        for (student in selectedStudents) {
                            val absence = AbsenceFields(
                                studentRegNo = FirestoreString(student.regNo),
                                studentName = FirestoreString(student.studentName),
                                moduleCode = FirestoreString(selectedModule.code),
                                moduleName = FirestoreString(selectedModule.name),
                                absenceDate = FirestoreString(absenceDate),
                                academicYear = FirestoreString(academicYear)
                            )
                            if (!addAbsenceToFirestore(absence)) {
                                allSuccessful = false
                            }
                        }
                        status = allSuccessful
                        showDialog = true
                    }
                )
                Button(onClick = onAcademicPromotion, modifier = Modifier.weight(1f)) {
                    Text("Students Promotion")
                }
                Button(onClick = onViewResults, modifier = Modifier.weight(1f)) {
                    Text("View Results")
                }
                    Button(onClick = onPublishResults, modifier = Modifier.weight(1f)) {
                        Text("Publish Results")
                    }
            }

            // 🔹 Show List by Tab
            when (currentTab) {
                ManageTab.STUDENTS -> EntityList(
                    searchIndex = searchIndex,
                    title = "Students",
                    isLoading = refresh.value,
                    items = students,
                ) { index, student ->
                    StudentListItem(
                        index = index + 1,
                        student = student,
                        onEditClick = { studentToEdit = it },
                        onStudentDeleted = { updated ->
                            students.clear(); students.addAll(updated)
                        }
                    )
                }

                ManageTab.MODULES -> EntityList(
                    searchIndex = searchIndex,
                    title = "Modules",
                    isLoading = refresh.value,
                    items = modules,
                ) { index, module ->
                    ModuleListItem(
                        index = index + 1,
                        module = module,
                        onEditClick = { moduleToEdit = it },
                        onModulesUpdated = { updated ->
                            modules.clear(); modules.addAll(updated)
                        }
                    )
                }

                ManageTab.TUTORS -> EntityList(
                    searchIndex = searchIndex,
                    title = "Tutors",
                    isLoading = refresh.value,
                    items = tutors,
                ) { index, tutor ->
                    TutorListItem(
                        index = index + 1,
                        tutor = tutor,
                        onEditClick = { tutorToEdit = it },
                        onTutorDeleted = { updated ->
                            tutors.clear(); tutors.addAll(updated)
                        }
                    )
                }
            }
        } else {
            // 🔹 Global Loading
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) { CircularProgressIndicator() }
        }
    }

    // 🔹 Edit Dialogs
    studentToEdit?.let { student ->
        EditStudentDialog(
            student = student,
            onDismiss = { studentToEdit = null },
            onSave = { updated ->
                CoroutineScope(Dispatchers.IO).launch {
                    val success = updateStudentInFirestore(updated)
                    withContext(Dispatchers.Main) {
                        if (success) {
                            val index = students.indexOfFirst { it.id == updated.id }
                            if (index != -1) students[index] = updated
                            status = true
                        } else {
                            status = false
                        }
                        showDialog = true
                    }
                }
                studentToEdit = null
            }

        )
    }
    tutorToEdit?.let { tutor ->
        EditTutorDialog(
            tutor = tutor,
            onDismiss = { tutorToEdit = null },
            onSave = { updated ->
                CoroutineScope(Dispatchers.IO).launch {
                    val success = updateTutorInFirestore(updated)
                    withContext(Dispatchers.Main) {
                        if (success) {
                            val index = tutors.indexOfFirst { it.id == updated.id }
                            if (index != -1) {
                                tutors[index] = updated.copy(id = tutors[index].id) // keep same id
                            }
                        }
                        status = success
                        showDialog = true
                    }
                }
                tutorToEdit = null
            }

        )
    }
    moduleToEdit?.let { module ->
        EditModuleDialog(
            module = module,
            onDismiss = { moduleToEdit = null },
            onSave = { updated ->
                CoroutineScope(Dispatchers.IO).launch {
                    val success = updateModuleInFirestore(updated)
                    withContext(Dispatchers.Main) {
                        if (success) {
                            val index = modules.indexOfFirst { it.code == updated.code }
                            if (index != -1) modules[index] = updated
                            status = true
                        } else {
                            status = false
                        }
                        showDialog = true
                    }
                }
                moduleToEdit = null
            }

        )
    }
}

@Composable
fun TabButton(text: String, isSelected: Boolean, onClick: () -> Unit) {
    Button(
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isSelected) GradeMateColors.Primary else Color.LightGray,
            contentColor = if (isSelected) Color.White else Color.Black
        ),
        onClick = onClick
    ) { Text(text) }
}
@Composable
fun <T> EntityList(
    searchIndex: Int,
    title: String,
    isLoading: Boolean,
    items: List<T>,
    itemContent: @Composable (Int, T) -> Unit
) {
    var searchItem by remember { mutableStateOf("") }
    val searchItemRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        if (searchIndex == 0) {
            searchItemRequester.requestFocus()
        }
    }

    if (isLoading) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
        return
    }

    Spacer(modifier = Modifier.height(4.dp))

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        //  Title — bold, clean
        Text(
            text = title,
            fontWeight = FontWeight.Bold,
            fontSize = 22.sp,
            color = GradeMateColors.Primary,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.weight(1f)) // Push dropdown to the far right

        if (searchIndex == 0) {
            TextField(
                modifier = Modifier
                    .weight(2f)
                    .focusRequester(searchItemRequester),
                value = searchItem,
                singleLine = true,
                label = { Text("Search") },
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    unfocusedLabelColor = GradeMateColors.Primary,
                    focusedIndicatorColor = GradeMateColors.Primary,
                    unfocusedIndicatorColor = Color.Transparent,
                    focusedTextColor = Color.Black,
                    cursorColor = GradeMateColors.Primary
                ),
                trailingIcon = {
                    Icon(
                        painter = painterResource("search.png"),
                        modifier = Modifier.size(20.dp),
                        contentDescription = null,
                        tint = GradeMateColors.Primary
                    )
                },
                onValueChange = {
                    if (it.length <= 30) {
                        searchItem = it
                    }
                }
            )

        }
    }

    // 🔍 Filtering logic
    val filteredItems = remember(searchItem, items) {
        if (searchItem.isBlank()) {
            items
        } else {
            items.filter { item ->
                when (item) {
                    is Student -> {
                        item.studentName.contains(searchItem, ignoreCase = true) ||
                                item.regNo.contains(searchItem, ignoreCase = true)
                    }
                    is Module -> {
                        item.name.contains(searchItem, ignoreCase = true) ||
                                item.code.contains(searchItem, ignoreCase = true)
                    }
                    is Tutor -> {
                        item.tutorName.contains(searchItem, ignoreCase = true) ||
                                item.email.contains(searchItem, ignoreCase = true)
                    }
                    else -> item.toString().contains(searchItem, ignoreCase = true)
                }
            }
        }
    }

    // 🔹 Entity List Table
    LazyColumn(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight()
            .border(1.dp, Color(0xFFb3e5fc), RoundedCornerShape(8.dp))
            .background(Color(0xFFE3F2FD), RoundedCornerShape(8.dp))
    ) {
        itemsIndexed(filteredItems) { index, item ->
            itemContent(index, item)
        }
    }
}



