import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dialog.EditStudentDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import list.TutorListItem

@Composable
fun Manage(
    onBack:()->Unit,
    students: SnapshotStateList<Student>,
    modules: SnapshotStateList<Module>,
    tutors: SnapshotStateList<Tutor>,
    publish:SnapshotStateList<Publish>,
    onViewResults:()->Unit,
    onPublishResults:()->Unit,
    onAcademicPromotion:()->Unit
    ){
    var status by remember { mutableStateOf(true) }
    var showStudentList by remember { mutableStateOf(false) }
    var showModuleList by remember { mutableStateOf(false) }
    var showtutorList by remember { mutableStateOf(false) }
    var studentToEdit by remember { mutableStateOf<Student?>(null) }
    var tutorToEdit by remember { mutableStateOf<Tutor?>(null) }
    var moduleToEdit by remember { mutableStateOf<Module?>(null) }
    var showDialog by remember { mutableStateOf(false) }
    var showAbsence by remember { mutableStateOf(false) }
    if (showDialog) {
        TimedDialog(status) {
            showDialog = false
        }
    }
    fun toggleChanges(target: String) {
        when (target) {
            "students" -> {
                showStudentList = true
                showModuleList = false
                showtutorList = false

            }
            "modules" -> {
                showModuleList = true
                showStudentList = false
                showtutorList = false
            }
            "tutors" -> {
                showModuleList = false
                showStudentList = false
                showtutorList = true
            }
        }
    }
    LaunchedEffect(Unit){
        students.clear()
        val studentsList = fetchStudentsFromFirestore()
        students.addAll(studentsList)
        toggleChanges("students")
        publish.clear()
        val publishList = fetchPublishFromFirestore()
        publish.addAll(publishList)
        modules.clear()
        val moduleList = fetchModulesFromFirestore()
        modules.addAll(moduleList)
        tutors.clear()
        val tutorList = fetchTutorsFromFirestore()
        tutors.addAll(tutorList)

    }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp)
    ) {
        // Top bar
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = GradeMateColors.Primary)
            ) {
                Text("⬅ Go Back", color = GradeMateColors.Background)
            }
        }
        Spacer(modifier = Modifier.size(32.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Button(
                colors = ButtonDefaults.buttonColors(
                    containerColor = if(showStudentList) GradeMateColors.Primary else Color.LightGray,
                    contentColor = if (showStudentList) Color.White else Color.Black
                ),
                onClick = { showStudentList = !showStudentList
                          toggleChanges("students")
                          },
                modifier = Modifier.weight(1f)
            ) {
                androidx.compose.material.Text("View Students")
            }
            Button(
                colors = ButtonDefaults.buttonColors(
                    containerColor = if(showModuleList) GradeMateColors.Primary else Color.LightGray,
                    contentColor = if (showModuleList) Color.White else Color.Black
                ),
                onClick = { showModuleList = !showModuleList
                          toggleChanges("modules")},
                modifier = Modifier.weight(1f)
            ) {
                androidx.compose.material.Text("View Modules" )
            }
            //show the tutors
            Button(
                colors = ButtonDefaults.buttonColors(
                    containerColor = if(showtutorList) GradeMateColors.Primary else Color.LightGray,
                    contentColor = if (showtutorList) Color.White else Color.Black
                ),
                onClick = {
                    showtutorList = !showtutorList
                    toggleChanges("tutors")
                },
                modifier = Modifier.weight(1f)
            ) {
                androidx.compose.material.Text("View Tutors")
            }

        }
        Spacer(modifier = Modifier.size(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Show the dialog when button clicked
            Button(onClick = { showAbsence = true }, modifier = Modifier.weight(1f)) {
                androidx.compose.material.Text("Record Absence")
            }
            RecordAbsence(
                showDialog = showAbsence,
                onDismiss = { showAbsence = false },
                onConfirm = { selectedStudents, subject ->
                    // This lambda is suspend, so you can call suspend functions here safely
                    val selectedModule = modules.find { "${it.code} ${it.name}" == subject }
                    if (selectedModule == null) {
                        println("❌ Selected module not found for subject: $subject")
                        return@RecordAbsence
                    }

                    val absenceDate = java.time.LocalDate.now().toString()
                    var allSuccessful = true

                    for (student in selectedStudents) {
                        val absence = AbsenceFields(
                            studentRegNo = FirestoreString(student.regNo),
                            studentName = FirestoreString(student.studentName),
                            moduleCode = FirestoreString(selectedModule.code),
                            moduleName = FirestoreString(selectedModule.name),
                            absenceDate = FirestoreString(absenceDate)
                        )

                        val success = addAbsenceToFirestore(absence)
                        if (!success) {
                            allSuccessful = false
                            println("❌ Failed to save absence for ${student.studentName}")
                        }
                    }

                    status = allSuccessful
                    showDialog = true
                    println("✅ Absences recorded for ${selectedStudents.size} students in $subject")
                }
            )
            //Promote students
            Button(onClick = onAcademicPromotion, modifier = Modifier.weight(1f)) {
                androidx.compose.material.Text("Students Promotion")
            }
            //show the results
            Button(
                onClick = onViewResults,
                modifier = Modifier.weight(1f)
            ) {
                androidx.compose.material.Text("View Results")
            }
            // Show the dialog when button clicked
            if(publish.isNotEmpty()){
                Button(
                    onClick = onPublishResults,
                    modifier = Modifier.weight(1f)
                ) {
                    androidx.compose.material.Text("Publish Results")
                }
            }

        }
                //showing the student List
        if (showStudentList) {
            Spacer(Modifier.height(24.dp))
            androidx.compose.material.Text(
                "Students",
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                color = Color(0xFF0277bd)
            )
            Spacer(Modifier.height(12.dp))
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .border(1.dp, Color(0xFFb3e5fc), RoundedCornerShape(8.dp))
                    .background(Color(0xFFE3F2FD), RoundedCornerShape(8.dp))
            ) {
                itemsIndexed(students) { index, student ->
                    StudentListItem(
                        index = index + 1,
                        student = student,
                        onEditClick = { studentToEdit = it },
                        onStudentDeleted = { updatedStudents ->
                            students.clear()
                            students.addAll(updatedStudents)
                        }
                    )
                }


            }
        }
        //showing the tutor list
        if(showtutorList){
            Spacer(Modifier.height(24.dp))
            androidx.compose.material.Text(
                "Tutors",
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                color = Color(0xFF0277bd)
            )
            Spacer(Modifier.height(12.dp))
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .border(1.dp, Color(0xFFb3e5fc), RoundedCornerShape(8.dp))
                    .background(Color(0xFFE3F2FD), RoundedCornerShape(8.dp))
            ) {
                itemsIndexed(tutors) { index, tutor ->

                    TutorListItem(
                        index = index + 1,
                        tutor = tutor,
                        onEditClick = {tutorToEdit = it},
                        onTutorDeleted = {updatedTutor->
                            tutors.clear()
                            tutors.addAll(updatedTutor)
                        }
                    )
                }


            }
        }
//showing the module list
        if (showModuleList) {
            Spacer(Modifier.height(24.dp))
            androidx.compose.material.Text(
                "Modules",
                fontWeight = FontWeight.Bold,
                fontSize = 22.sp,
                color = Color(0xFF0277bd)
            )
            Spacer(Modifier.height(12.dp))
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .border(1.dp, Color(0xFFb3e5fc), RoundedCornerShape(8.dp))
                    .background(Color(0xFFE3F2FD), RoundedCornerShape(8.dp)
                    )
            ) {
                itemsIndexed(modules) { index, module ->
                    ModuleListItem(
                        index + 1,
                        module,
                        onEditClick = { moduleToEdit = it },
                        onModulesUpdated = { updatedModules ->
                            modules.clear()
                            modules.addAll(updatedModules)
                        }
                    )
                }

            }
        }
    }
    //show the student Edit Dialog
    studentToEdit?.let { student ->
        EditStudentDialog(
            student = student,
            onDismiss = { studentToEdit = null },
            onSave = { updatedStudent ->
                // update UI
                val index = students.indexOfFirst { it.id == updatedStudent.id }
                if (index != -1) students[index] = updatedStudent

                // update Firestore
                CoroutineScope(Dispatchers.IO).launch {
                    val success = updateStudentInFirestore(updatedStudent)
                    println(if (success) "✅ Updated in Firestore" else "❌ Update failed")
                    status = success
                    showDialog = true
                }

                studentToEdit = null
            }
        )
    }
    // Show the module Edit Dialog
    moduleToEdit?.let { module ->
        EditModuleDialog(
            module = module,
            onDismiss = { moduleToEdit = null },
            onSave = { updatedModule ->
                val index = modules.indexOfFirst { it.code == module.code }
                if (index != -1) modules[index] = updatedModule

                CoroutineScope(Dispatchers.IO).launch {
                    val success = updateModuleInFirestore(updatedModule)
                    println(if (success) "✅ Module updated" else "❌ Update failed")
                    status = success
                    showDialog = true
                }

                moduleToEdit = null
            }
        )
    }
}