import androidx.compose.foundation.layout.Column
import androidx.compose.material.*
import androidx.compose.runtime.*
import java.util.*

@Composable
fun EditModuleDialog(
    module: Module,
    onDismiss: () -> Unit,
    onSave: (Module) -> Unit
) {
    var code by remember { mutableStateOf(module.code) }
    var name by remember { mutableStateOf(module.name) }
    val credit by remember { mutableStateOf(module.credit) }
    var courseList by remember { mutableStateOf(module.courses.joinToString(", ")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Module") },
        text = {
            Column {
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    label = { Text("Module Code") }
                )
                OutlinedTextField(
                    value = name.uppercase(Locale.getDefault()),
                    onValueChange = { name = it },
                    label = { Text("Module Name") }
                )
                OutlinedTextField(
                    value = courseList,
                    onValueChange = { courseList = it },
                    label = { Text("Courses (comma-separated)") }
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val updatedModule = Module(
                    code = code.trim(),
                    name = name.trim(),
                    credit = credit.trim(),
                    courses = courseList.split(",").map { it.trim() }
                )
                onSave(updatedModule)
            }) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
