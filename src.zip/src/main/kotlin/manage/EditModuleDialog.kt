import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import components.DropdownMenuWithLabel
import java.util.*

@Composable
fun EditModuleDialog(
    module: Module,
    onDismiss: () -> Unit,
    onSave: (Module) -> Unit
) {
    var code by remember { mutableStateOf(module.code) }
    var name by remember { mutableStateOf(module.name) }
    var credit by remember { mutableStateOf(module.credit) }
    var courseList by remember { mutableStateOf(module.courses.joinToString(", ")) }

    val nameRequester = remember { FocusRequester() }
    val creditRequester = remember { FocusRequester() }
    val courseRequester = remember { FocusRequester() }

    val tutors = remember { mutableStateListOf<Tutor>() }
    var selectedTutor by remember { mutableStateOf<Tutor?>(null) }
    var isLoadingTutors by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        val fetchedTutors = fetchTutorsFromFirestore()
        tutors.clear()
        tutors.addAll(fetchedTutors.sortedBy { it.tutorName })

        selectedTutor = tutors.firstOrNull { it.email == module.tutor }
        isLoadingTutors = false

        kotlinx.coroutines.delay(100) // <-- wait until composition done
        nameRequester.requestFocus()
    }

    if (isLoadingTutors) {
        // Show loading state instead of dialog
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator()
        }
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Edit Module",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = Color(0xFF0277bd)
            )
        },
        text = {
            Column {
                OutlinedTextField(
                    value = code.uppercase(),
                    enabled = false,
                    onValueChange = { code = it },
                    label = { Text("Module Code") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    singleLine = true,
                    label = { Text("Module Name") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(nameRequester),
                    keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = { creditRequester.requestFocus() })
                )

                OutlinedTextField(
                    value = credit,
                    onValueChange = { input ->
                        if (input.matches(Regex("^\\d{0,2}(\\.\\d?)?$")) || input.isEmpty()) {
                            credit = input
                        }
                    },
                    label = { Text("Module Credit") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(creditRequester),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions.Default.copy(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Next
                    ),
                    keyboardActions = KeyboardActions(onNext = { courseRequester.requestFocus() }),
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color(0xFF4A90E2),
                        focusedLabelColor = Color(0xFF4A90E2),
                        cursorColor = Color(0xFF4A90E2)
                    )
                )

                Spacer(Modifier.height(8.dp))

                DropdownMenuWithLabelModern(
                    label = "Tutor",
                    options = tutors.map { it.tutorName },
                    selectedOption = selectedTutor?.tutorName ?: "",
                    onOptionSelected = { index ->
                        selectedTutor = tutors[index]
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(Modifier.height(8.dp))

                OutlinedTextField(
                    value = courseList,
                    singleLine = true,
                    onValueChange = { courseList = it },
                    label = { Text("Courses (comma-separated)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(courseRequester),
                    keyboardOptions = KeyboardOptions.Default.copy(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            val updatedModule = Module(
                                code = code.trim(),
                                name = name.trim(),
                                credit = credit.trim(),
                                courses = courseList.split(",").map { it.trim() },
                                tutor = selectedTutor?.email ?: module.tutor
                            )
                            onSave(updatedModule)
                        }
                    )
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val updatedModule = Module(
                    code = code.trim(),
                    name = name.trim(),
                    credit = credit.trim(),
                    courses = courseList.split(",").map { it.trim() },
                    tutor = selectedTutor?.email ?: module.tutor
                )
                onSave(updatedModule)
            }) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}


