import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import components.DropdownMenuWithLabel
import java.util.*

@Composable
fun EditModuleDialog(
    module: Module,
    onDismiss: () -> Unit,
    onSave: (Module) -> Unit
) {
    var code by remember { mutableStateOf(module.code) }
    val nameRequester = remember { FocusRequester() }
    val creditRequester = remember { FocusRequester() }
    val courseRequester = remember { FocusRequester() }
    var name by remember { mutableStateOf(module.name) }
    var credit by remember { mutableStateOf(module.credit) }
    var courseList by remember { mutableStateOf(module.courses.joinToString(", ")) }
LaunchedEffect(Unit){
    nameRequester.requestFocus()
}
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(
            "Edit Module",
            fontWeight = FontWeight.Bold,
            fontSize = 20.sp,
            color = Color(0xFF0277bd)) },
        text = {
            Column {
                //Module Code
                OutlinedTextField(
                    value = code.toUpperCase(),
                    enabled = false,
                    onValueChange = { code = it },
                    label = { Text("Module Code") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                //module name
                OutlinedTextField(
                    value = name.toUpperCase(),
                    onValueChange = { name = it },
                    singleLine = true,
                    label = { Text("Module Name") },
                    modifier = Modifier.fillMaxWidth().focusRequester(nameRequester),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = {creditRequester.requestFocus()})
                )
                //credit
                OutlinedTextField(
                    value = credit,
                    onValueChange = { input ->
                        if (input.matches(Regex("^\\d{0,2}(\\.\\d?)?$")) || input.isEmpty()) {
                            credit = input
                        }
                    },
                    label = { Text("Module Credit") },
                    modifier = Modifier.fillMaxWidth().focusRequester(creditRequester),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions.Default.copy(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = {courseRequester.requestFocus()}),
                            colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color(0xFF4A90E2),
                        focusedLabelColor = Color(0xFF4A90E2),
                        cursorColor = Color(0xFF4A90E2)
                    )
                )
                OutlinedTextField(
                    modifier = Modifier.focusRequester(courseRequester),
                    value = courseList,
                    singleLine = true,
                    onValueChange = { courseList = it },
                    label = { Text("Courses (comma-separated)")

                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            val updatedModule = Module(
                                code = code.trim(),
                                name = name.trim(),
                                credit = credit.trim(),
                                courses = courseList.split(",").map { it.trim() }
                            )
                            onSave(updatedModule)
                        }
                    )
                )

            }
        },
        confirmButton = {
            Button(onClick = {
                val updatedModule = Module(
                    code = code.trim(),
                    name = name.trim(),
                    credit = credit.trim(),
                    courses = courseList.split(",").map { it.trim() }
                )
                onSave(updatedModule)
            }) {
                Text("Save")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
