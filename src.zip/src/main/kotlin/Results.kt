import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@Composable
fun Results(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()

    // State holders
    var students by remember { mutableStateOf(listOf<Student>()) }
    var modules by remember { mutableStateOf(listOf<Module>()) }
    var selectedProgram by remember { mutableStateOf<String?>(null) }
    var selectedSemester by remember { mutableStateOf<String?>(null) }
    var selectedModule by remember { mutableStateOf<String?>(null) }
    var sortAscending by remember { mutableStateOf(true) }

    // Load initial data
    LaunchedEffect(Unit) {
        scope.launch {
            students = fetchStudentsFromFirestore()
            modules = fetchModulesFromFirestore()
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(20.dp)
    ) {
        // 🔙 Back button
        Button(
            onClick = onBack,
            modifier = Modifier.align(Alignment.Start)
        ) {
            Text("⬅ Back")
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Top bar with filters
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            DropdownFilter("Program", students.map { it.program }.distinct(), selectedProgram) {
                selectedProgram = it
            }
            DropdownFilter("Semester", students.map { it.semester }.distinct(), selectedSemester) {
                selectedSemester = it
            }
            DropdownFilter("Module", modules.map { it.name }, selectedModule) {
                selectedModule = it
            }

            // Sort button
            Button(onClick = { sortAscending = !sortAscending }) {
                Text(if (sortAscending) "Sort: NTA ↑" else "Sort: NTA ↓")
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Results list
        val filteredStudents = students
            .filter { student ->
                (selectedProgram == null || student.program == selectedProgram) &&
                        (selectedSemester == null || student.semester == selectedSemester)
            }
            .let {
                if (sortAscending) it.sortedBy { s -> s.ntaLevel }
                else it.sortedByDescending { s -> s.ntaLevel }
            }

        LazyColumn(modifier = Modifier.fillMaxSize()) {
            items(filteredStudents) { student ->
                StudentResultCard(student = student, selectedModule = selectedModule)
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
fun DropdownFilter(
    label: String,
    options: List<String>,
    selectedOption: String?,
    onSelect: (String?) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    Box {
        OutlinedButton(onClick = { expanded = true }) {
            Text(selectedOption ?: label)
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            DropdownMenuItem(onClick = { onSelect(null); expanded = false }) {
                Text("All $label")
            }
            options.forEach { option ->
                DropdownMenuItem(onClick = { onSelect(option); expanded = false }) {
                    Text(option)
                }
            }
        }
    }
}

@Composable
fun StudentResultCard(student: Student, selectedModule: String?) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = 8.dp
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("👤 ${student.studentName}", style = MaterialTheme.typography.h6)
            Text("📘 Reg No: ${student.regNo}")
            Text("🎓 Program: ${student.program} | Semester: ${student.semester}")
            Text("📊 NTA Level: ${student.ntaLevel}")

            Spacer(modifier = Modifier.height(8.dp))

            // Load student grades
            var grades by remember { mutableStateOf<Map<String, Grade>>(emptyMap()) }
            LaunchedEffect(student) {
                val loadedList = selectedModule?.let { loadGradesForModule(Database.projectId, it,"2024/2025") }
                if (loadedList != null) {
                    grades = loadedList.associateBy { it.studentId }
                } // convert list -> map
            }


            if (grades.isNotEmpty()) {
                Divider(modifier = Modifier.padding(vertical = 8.dp))
                Text("Results:", style = MaterialTheme.typography.subtitle1)

                grades.values.forEach { grade ->
                    if (selectedModule == null || grade.moduleCode == selectedModule) {
                        Text("• ${grade.moduleCode}: Total = ${grade.total}")
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    "Courses: ${grades.values.joinToString(", ") { it.moduleCode }}",
                    style = MaterialTheme.typography.body2
                )

                // GPA
                val gpa = grades.values.map { it.total }.average()
                Text("⭐ GPA: %.2f".format(gpa), style = MaterialTheme.typography.subtitle1)
            } else {
                Text("No grades available", style = MaterialTheme.typography.body2)
            }
        }
    }
}
