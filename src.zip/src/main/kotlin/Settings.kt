import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Settings() {
    var showPasswordSection by remember { mutableStateOf(false) }
    var showSupportSection by remember { mutableStateOf(false) }

    var isUpdating by remember { mutableStateOf(false) }
    var isSending by remember { mutableStateOf(false) }

    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    val coroutineScope = rememberCoroutineScope()
    var status by remember { mutableStateOf(true) }
    var showDialog by remember { mutableStateOf(false) }

    if (showDialog) {
        TimedDialog(status) { showDialog = false }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 600.dp)
                .verticalScroll(rememberScrollState())
                .background(
                    color = Color.White.copy(alpha = 0.95f),
                    shape = RoundedCornerShape(16.dp)
                )
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {

            // 🏷️ Title
            Text(
                text = "Settings",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = GradeMateColors.Primary
                ),
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // 🔒 Change Password Card
            SettingsCard(
                icon = "lock.png",
                title = "Change Password",
                expanded = showPasswordSection,
                onClick = { showPasswordSection = !showPasswordSection }
            ) {
                AnimatedVisibility(visible = showPasswordSection) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        PasswordInput(
                            password = currentPassword,
                            onPasswordChange = { currentPassword = it },
                            label = "Current Password"
                        )
                        PasswordInput(
                            password = newPassword,
                            onPasswordChange = { newPassword = it },
                            label = "New Password"
                        )

                        Button(
                            onClick = {
                                isUpdating = true
                                coroutineScope.launch(Dispatchers.IO) {
                                    val success = changePassword(newPassword)
                                    withContext(Dispatchers.Main) {
                                        isUpdating = false
                                        showDialog = true
                                        status = success
                                        if (success) {
                                            showPasswordSection = false
                                            Global.pd.value = newPassword
                                            currentPassword = ""
                                            newPassword = ""
                                        }
                                    }
                                }
                            },
                            enabled = !isUpdating &&
                                    currentPassword.isNotEmpty() &&
                                    newPassword.isNotEmpty() && currentPassword == Global.pd.value
                                    && !newPassword.equals(currentPassword,ignoreCase = false)
                            ,
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = GradeMateColors.Primary
                            )
                        ) {
                            if (isUpdating) {
                                CircularProgressIndicator(
                                    modifier = Modifier
                                        .size(22.dp)
                                        .padding(2.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Updating...")
                            } else {
                                Text("Update Password")
                            }
                        }
                    }
                }
            }

            // 📧 Online Support Card
            SettingsCard(
                icon = "email.png",
                title = "Online Support",
                expanded = showSupportSection,
                onClick = { showSupportSection = !showSupportSection }
            ) {
                AnimatedVisibility(visible = showSupportSection) {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = message,
                            onValueChange = { message = it },
                            label = { Text("Write your message") },
                            maxLines = 4,
                            modifier = Modifier.fillMaxWidth(),
                            textStyle = TextStyle(fontSize = 16.sp)
                        )

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = {
                                    isSending = true
                                    coroutineScope.launch(Dispatchers.IO) {
                                        val success = sendEmail(
                                            to = listOf("lennyflorence2000@gmail.com"),
                                            subject = "Online Support From Grademate",
                                            body = message,
                                            attachment = null
                                        )
                                        withContext(Dispatchers.Main) {
                                            isSending = false
                                            showDialog = true
                                            status = success
                                            if (success) {
                                                message = ""
                                                showSupportSection = false
                                            }
                                        }
                                    }
                                },
                                enabled = message.isNotEmpty() && !isSending,
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = GradeMateColors.Primary
                                )
                            ) {
                                if (isSending) {
                                    CircularProgressIndicator(
                                        modifier = Modifier
                                            .size(22.dp)
                                            .padding(2.dp),
                                        color = Color.White,
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Sending...")
                                } else {
                                    Text("Send")
                                }
                            }

                            OutlinedButton(
                                onClick = {
                                    message = ""
                                    showSupportSection = false
                                },
                                modifier = Modifier.weight(1f),
                                enabled = !isSending
                            ) {
                                Text("Cancel")
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun SettingsCard(
    icon: String,
    title: String,
    expanded: Boolean,
    onClick: () -> Unit,
    content: @Composable () -> Unit
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(6.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.95f)
        )
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .animateContentSize()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onClick() }
            ) {
                Icon(
                    painter = painterResource(icon),
                    contentDescription = null,
                    tint = GradeMateColors.Primary,
                    modifier = Modifier.size(30.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = GradeMateColors.Primary,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    painter = if (expanded) painterResource("up.png") else  painterResource("down.png"),
                    contentDescription = null,
                    modifier = Modifier.size(22.dp),
                    tint = GradeMateColors.Primary
                )
            }

            if (expanded) {
                Spacer(Modifier.height(8.dp))
                Divider(color = Color.Gray.copy(alpha = 0.2f), thickness = 1.dp)
                Spacer(Modifier.height(8.dp))
                content()
            }
        }
    }
}

@Composable
fun PasswordInput(
    password: String,
    onPasswordChange: (String) -> Unit,
    label: String = "Password"
) {
    var passwordVisible by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = password,
        onValueChange = { if (it.length <= 30) onPasswordChange(it) },
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        textStyle = TextStyle(
            color = GradeMateColors.TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium
        ),
        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
        trailingIcon = {
            val icon = if (passwordVisible) "hide.png" else "show.png"
            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                Icon(
                    painter = painterResource(icon),
                    modifier = Modifier.size(22.dp),
                    contentDescription = null,
                    tint = GradeMateColors.Primary
                )
            }
        },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
    )
}
