package Results

fun formatResultTitle(nta: String, semester: String, course: String, intake: String): String {
    return "NTA Level $nta, Semester $semester — $course, $intake Intake Results"
}
