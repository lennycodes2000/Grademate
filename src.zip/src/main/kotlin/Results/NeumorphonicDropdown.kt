import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.TextFieldDefaults
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SmallerNeumorphicDropDown(
    label: String,
    options: List<String>,
    selectedOption: String,
    onOptionSelected: (Int) -> Unit,
    currentAction: FocusRequester,
    nextAction: () -> Unit,
    modifier: Modifier = Modifier,
    iconRes: String? = null
) {
    var expanded by  remember {
        mutableStateOf(false)
    }

    Column(modifier = modifier) {
        Text(label, color = Color.Gray, fontSize = 13.sp)

        Box(
            modifier = Modifier
                .padding(top = 4.dp)
                .background(
                    color = Color(0xFFE0E0E0),
                    shape = RoundedCornerShape(12.dp)
                )
                .padding(4.dp)
        ) {
            androidx.compose.material.OutlinedTextField(
                value = selectedOption,
                onValueChange = {},
                readOnly = true,
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp)
                    .background(Color(0xFFE0E0E0), RoundedCornerShape(12.dp))
                    .focusRequester(currentAction),
                trailingIcon = {
                    if (iconRes != null) {
                        Icon(
                            painter = painterResource(iconRes),
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                            tint = Color(0xFF0288D1)
                        )
                    }
                },
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    backgroundColor = Color.Transparent,
                    focusedBorderColor = Color(0xFF0288d1),
                    unfocusedBorderColor = Color(0xFF81d4fa),
                    cursorColor = Color(0xFF0288d1),
                    focusedLabelColor = Color(0xFF0288d1)
                )
            )

            DropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false },
                modifier = Modifier.background(Color.White)
            ) {
                options.forEachIndexed { index, option ->
                    DropdownMenuItem(
                        text = { Text(option, overflow = TextOverflow.Ellipsis) },
                        onClick = {
                            expanded = false
                            onOptionSelected(index)
                        }
                    )
                }
            }

            // Open dropdown click area
            Spacer(
                modifier = Modifier
                    .matchParentSize()
                    .clickable { expanded = !expanded }
            )
        }
    }
}
