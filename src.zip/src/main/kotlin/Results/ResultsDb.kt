import io.ktor.client.call.*
import io.ktor.client.request.*
import io.ktor.http.*

suspend fun loadGrades(): List<Grade> {
    val url = "https://firestore.googleapis.com/v1/projects/${Database.projectId}/databases/(default)/documents:runQuery"

    val requestBody = """
        {
          "structuredQuery": {
            "from": [{ "collectionId": "grades" }]
          }
        }
    """.trimIndent()

    return try {
        val response = NetworkClient.http.post(url) {
            contentType(ContentType.Application.Json)
            setBody(requestBody)
        }

        val results = response.body<List<FirestoreQueryResponse>>()

        results.mapNotNull { queryResp ->
            queryResp.document?.fields?.toGrade()
        }
    } catch (e: Exception) {
        println("❌ Failed to load grades: ${e.message}")
        emptyList()
    }
}

//Function to get the point
fun getPoint(ntaLevel: Int, total: Double, ueMark: Double): Double {
    return if (ntaLevel != 6) {
        when {
            ueMark < 20.0 -> 0.0
            total >= 80 -> 4.0
            total >= 65 -> 3.0
            total >= 50 -> 2.0
            total >= 40 -> 1.0
            else -> 0.0
        }
    } else {
        when {
            ueMark < 20.0 -> 0.0
            total >= 75 -> 5.0
            total >= 65 -> 4.0
            total >= 55 -> 3.0
            total >= 45 -> 2.0
            total >= 35 -> 1.0
            else -> 0.0
        }
    }
}

//functioin to get the award name
fun awardName(myGPA:Double,ntaLevel: Int): String {
    return if (ntaLevel != 6) {
        when {
            myGPA >= 3.5 -> "First Class"
            myGPA >= 3.0 -> "Second Class"
            myGPA >= 2.0 -> "Pass"
            else -> "Unassigned"
        }
    } else {
        when {
            myGPA >= 4.4 -> "First Class"
            myGPA >= 3.5 -> "Upper Second Class"
            myGPA >= 2.7 -> "Second Class"
            myGPA >= 2.0 -> "Pass"
            else -> "Unassigned"
        }
    }
}