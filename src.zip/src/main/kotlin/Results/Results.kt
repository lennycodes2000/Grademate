import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import components.Constants
import components.Constants.courseList
import components.Constants.intake
import components.Constants.ntaLevels
import components.Constants.semesters

@Composable
fun Results(onBack: () -> Unit) {
    var selectedCourse by remember { mutableStateOf("") }
    val courseRequester = remember { FocusRequester() }

    var selectedNta by remember { mutableStateOf("") }
    val ntaRequester = remember { FocusRequester() }

    var selectedSemester by remember { mutableStateOf("") }
    val semesterRequester = remember { FocusRequester() }

    var selectedIntake by remember { mutableStateOf("") }
    val intakeRequester = remember { FocusRequester() }

    val avgGPA by remember { mutableStateOf(4.5) }
    var countTotal by remember { mutableStateOf(125) }
    val countFailed by remember { mutableStateOf(5) }
    val countPassed by remember { mutableStateOf(120) }

    Scaffold(
        bottomBar = {
            if(countTotal > 0){
                // 📊 Sticky bottom summary bar
                Surface(
                    tonalElevation = 3.dp,
                    shadowElevation = 6.dp,
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Left side: summary counts
                        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                            Text(
                                "Total: $countTotal",
                                style = MaterialTheme.typography.bodyLarge.copy(fontSize = 18.sp),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                "✅ Passed: $countPassed",
                                style = MaterialTheme.typography.bodyLarge.copy(fontSize = 18.sp),
                                color = Color(0xFF2E7D32) // green
                            )
                            Text(
                                "❌ Failed: $countFailed",
                                style = MaterialTheme.typography.bodyLarge.copy(fontSize = 18.sp),
                                color = Color(0xFFC62828) // red
                            )
                        }

                        // Right side: export button
                        Button(
                            onClick = { /* TODO: Export action */ },
                            colors = ButtonDefaults.buttonColors(containerColor = GradeMateColors.Primary),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)
                        ) {
                            Icon(
                                painter = painterResource("export.png"),
                                contentDescription = null,
                                modifier = Modifier.size(22.dp),
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Export Results", fontSize = 16.sp, color = Color.White)
                        }
                    }
                }
            }

        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0F0F3))
                .padding(innerPadding)
                .padding(20.dp)
        ) {
            // 🔙 Back button
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0288D1)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.padding(8.dp)
            ) {
                Text("⬅ Back", color = Color.White, fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = if (selectedSemester.isNotEmpty() &&
                    selectedSemester != semesters[0] &&
                    selectedNta != ntaLevels[0] &&
                    selectedCourse != courseList[0] &&
                    selectedIntake.isNotEmpty()
                ) {
                    "NTA Level $selectedNta Semester $selectedSemester - $selectedCourse $selectedIntake Intake Results"
                } else {
                    "All Students Results"
                },
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = GradeMateColors.Primary
                ),
                modifier = Modifier.padding(vertical = 12.dp)
            )

            // Centered top bar with dropdowns
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.Bottom
            ) {
                SmallerNeumorphicDropDown(
                    label = "Course",
                    options = courseList,
                    selectedOption = selectedCourse,
                    onOptionSelected = { selectedCourse = courseList[it] },
                    currentAction = courseRequester,
                    nextAction = {},
                    modifier = Modifier.width(200.dp),
                    iconRes = "book.png"
                )

                Spacer(modifier = Modifier.width(4.dp))

                SmallerNeumorphicDropDown(
                    label = "NTA Level",
                    options = ntaLevels,
                    selectedOption = selectedNta,
                    onOptionSelected = { selectedNta = ntaLevels[it] },
                    currentAction = ntaRequester,
                    nextAction = {},
                    modifier = Modifier.width(200.dp),
                    iconRes = "school.png"
                )

                Spacer(modifier = Modifier.width(4.dp))

                SmallerNeumorphicDropDown(
                    label = "Semester",
                    options = semesters,
                    selectedOption = selectedSemester,
                    onOptionSelected = { selectedSemester = semesters[it] },
                    currentAction = semesterRequester,
                    nextAction = {},
                    modifier = Modifier.width(200.dp),
                    iconRes = "daterange.png"
                )

                Spacer(modifier = Modifier.width(4.dp))

                SmallerNeumorphicDropDown(
                    label = "Intake",
                    options = intake,
                    selectedOption = selectedIntake,
                    onOptionSelected = { selectedIntake = intake[it] },
                    currentAction = intakeRequester,
                    nextAction = {},
                    modifier = Modifier.width(200.dp),
                    iconRes = "intake.png"
                )

                Spacer(modifier = Modifier.width(20.dp))

                      if(countTotal > 0){
                          // GPA card
                          Card(
                              shape = RoundedCornerShape(16.dp),
                              colors = CardDefaults.cardColors(containerColor = Color.White),
                              elevation = CardDefaults.cardElevation(8.dp),
                              modifier = Modifier.align(Alignment.Bottom)
                          ) {
                              Column(
                                  modifier = Modifier.padding(16.dp),
                                  horizontalAlignment = Alignment.CenterHorizontally
                              ) {
                                  Text("Avg GPA", color = Color.Gray, fontSize = 14.sp)
                                  Text(
                                      "$avgGPA",
                                      color = Color(0xFF0288D1),
                                      fontSize = 22.sp,
                                      fontWeight = FontWeight.Bold
                                  )
                              }
                          }
                      }

            }


// LazyColumn displaying students
                    if (countTotal > 0) {
                        // ✅ Case 1: Show table header (and items below in LazyColumn)
                        Row(
                            modifier = Modifier
                                .padding(top = 20.dp, bottom = 8.dp)
                                .fillMaxWidth()
                                .background(GradeMateColors.Primary)
                                .padding(8.dp)
                        ) {
                            ResultHeaderText("S/N", 0.1f)
                            ResultHeaderText("Registration Number", 0.2f)
                            ResultHeaderText("Full Name", 0.35f)
                            ResultHeaderText("GPA", 0.15f)
                            ResultHeaderText("Remarks", 0.35f)
                        }
                    } else if (
                        selectedSemester.isNotEmpty() &&
                        selectedSemester != semesters[0] &&
                        selectedNta != ntaLevels[0] &&
                        selectedCourse != courseList[0] &&
                        selectedIntake.isNotEmpty()
                    ) {
                        // ✅ Case 2: Filters applied but no data
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                painter = painterResource("warning.png"),
                                tint = GradeMateColors.Primary,
                                contentDescription = "No students",
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "No students found for the selected criteria",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 16.sp
                                )
                            )
                        }
                    } else {
                        // ✅ Case 3: No filters yet
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                painter = painterResource("search.png"),
                                tint = GradeMateColors.Primary,
                                contentDescription = "Search criteria",
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Please select criteria to view results",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 16.sp
                                )
                            )
                        }
                    }



            // Student Rows
            LazyColumn {
              val studentsList =   fakeStudents.filter {
                    it.status != "GRADUATED" && it.intake == selectedIntake
                            && it.semester == selectedSemester && it.ntaLevel == selectedNta && it.program == selectedCourse
                }
                countTotal = studentsList.size
                itemsIndexed(studentsList) { index, student ->
                    Surface(
                        tonalElevation = if (index % 2 == 0) 0.dp else 2.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ResultDataText("${index + 1}", 0.1f)
                            ResultDataText(student.regNo, 0.2f)
                            ResultDataText(student.studentName, 0.35f)
                            ResultDataText("3.7", 0.15f, highlight = true)
                            ResultDataText("Passed", 0.2f, highlight = true)
                        }
                    }
                }
            }
        }
    }
}
// Row Header
@Composable
fun ResultHeaderText(text: String, weight: Float) {
    Text(
        text = text,
        modifier = Modifier.fillMaxWidth(weight),
        fontWeight = FontWeight.SemiBold,
        color = GradeMateColors.Background,
        fontSize = 15.sp,
        style = MaterialTheme.typography.labelLarge
    )
}

// Row Data
@Composable
fun ResultDataText(text: String, weight: Float, highlight: Boolean = false) {
    Text(
        text = text,
        modifier = Modifier.fillMaxWidth(weight),
        fontWeight = if (highlight) FontWeight.SemiBold else FontWeight.Normal,
        color = if (highlight) GradeMateColors.Primary else GradeMateColors.TextPrimary,
        fontSize = 15.sp,
        style = MaterialTheme.typography.bodyMedium
    )
}
