import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Results(
    onBack: () -> Unit,
    students: SnapshotStateList<Student>,
    modules: SnapshotStateList<Module>
) {
    val tabs = listOf("Current Students", "Graduated Students")
    var selectedTabIndex by remember { mutableStateOf(0) }

    Scaffold { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0F0F3))
                .padding(innerPadding)
                .padding(20.dp)
        ) {
            // 🔙 Back Button
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0288D1)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.padding(8.dp)
            ) {
                Text("⬅ Back", color = Color.White, fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.height(8.dp))

            //  Tabs Row
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = GradeMateColors.Primary.copy(alpha = 0.1f),
                contentColor = GradeMateColors.Primary,
                modifier = Modifier.fillMaxWidth(),
                indicator = { tabPositions ->
                    TabRowDefaults.Indicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = GradeMateColors.Primary
                    )
                }
            )  {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                title,
                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTabIndex == index) GradeMateColors.Primary else Color.Gray
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 🔹 Show Composables based on tab
            when (selectedTabIndex) {
                0 -> CurrentStudents(students, modules)
                1 -> GraduatedStudents()
            }
        }
    }
}




