import Results.formatResultTitle
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import components.Constants.courseList
import components.Constants.intake
import components.Constants.ntaLevels
import components.Constants.semesters
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode

@Composable
fun Results(
    onBack: () -> Unit,
    students: SnapshotStateList<Student>,
    modules: SnapshotStateList<Module>
) {
    // 📌 Store precomputed GPA per student
    val gpaMap = remember { mutableStateMapOf<String, Double>() }
    val selectedGPA = remember { mutableStateOf(0.0) }
    // 🔹 Filters
    var selectedCourse by remember { mutableStateOf("") }
    val courseRequester = remember { FocusRequester() }

    var selectedNta by remember { mutableStateOf("") }
    val ntaRequester = remember { FocusRequester() }

    var selectedSemester by remember { mutableStateOf("") }
    val semesterRequester = remember { FocusRequester() }

    var selectedIntake by remember { mutableStateOf("") }
    val intakeRequester = remember { FocusRequester() }

    // 🔹 Local states
    var avgGPA by remember { mutableStateOf(0.0) }
    var countTotal by remember { mutableStateOf(0) }
    var countPassed by remember { mutableStateOf(0) }
    val grades = remember { mutableStateListOf<Grade>() }
    var studentClicked by remember { mutableStateOf(false) }
    var selectedRegNo by remember { mutableStateOf<String?>(null) }
    // ✅ Load Firestore data ONCE
    val scope = rememberCoroutineScope()
    var isLoading by remember { mutableStateOf(false) }
    // 🪟 Dialog if student clicked
    if (studentClicked && selectedRegNo != null) {
        gpaMap[selectedRegNo]?.let { gpa ->
            ResultDialog(
                onDismiss = { studentClicked = false },
                result = students.find { it.regNo == selectedRegNo },
                currentGPA = gpa
            )
        }
    }
   val criteriaChosen =   (selectedSemester.isNotEmpty() &&
        selectedSemester != semesters[0] &&
        selectedNta != ntaLevels[0] &&
        selectedCourse != courseList[0] &&
        selectedIntake.isNotEmpty())
    LaunchedEffect(Unit) {
        if (students.isEmpty() || modules.isEmpty() || grades.isEmpty()) {
            isLoading = true
            scope.launch {
                try {
                    grades.clear()
                    grades.addAll(loadGrades())

                    modules.clear()
                    modules.addAll(fetchModulesFromFirestore())

                    students.clear()
                    students.addAll(fetchStudentsFromFirestore())
                    // Calculate GPA for each student once
                    gpaMap.clear()
                    students.forEach { student ->
                        val studentGrades = grades.filter {
                            it.ntaLevel == student.ntaLevel &&
                                    it.semester == student.semester &&
                                    it.studentId == student.regNo
                        }
                        var PN = 0.0
                        var N = 0.0
                        for (grade in studentGrades) {
                            val creditStr = modules.find { it.code == grade.moduleCode }?.credit ?: ""
                            val credit = creditStr.toDoubleOrNull() ?: 0.0
                            val examMark = grade.examMark.trim().toDoubleOrNull() ?: 0.0
                            PN += credit * getPoint(student.ntaLevel.trim().toInt(), grade.total, examMark)
                            N += credit
                        }
                        gpaMap[student.regNo] =
                            if (N != 0.0) BigDecimal(PN / N).setScale(1, RoundingMode.HALF_UP).toDouble() else 0.0
                    }
                } catch (e: Exception) {
                    println("❌ Firestore error: ${e.message}")
                } finally {
                    isLoading = false
                }
            }
        }
    }

    Scaffold(
        bottomBar = {
            if (countTotal > 0) {
                // 📊 Sticky bottom summary bar
                Surface(
                    tonalElevation = 3.dp,
                    shadowElevation = 6.dp,
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Left: summary
                        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                            Text("Total: $countTotal", fontSize = 18.sp)
                            Text("✅ Passed: $countPassed", fontSize = 18.sp, color = GradeMateColors.Secondary)
                            Text("❌ Failed: ${countTotal - countPassed}", fontSize = 18.sp, color = GradeMateColors.Error)
                            Text(
                                "📊 Avg GPA: $avgGPA" + if (selectedNta.toIntOrNull() != null)
                                    " (${awardName(avgGPA, selectedNta.toInt())})"
                                else "",
                                fontSize = 18.sp,
                                color = GradeMateColors.Primary
                            )
                        }

                        // Right: Export button
                        Button(
                            onClick = { /* TODO: Export */ },
                            colors = ButtonDefaults.buttonColors(containerColor = GradeMateColors.Primary),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)
                        ) {
                            Icon(
                                painter = painterResource("export.png"),
                                contentDescription = null,
                                modifier = Modifier.size(22.dp),
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Export Results", fontSize = 16.sp, color = Color.White)
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0F0F3))
                .padding(innerPadding)
                .padding(20.dp)
        ) {
            // 🔙 Back
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0288D1)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.padding(8.dp)
            ) {
                Text("⬅ Back", color = Color.White, fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Title
            Text(
                text = if (criteriaChosen
                ) {
                    formatResultTitle(selectedNta, selectedSemester, selectedCourse, selectedIntake)
                } else {
                    "All Students Results"
                },
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = GradeMateColors.Primary
                ),
                modifier = Modifier.padding(vertical = 12.dp)
            )

            // 🔽 Filters row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.Bottom
            ) {
                SmallerNeumorphicDropDown("Course", courseList, selectedCourse,
                    { selectedCourse = courseList[it] }, courseRequester, {}, Modifier.width(200.dp), "book.png")
                Spacer(modifier = Modifier.width(4.dp))
                SmallerNeumorphicDropDown("NTA Level", ntaLevels, selectedNta,
                    { selectedNta = ntaLevels[it] }, ntaRequester, {}, Modifier.width(200.dp), "school.png")
                Spacer(modifier = Modifier.width(4.dp))
                SmallerNeumorphicDropDown("Semester", semesters, selectedSemester,
                    { selectedSemester = semesters[it] }, semesterRequester, {}, Modifier.width(200.dp), "daterange.png")
                Spacer(modifier = Modifier.width(4.dp))
                SmallerNeumorphicDropDown("Intake", intake, selectedIntake,
                    { selectedIntake = intake[it] }, intakeRequester, {}, Modifier.width(200.dp), "intake.png")
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.CenterHorizontally))
            } else {
                // Filtered students
                val studentsList = students.filter {
                    it.status != "GRADUATED" &&
                            it.intake == selectedIntake &&
                            it.semester == selectedSemester &&
                            it.ntaLevel == selectedNta &&
                            it.program == selectedCourse
                }.distinctBy { it.regNo }

                countTotal = studentsList.size

                // GPA calc
                val gpaList = studentsList.map { student ->
                    val studentGrades = grades.filter {
                        it.ntaLevel == student.ntaLevel &&
                                it.semester == student.semester &&
                                it.studentId == student.regNo
                    }
                    var PN = 0.0
                    var N = 0.0
                    for (grade in studentGrades) {
                        val creditStr = modules.find { it.code == grade.moduleCode }?.credit ?: ""
                        val credit = creditStr.toDoubleOrNull() ?: 0.0
                        val examMark = grade.examMark.trim().toDoubleOrNull() ?: 0.0
                        PN += credit * getPoint(student.ntaLevel.trim().toInt(), grade.total, examMark)
                        N += credit
                    }
                    if (N != 0.0) BigDecimal(PN / N).setScale(1, RoundingMode.HALF_UP).toDouble() else 0.0
                }

                countPassed = gpaList.count { it >= 2.0 }
                avgGPA = if (studentsList.isNotEmpty()) {
                    BigDecimal(
                        studentsList.map { gpaMap[it.regNo] ?: 0.0 }.sum() / studentsList.size
                    ).setScale(1, RoundingMode.HALF_UP).toDouble()
                } else 0.0
                if (countTotal > 0) {
                    // Table header
                    Row(
                        modifier = Modifier
                            .padding(top = 20.dp, bottom = 8.dp)
                            .fillMaxWidth()
                            .background(GradeMateColors.Primary)
                            .padding(8.dp)
                    ) {
                        ResultHeaderText("S/N", 0.1f)
                        ResultHeaderText("Registration Number", 0.2f)
                        ResultHeaderText("Full Name", 0.3f)
                        ResultHeaderText("GPA", 0.15f)
                        ResultHeaderText("Classification", 0.3f)
                        ResultHeaderText("Remarks", 0.35f)
                    }

                    // Students
                    LazyColumn {
                        itemsIndexed(studentsList) { index, student ->
                            val myGPA = gpaList[index]
                            val classification = awardName(myGPA, student.ntaLevel.trim().toInt())
                            val myRemark = if (myGPA >= 2.0) "Passed" else "Failed"
                            val isSelected = student.regNo == selectedRegNo
                            Surface(
                                tonalElevation = if (index % 2 == 0) 0.dp else 2.dp,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    selectedRegNo = student.regNo
                                    studentClicked = true
                                }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 6.dp)
                                        .background(
                                            if (isSelected) GradeMateColors.Primary.copy(alpha = 0.15f)
                                            else Color.Transparent
                                        ),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    ResultDataText("${index + 1}.", 0.1f)
                                    ResultDataText(student.regNo, 0.2f)
                                    ResultDataText(student.studentName, 0.3f)
                                    ResultDataText("$myGPA", 0.15f, highlight = true)
                                    ResultDataText(classification, 0.3f, highlight = true)
                                    ResultRemarkCell(myRemark, 0.2f)
                                }
                            }
                        }
                    }
                } else {
                    // Empty state: handle two cases
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            painter = painterResource("search.png"),
                            tint = GradeMateColors.Primary,
                            contentDescription = null,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (criteriaChosen)
                                "No results found for the selected criteria"
                            else
                                "Please select criteria to view results",
                            fontSize = 16.sp
                        )
                    }
                }

            }
        }
    }
}
