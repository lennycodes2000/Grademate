import Results.formatResultTitle
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import components.Constants.courseList
import components.Constants.intake
import components.Constants.ntaLevels
import components.Constants.semesters
import java.math.BigDecimal
import java.math.RoundingMode

@Composable
fun Results(onBack: () -> Unit, students: SnapshotStateList<Student>,modules:SnapshotStateList<Module>) {
    var selectedCourse by remember { mutableStateOf("") }
    val courseRequester = remember { FocusRequester() }

    var selectedNta by remember { mutableStateOf("") }
    val ntaRequester = remember { FocusRequester() }

    var selectedSemester by remember { mutableStateOf("") }
    val semesterRequester = remember { FocusRequester() }

    var selectedIntake by remember { mutableStateOf("") }
    val intakeRequester = remember { FocusRequester() }

    var avgGPA by remember { mutableStateOf(0.0) }
    var countTotal by remember { mutableStateOf(125) }
    var countPassed by remember { mutableStateOf(0) }
    val grades = mutableStateListOf<Grade>()
LaunchedEffect(Unit){
    grades.clear()
    val fetchedGrades = loadGrades()
    grades.addAll(fetchedGrades)
    modules.clear()
    val fetchedModules = fetchModulesFromFirestore()
    modules.addAll(fetchedModules)
    students.clear()
    val fetchedStudents = fetchStudentsFromFirestore()
    students.addAll(fetchedStudents)
}
    Scaffold(
        bottomBar = {
            if(countTotal > 0){
                // 📊 Sticky bottom summary bar
                Surface(
                    tonalElevation = 3.dp,
                    shadowElevation = 6.dp,
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Left side: summary counts
                        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                            Text(
                                "Total: $countTotal",
                                style = MaterialTheme.typography.bodyLarge.copy(fontSize = 18.sp),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                "✅ Passed: $countPassed",
                                style = MaterialTheme.typography.bodyLarge.copy(fontSize = 18.sp),
                                color = GradeMateColors.Secondary // green
                            )
                            Text(
                                "❌ Failed: ${countTotal - countPassed}",
                                style = MaterialTheme.typography.bodyLarge.copy(fontSize = 18.sp),
                                color = GradeMateColors.Error// red
                            )
                            if (selectedNta.isNotBlank() && selectedNta.toIntOrNull() != null) {
                                Text(
                                    "📊 Avg GPA: $avgGPA - ( ${awardName(avgGPA, selectedNta.trim().toInt())} )",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontSize = 18.sp),
                                    color = GradeMateColors.Primary
                                )
                            } else {
                                Text(
                                    "📊 Avg GPA: $avgGPA",
                                    style = MaterialTheme.typography.bodyLarge.copy(fontSize = 18.sp),
                                    color = GradeMateColors.Primary
                                )
                            }
                        }

                        // Right side: export button
                        Button(
                            onClick = { /* TODO: Export action */ },
                            colors = ButtonDefaults.buttonColors(containerColor = GradeMateColors.Primary),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)
                        ) {
                            Icon(
                                painter = painterResource("export.png"),
                                contentDescription = null,
                                modifier = Modifier.size(22.dp),
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Export Results", fontSize = 16.sp, color = Color.White)
                        }
                    }
                }
            }

        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF0F0F3))
                .padding(innerPadding)
                .padding(20.dp)
        ) {
            // 🔙 Back button
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0288D1)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.padding(8.dp)
            ) {
                Text("⬅ Back", color = Color.White, fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = if (selectedSemester.isNotEmpty() &&
                    selectedSemester != semesters[0] &&
                    selectedNta != ntaLevels[0] &&
                    selectedCourse != courseList[0] &&
                    selectedIntake.isNotEmpty()
                ) {
                  formatResultTitle(selectedNta, selectedSemester, selectedCourse, selectedIntake)

                } else {
                    "All Students Results"
                },
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = GradeMateColors.Primary
                ),
                modifier = Modifier.padding(vertical = 12.dp)
            )

            // Centered top bar with dropdowns
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.Bottom
            ) {
                SmallerNeumorphicDropDown(
                    label = "Course",
                    options = courseList,
                    selectedOption = selectedCourse,
                    onOptionSelected = { selectedCourse = courseList[it] },
                    currentAction = courseRequester,
                    nextAction = {},
                    modifier = Modifier.width(200.dp),
                    iconRes = "book.png"
                )

                Spacer(modifier = Modifier.width(4.dp))

                SmallerNeumorphicDropDown(
                    label = "NTA Level",
                    options = ntaLevels,
                    selectedOption = selectedNta,
                    onOptionSelected = { selectedNta = ntaLevels[it] },
                    currentAction = ntaRequester,
                    nextAction = {},
                    modifier = Modifier.width(200.dp),
                    iconRes = "school.png"
                )

                Spacer(modifier = Modifier.width(4.dp))

                SmallerNeumorphicDropDown(
                    label = "Semester",
                    options = semesters,
                    selectedOption = selectedSemester,
                    onOptionSelected = { selectedSemester = semesters[it] },
                    currentAction = semesterRequester,
                    nextAction = {},
                    modifier = Modifier.width(200.dp),
                    iconRes = "daterange.png"
                )

                Spacer(modifier = Modifier.width(4.dp))

                SmallerNeumorphicDropDown(
                    label = "Intake",
                    options = intake,
                    selectedOption = selectedIntake,
                    onOptionSelected = { selectedIntake = intake[it] },
                    currentAction = intakeRequester,
                    nextAction = {},
                    modifier = Modifier.width(200.dp),
                    iconRes = "intake.png"
                )

                Spacer(modifier = Modifier.width(20.dp))

            }


// LazyColumn displaying students
                    if (countTotal > 0) {
                        // ✅ Case 1: Show table header (and items below in LazyColumn)
                        Row(
                            modifier = Modifier
                                .padding(top = 20.dp, bottom = 8.dp)
                                .fillMaxWidth()
                                .background(GradeMateColors.Primary)
                                .padding(8.dp)
                        ) {
                            ResultHeaderText("S/N", 0.1f)
                            ResultHeaderText("Registration Number", 0.2f)
                            ResultHeaderText("Full Name", 0.3f)
                            ResultHeaderText("GPA", 0.15f)
                            ResultHeaderText("Classification", 0.3f)
                            ResultHeaderText("Remarks", 0.35f)
                        }
                    } else if (
                        selectedSemester.isNotEmpty() &&
                        selectedSemester != semesters[0] &&
                        selectedNta != ntaLevels[0] &&
                        selectedCourse != courseList[0] &&
                        selectedIntake.isNotEmpty()
                    ) {
                        // ✅ Case 2: Filters applied but no data
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                painter = painterResource("warning.png"),
                                tint = GradeMateColors.Primary,
                                contentDescription = "No students",
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "No students found for the selected criteria",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 16.sp
                                )
                            )
                        }
                    } else {
                        // ✅ Case 3: No filters yet
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                painter = painterResource("search.png"),
                                tint = GradeMateColors.Primary,
                                contentDescription = "Search criteria",
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Please select criteria to view results",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 16.sp
                                )
                            )
                        }
                    }
            //STUDENT ROW
            val studentsList = students.filter {
                it.status != "GRADUATED" &&
                        it.intake == selectedIntake &&
                        it.semester == selectedSemester &&
                        it.ntaLevel == selectedNta &&
                        it.program == selectedCourse
            }.distinctBy {
                it.regNo
            }

            countTotal = studentsList.size

// Compute GPA values for all students once
            val gpaList = studentsList.map { student ->
                val studentGrades = grades.filter {
                    it.ntaLevel == student.ntaLevel &&
                            it.semester == student.semester &&
                            it.studentId == student.regNo
                }
                var PN = 0.0
                var N = 0.0
                for (grade in studentGrades) {
                    val creditStr = modules.find { it.code == grade.moduleCode }?.credit ?: ""
                    val credit = creditStr.toDoubleOrNull() ?: 0.0
                    val examMark = grade.examMark.trim().toDoubleOrNull() ?: 0.0
                    PN += credit * getPoint(student.ntaLevel.trim().toInt(), grade.total, examMark)
                    N += credit
                }

                if (N != 0.0) BigDecimal(PN / N).setScale(1, RoundingMode.HALF_UP).toDouble() else 0.0
            }

            countPassed = gpaList.count { it >= 2.0 }

            avgGPA = if (gpaList.isNotEmpty()) {
                BigDecimal(gpaList.sum() / gpaList.size).setScale(1, RoundingMode.HALF_UP).toDouble()
            } else {
                0.0
            }
            LazyColumn {
                itemsIndexed(studentsList) { index, student ->
                    val myGPA = gpaList[index]
                    val classification = awardName(myGPA, student.ntaLevel.trim().toInt())
                    val myRemark = if (myGPA >= 2.0) "Passed" else "Failed"

                    Surface(
                        tonalElevation = if (index % 2 == 0) 0.dp else 2.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ResultDataText("${index + 1}.", 0.1f)
                            ResultDataText(student.regNo, 0.2f)
                            ResultDataText(student.studentName, 0.3f)
                            ResultDataText("$myGPA", 0.15f, highlight = true)
                            ResultDataText(classification, 0.3f, highlight = true)
                            ResultRemarkCell(myRemark, 0.2f)
                        }
                    }
                }
            }


        }
    }
}




