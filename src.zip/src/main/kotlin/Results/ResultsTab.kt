import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ResultsTable(
    studentsList: List<Student>,
    gpaList: List<Double>,
    onSelectStudent: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        // Table header
        Row(
            modifier = Modifier
                .padding(top = 20.dp, bottom = 8.dp)
                .fillMaxWidth()
                .background(GradeMateColors.Primary)
                .padding(8.dp)
        ) {
            ResultHeaderText("S/N", 0.1f)
            ResultHeaderText("Registration Number", 0.2f)
            ResultHeaderText("Full Name", 0.3f)
            ResultHeaderText("GPA", 0.15f)
            ResultHeaderText("Classification", 0.3f)
            ResultHeaderText("Remarks", 0.35f)
        }

        // Table content
        LazyColumn {
            itemsIndexed(studentsList) { index, student ->
                val myGPA = gpaList[index]
                val classification = awardName(myGPA, student.ntaLevel.trim().toInt())
                val myRemark = if (myGPA >= 2.0) "Passed" else "Failed"

                Surface(
                    tonalElevation = if (index % 2 == 0) 0.dp else 2.dp,
                    modifier = Modifier.fillMaxWidth().clickable {
                        onSelectStudent(student.regNo)
                    }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ResultDataText("${index + 1}.", 0.1f)
                        ResultDataText(student.regNo, 0.2f)
                        ResultDataText(student.studentName, 0.3f)
                        ResultDataText("$myGPA", 0.15f, highlight = true)
                        ResultDataText(classification, 0.3f, highlight = true)
                        ResultRemarkCell(myRemark, 0.2f)
                    }
                }
            }
        }
    }
}
