
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ResultRemarkCell(result: String, weight: Float) {
    Row(
        modifier = Modifier.fillMaxWidth(weight),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        when {
            result.equals("Passed", ignoreCase = true) -> {
                Icon(
                    painter = painterResource("tick.png"), // ✅ green tick icon
                    contentDescription = "Passed",
                    tint = GradeMateColors.Secondary, // Green
                    modifier = Modifier.size(20.dp)
                )
            }
            result.equals("Failed", ignoreCase = true) -> {
                Icon(
                    painter = painterResource("x.png"), // ❌ red cross icon
                    contentDescription = "Failed",
                    tint = GradeMateColors.Error, // Red
                    modifier = Modifier.size(20.dp)
                )
            }
            else -> {
                Text(
                    text = result,
                    color = GradeMateColors.TextPrimary,
                    style = MaterialTheme.typography.bodyMedium,
                    fontSize = 14.sp
                )
            }
        }
    }
}