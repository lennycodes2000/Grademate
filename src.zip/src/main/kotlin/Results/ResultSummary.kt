
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
fun ResultSummary(
    iconResId: String,
    totalPassed: Int,
    totalFailed: Int
) {
    val total = totalPassed + totalFailed
    val percentage = if (total > 0) {
        if (iconResId == "tick.png") {
            (totalPassed * 100) / total
        } else {
            (totalFailed * 100) / total
        }
    } else 0

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .background(GradeMateColors.backGradient, shape = RoundedCornerShape(12.dp))
            .padding(top = 4.dp, bottom = 4.dp, start = 16.dp, end = 16.dp)
    ) {
        Icon(
            painter = painterResource(if (iconResId == "tick.png") "tick.png" else "x.png"),
            contentDescription = null,
            tint = if (iconResId == "tick.png") GradeMateColors.Secondary else GradeMateColors.Error,
            modifier = Modifier.size(32.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = if (iconResId == "tick.png") "Passed" else "Failed",
            style = MaterialTheme.typography.bodyMedium.copy(
                color = if (iconResId == "tick.png") GradeMateColors.Secondary else GradeMateColors.Error,
                fontWeight = FontWeight.Bold
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "$percentage%",
            style = MaterialTheme.typography.bodyMedium.copy(
                color = Color.Gray,
                fontWeight = FontWeight.Medium
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
