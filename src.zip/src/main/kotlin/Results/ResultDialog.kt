import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog

@OptIn(ExperimentalMaterial3Api::class)
@Composable

// Function to map numeric marks to grade letters
fun getGradeLetter(totalMark: Double, ueMark: Double?, ntaLevel: Int?): String {
    return if (ntaLevel == 4 || ntaLevel == 5) {
        when {
            ueMark != null && ueMark < 20 -> "TS"
            totalMark >= 80 -> "A"
            totalMark >= 65 -> "B"
            totalMark >= 50 -> "C"
            totalMark >= 40 -> "D"
            else -> "F"
        }
    } else {
        when {
            ueMark != null && ueMark < 20 -> "TS"
            totalMark >= 75 -> "A"
            totalMark >= 65 -> "B+"
            totalMark >= 55 -> "B"
            totalMark >= 45 -> "C"
            totalMark >= 35 -> "D"
            else -> "F"
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultDialog(
    onDismiss: () -> Unit,
    result: Student?,
    currentGPA: Double
) {
    if (result == null) {
        LaunchedEffect(Unit) { onDismiss() }
        return
    }

    val gradeList = remember { mutableStateListOf<Grade>() }
    val moduleList = remember { mutableStateListOf<Module>() }
    var modulesLoaded by remember { mutableStateOf(false) }
    var gpaLoading by remember { mutableStateOf(false) }

    // Load grades & modules for current student only
    LaunchedEffect(Unit) {
        val allGrades = loadGrades()
        gradeList.addAll(
            allGrades.filter {
                it.studentId == result.regNo &&
                        it.ntaLevel == result.ntaLevel &&
                        it.semester == result.semester
            }
        )
        moduleList.addAll(fetchModulesFromFirestore())
        modulesLoaded = true
    }

    Dialog(onDismissRequest = { onDismiss() }) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp)
                .shadow(4.dp, RoundedCornerShape(12.dp))
                .clip(RoundedCornerShape(12.dp))
                .background(GradeMateColors.backGradient)
                .padding(8.dp)
        ) {
            // ---------------- Profile card ----------------
            ElevatedCard(
                colors = CardDefaults.elevatedCardColors(containerColor = GradeMateColors.back1),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 8.dp),
                modifier = Modifier
                    .border(
                        width = 0.5.dp,
                        color = GradeMateColors.Primary,
                        shape = RoundedCornerShape(16.dp)
                    )
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                ) {
                    // ---------------- Header ----------------
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Image(
                            painter = painterResource("person.png"),
                            contentDescription = "Profile Picture",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(70.dp)
                                .clip(CircleShape)
                                .border(3.dp, GradeMateColors.Primary, CircleShape)
                                .shadow(6.dp, CircleShape)
                        )

                        Spacer(modifier = Modifier.width(16.dp))

                        Column(
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = result.studentName,
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = GradeMateColors.Primary,
                                    fontSize = MaterialTheme.typography.titleMedium.fontSize
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = result.regNo,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = Color.Gray,
                                    fontWeight = FontWeight.Medium
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // ---------------- Count passed & failed ----------------
                    val passedCount = gradeList.count { grade ->
                        val ntaLevel = grade.ntaLevel.toIntOrNull()
                        val totalMark = grade.total
                        val ueMark = grade.examMark.toDoubleOrNull()
                        val letter = getGradeLetter(totalMark, ueMark, ntaLevel)
                        letter in listOf("A", "B+", "B", "C")
                    }
                    val failedCount = gradeList.size - passedCount

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ResultSummary("tick.png", totalPassed = passedCount, totalFailed = failedCount)
                        ResultSummary("x.png", totalPassed = passedCount, totalFailed = failedCount)

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            if (gpaLoading) {
                                BouncingDots()
                            } else {
                                GPABox(myGPA = currentGPA)
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = if (currentGPA > 0.0)
                                        awardName(myGPA = currentGPA, ntaLevel = result.ntaLevel.trim().toInt())
                                    else "",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = Color.Gray,
                                        fontWeight = FontWeight.Medium
                                    ),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (!modulesLoaded) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else {
                CourseResult(
                    grades = gradeList,
                    modifier = Modifier.fillMaxSize(),
                    modules = moduleList
                )
            }
        }
    }
}


