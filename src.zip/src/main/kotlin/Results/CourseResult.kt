import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun CourseResult(
    grades: List<Grade>,
    modifier: Modifier = Modifier,
    modules: SnapshotStateList<Module>,
    criteriaChosen: Boolean = false // add flag to know if filters are applied
) {
    val moduleNameCache = remember {
        modules.associate { it.code to it.name }.toMutableMap()
    }

    fun getModuleName(moduleCode: String) = moduleNameCache[moduleCode] ?: "Unknown"
    fun getLevel(input: String?): Char? {
        if (input == null) return null
        // Filter only digits from the string
        val digits = input.filter { it.isDigit() }
        // Return the second digit if exists, else null
        return if (digits.length >= 2) digits[1] else null
    }

    LazyColumn(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        if (grades.isNotEmpty()) {
            itemsIndexed(grades) { _, course ->

                val moduleName = getModuleName(course.moduleCode)

                val courseNameLower = moduleName.lowercase()
                val courseIcon = when {
                    "programming" in courseNameLower -> painterResource("programmin.png")
                    "database" in courseNameLower -> painterResource("database.png")
                    "web" in courseNameLower -> painterResource("web.png")
                    "mathematics" in courseNameLower -> painterResource("maths.png")
                    "statistics" in courseNameLower -> painterResource("maths.png")
                    "graphics" in courseNameLower -> painterResource("graphics.png")
                    "computer networking" in courseNameLower -> painterResource("network.png")
                    "computer communications" in courseNameLower -> painterResource("network.png")
                    "management information system" in courseNameLower -> painterResource("information.png")
                    "development of  information systems" in courseNameLower -> painterResource("information.png")
                    "system analysis" in courseNameLower -> painterResource("sad.png")
                    "computer maintenance" in courseNameLower -> painterResource("maintenance.png")
                    "computer application" in courseNameLower -> painterResource("office.png")
                    "computer software" in courseNameLower -> painterResource("software.png")
                    "data communication" in courseNameLower -> painterResource("network.png")
                    "operating system" in courseNameLower -> painterResource("os.png")
                    "communication skills" in courseNameLower -> painterResource("communication.png")
                    "business communication" in courseNameLower -> painterResource("communication.png")
                    "e-business" in courseNameLower -> painterResource("ebusiness.png")
                    "e-commerce" in courseNameLower -> painterResource("ebusiness.png")
                    "architecture" in courseNameLower -> painterResource("architecture.png")
                    "project" in courseNameLower -> painterResource("project.png")
                    "security" in courseNameLower -> painterResource("security.png")
                    else -> painterResource("regular.png")
                }

                // Grade calculation
                val ntaLevelChar = getLevel(course.moduleCode)
                val ntaLevel = ntaLevelChar?.digitToIntOrNull()
                val totalMark = course.total
                val ueMark = course.examMark.toDoubleOrNull()

                val gradeChar = if (ntaLevel == 4 || ntaLevel == 5) {
                    when {
                        ueMark != null && ueMark < 20 -> "TS"
                        totalMark >= 80 -> "A"
                        totalMark >= 65 -> "B"
                        totalMark >= 50 -> "C"
                        totalMark >= 40 -> "D"
                        else -> "F"
                    }
                } else {
                    when {
                        ueMark != null && ueMark < 20 -> "TS"
                        totalMark >= 75 -> "A"
                        totalMark >= 65 -> "B+"
                        totalMark >= 55 -> "B"
                        totalMark >= 45 -> "C"
                        totalMark >= 35 -> "D"
                        else -> "F"
                    }
                }
                val gradeRemarks = course.examMark.toDoubleOrNull()?.let {
                    if (it < 20) {
                        "Technical Supplementary"
                    } else {
                        if (gradeChar == "D" || gradeChar == "F") "Supplementary" else "Passed"
                    }
                } ?: "Pending"

                val gradeColor = when {
                    gradeRemarks == "Technical Supplementary" -> GradeMateColors.Error
                    gradeChar == "D" || gradeChar == "F" -> GradeMateColors.Error
                    else -> GradeMateColors.Secondary
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.elevatedCardColors(containerColor = GradeMateColors.back1),
                    shape = RoundedCornerShape(16.dp),
                    elevation = CardDefaults.cardElevation(4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            painter = courseIcon,
                            contentDescription = course.moduleCode,
                            modifier = Modifier
                                .size(50.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(GradeMateColors.Background)
                                .padding(8.dp),
                            tint = Color.Unspecified
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = moduleName,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = GradeMateColors.Primary
                                )
                            )
                            Text(
                                text = course.moduleCode,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = Color.Gray
                                )
                            )
                        }

                        Text(
                            text = course.total.toString(),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = GradeMateColors.Primary,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.padding(start = 4.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))

                        Column(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(gradeColor)
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = gradeChar,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = GradeMateColors.Background
                                )
                            )
                            Text(
                                text = gradeRemarks,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = GradeMateColors.Background
                                )
                            )
                        }
                    }
                }
            }
        } else {
            // Empty state message
            item {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            painter = painterResource("search.png"),
                            contentDescription = null,
                            tint = GradeMateColors.Primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (criteriaChosen)
                                "No results found for the selected criteria"
                            else
                                "Please select criteria to view results",
                            style = MaterialTheme.typography.bodyLarge.copy(
                                color = GradeMateColors.Primary
                            )
                        )
                    }
                }
            }
        }
    }
}


