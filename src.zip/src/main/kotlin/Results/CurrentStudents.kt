import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import components.Constants.courseList
import components.Constants.intake
import components.Constants.ntaLevels
import components.Constants.semesters
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.math.RoundingMode

@Composable
fun CurrentStudents(
    students: SnapshotStateList<Student>,
    modules: SnapshotStateList<Module>
) {
    val gpaMap = remember { mutableStateMapOf<String, Double>() }
    val grades = remember { mutableStateListOf<Grade>() }

    var selectedCourse by remember { mutableStateOf("") }
    var selectedNta by remember { mutableStateOf("") }
    var selectedSemester by remember { mutableStateOf("") }
    var selectedIntake by remember { mutableStateOf("") }

    val courseRequester = remember { FocusRequester() }
    val ntaRequester = remember { FocusRequester() }
    val semesterRequester = remember { FocusRequester() }
    val intakeRequester = remember { FocusRequester() }

    var isLoading by remember { mutableStateOf(false) }
    var selectedRegNo by remember { mutableStateOf<String?>(null) }
    var studentClicked by remember { mutableStateOf(false) }

    val scope = rememberCoroutineScope()

    // 🪟 Student Dialog
    if (studentClicked && selectedRegNo != null) {
        gpaMap[selectedRegNo]?.let { gpa ->
            ResultDialog(
                onDismiss = { studentClicked = false },
                result = students.find { it.regNo == selectedRegNo },
                currentGPA = gpa
            )
        }
    }

    // 🔹 Load data once
    LaunchedEffect(Unit) {
        if (grades.isEmpty() || modules.isEmpty() || students.isEmpty()) {
            isLoading = true
            scope.launch {
                try {
                    grades.clear()
                    grades.addAll(loadGrades())
                    modules.clear()
                    modules.addAll(fetchModulesFromFirestore())
                    students.clear()
                    students.addAll(fetchStudentsFromFirestore())

                    // Compute GPA once
                    gpaMap.clear()
                    students.forEach { student ->
                        val studentGrades = grades.filter {
                            it.ntaLevel == student.ntaLevel &&
                                    it.semester == student.semester &&
                                    it.studentId == student.regNo
                        }
                        var PN = 0.0
                        var N = 0.0
                        for (grade in studentGrades) {
                            val credit = modules.find { it.code == grade.moduleCode }?.credit?.toDoubleOrNull() ?: 0.0
                            val examMark = grade.examMark.trim().toDoubleOrNull() ?: 0.0
                            PN += credit * getPoint(student.ntaLevel.trim().toInt(), grade.total, examMark)
                            N += credit
                        }
                        gpaMap[student.regNo] =
                            if (N != 0.0) BigDecimal(PN / N).setScale(1, RoundingMode.HALF_UP).toDouble() else 0.0
                    }
                } catch (e: Exception) {
                    println("❌ Firestore error: ${e.message}")
                } finally {
                    isLoading = false
                }
            }
        }
    }

    // 🔹 Filtered students whenever dropdown changes
    val filteredStudents by remember(selectedCourse, selectedNta, selectedSemester, selectedIntake, students) {
        derivedStateOf {
            students.filter {
                it.status != "GRADUATED" &&
                        it.intake == selectedIntake &&
                        it.semester == selectedSemester &&
                        it.ntaLevel == selectedNta &&
                        it.program == selectedCourse
            }.distinctBy { it.regNo }
        }
    }

    val countTotal = filteredStudents.size
    val countPassed = filteredStudents.count { (gpaMap[it.regNo] ?: 0.0) >= 2.0 }
    val avgGPA = if (countTotal > 0) {
        BigDecimal(filteredStudents.map { gpaMap[it.regNo] ?: 0.0 }.sum() / countTotal)
            .setScale(1, RoundingMode.HALF_UP).toDouble()
    } else 0.0

    Scaffold(
        bottomBar = {
            if (countTotal > 0) {
                Surface(
                    tonalElevation = 3.dp,
                    shadowElevation = 6.dp,
                    color = MaterialTheme.colorScheme.surface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                            Text("Total: $countTotal", fontSize = 18.sp)
                            Text("✅ Passed: $countPassed", fontSize = 18.sp, color = GradeMateColors.Secondary)
                            Text("❌ Failed: ${countTotal - countPassed}", fontSize = 18.sp, color = GradeMateColors.Error)
                            Text(
                                "📊 Avg GPA: $avgGPA",
                                fontSize = 18.sp,
                                color = GradeMateColors.Primary
                            )
                        }
                        Button(
                            onClick = { /* Export logic */ },
                            colors = ButtonDefaults.buttonColors(containerColor = GradeMateColors.Primary),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)
                        ) {
                            Icon(
                                painter = painterResource("export.png"),
                                contentDescription = null,
                                modifier = Modifier.size(22.dp),
                                tint = Color.White
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Export Results", fontSize = 16.sp, color = Color.White)
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)) {

            // 🔹 Dropdowns
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.Bottom
            ) {
                SmallerNeumorphicDropDown("Course", courseList, selectedCourse,
                    { selectedCourse = courseList[it] }, courseRequester, {}, Modifier.width(200.dp), "book.png")
                Spacer(modifier = Modifier.width(4.dp))
                SmallerNeumorphicDropDown("NTA Level", ntaLevels, selectedNta,
                    { selectedNta = ntaLevels[it] }, ntaRequester, {}, Modifier.width(200.dp), "school.png")
                Spacer(modifier = Modifier.width(4.dp))
                SmallerNeumorphicDropDown("Semester", semesters, selectedSemester,
                    { selectedSemester = semesters[it] }, semesterRequester, {}, Modifier.width(200.dp), "daterange.png")
                Spacer(modifier = Modifier.width(4.dp))
                SmallerNeumorphicDropDown("Intake", intake, selectedIntake,
                    { selectedIntake = intake[it] }, intakeRequester, {}, Modifier.width(200.dp), "intake.png")
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (isLoading) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                    CircularProgressIndicator()
                }
            } else {
                if (countTotal == 0) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            painter = painterResource("search.png"),
                            tint = GradeMateColors.Primary,
                            contentDescription = null,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (selectedCourse.isNotEmpty()) "No results found for the selected criteria"
                            else "Please select criteria to view results",
                            fontSize = 16.sp
                        )
                    }
                } else {
                    // 🔹 Header Row
                    Row(
                        modifier = Modifier
                            .padding(top = 20.dp, bottom = 8.dp)
                            .fillMaxWidth()
                            .background(GradeMateColors.Primary)
                            .padding(8.dp)
                    ) {
                        ResultHeaderText("S/N", 0.1f)
                        ResultHeaderText("Registration Number", 0.15f)
                        ResultHeaderText("Full Name", 0.3f)
                        ResultHeaderText("GPA", 0.1f)
                        ResultHeaderText("Classification", 0.25f)
                        ResultHeaderText("Remarks", 0.15f)
                        ResultHeaderText("", 0.2f)
                    }

                    LazyColumn(modifier = Modifier.fillMaxHeight()) {
                        itemsIndexed(filteredStudents) { index, student ->
                            val myGPA = gpaMap[student.regNo] ?: 0.0
                            val classification = awardName(myGPA, student.ntaLevel.trim().toInt())
                            val myRemark = if (myGPA >= 2.0) "Passed" else "Failed"
                            val isSelected = student.regNo == selectedRegNo
                            Surface(
                                tonalElevation = if (index % 2 == 0) 0.dp else 2.dp,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    selectedRegNo = student.regNo
                                    studentClicked = true
                                }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 6.dp)
                                        .background(
                                            if (isSelected) GradeMateColors.Primary.copy(alpha = 0.15f)
                                            else Color.Transparent
                                        ),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    ResultDataText("${index + 1}.", 0.1f)
                                    ResultDataText(student.regNo, 0.15f)
                                    ResultDataText(student.studentName, 0.3f)
                                    ResultDataText("$myGPA", 0.1f, highlight = true)
                                    ResultDataText(classification, 0.25f, highlight = true)
                                    ResultRemarkCell(myRemark, 0.15f)

                                    Button(
                                        onClick = { /* handle click */ },
                                        modifier = Modifier
                                            .height(38.dp)
                                            .weight(0.2f),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = GradeMateColors.Primary,
                                            contentColor = Color.White
                                        ),
                                        elevation = ButtonDefaults.buttonElevation(
                                            defaultElevation = 3.dp,
                                            pressedElevation = 6.dp
                                        )
                                    ) {
                                        Image(
                                            painter = painterResource("pdf.svg"),
                                            contentDescription = "Export Sheet",
                                            modifier = Modifier.size(20 .dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Progress Report", fontSize = 14.sp)
                                    }




                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
