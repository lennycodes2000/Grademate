import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

@Composable
fun ResultDataText(text: String, weight: Float, highlight: Boolean = false) {
    val textColor = when {
        text.contains("Unassigned", ignoreCase = true) -> GradeMateColors.Error // 🔴 red
        highlight -> GradeMateColors.Primary
        else -> GradeMateColors.TextPrimary
    }

    Text(
        text = text,
        modifier = Modifier.fillMaxWidth(weight),
        fontWeight = if (highlight) FontWeight.SemiBold else FontWeight.Normal,
        color = textColor,
        fontSize = 15.sp,
        style = MaterialTheme.typography.bodyMedium
    )
}