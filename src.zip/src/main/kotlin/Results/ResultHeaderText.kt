import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Row Header
@Composable
fun ResultHeaderText(text: String, weight: Float) {
    Text(
        text = text,
        modifier = Modifier.fillMaxWidth(weight),
        fontWeight = FontWeight.SemiBold,
        color = GradeMateColors.Background,
        fontSize = 15.sp,
        style = MaterialTheme.typography.labelLarge
    )
}
