

val fakeStudents = mutableListOf(
    Student(
        1,
        "Leonard Florence Mushumbusi",
        "NS1234/0012/2025",
        "Male",
        "4",
        "2",
        "ICT",
        "September",
        status = "ACTIVE"
    ),
    Student(
        2,
        "Pendo Hassan",
        "NS1234/0022/2025",
        "Female",
        "5",
        "2",
        "ICT",
        "March",
        status = "ACTIVE"
    ),
    Student(
        1,
        "Mushumbusi Kenny",
        "NS1334/0012/2025",
        "Male",
        "4",
        "2",
        "ICT",
        "September",
        status = "ACTIVE"
    ),
    Student(
        1,
        "Newcastle United",
        "NS1534/0012/2025",
        "Female",
        "4",
        "2",
        "ICT",
        "September",
        status = "GRADUATED"
    ),
    Student(
        1,
        "Manchester United",
        "NS1534/0012/2025",
        "Female",
        "4",
        "2",
        "BA",
        "September",
        status = "ACTIVE"
    ),
)