// Your project-specific imports
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import components.Constants.academicYear
import components.Constants.intake
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
fun GradingScreen(
    students: List<Student>,
    modules: List<Module>,
    projectId: String,
    onBack: () -> Unit,
) {
    var status by remember { mutableStateOf(true) }
    var showDialog by remember { mutableStateOf(false) }
    var showGenerateDialog by remember { mutableStateOf(false) }
    var selectedModule by remember { mutableStateOf<Module?>(null) }
    val coroutineScope = rememberCoroutineScope()
    val studentGrades = remember { mutableStateMapOf<String, Grade>() }

    var savingData by remember { mutableStateOf(false) }
    var generatingSheet by remember { mutableStateOf(false) }
    var quickSheetLoading by remember { mutableStateOf(false) }
    var allowQuickSheet by remember { mutableStateOf(false) }

    val assignmentFocus = remember { FocusRequester() }
    val quizFocus = remember { FocusRequester() }
    val attendanceFocus = remember { FocusRequester() }
    val testOneFocus = remember { FocusRequester() }
    val testTwoFocus = remember { FocusRequester() }
    val examFocus = remember { FocusRequester() }
    val selectedIntakeFocus = remember { FocusRequester() }

    val initialModuleCode = "XYZ"
    var absentStudentRegNos by remember { mutableStateOf(setOf<String>()) }
    var selectedIntake by remember { mutableStateOf(intake[0]) }
    var showSaveText by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }

    // Academic year setup
    val currentYear = LocalDate.now().year
    val targetYear = "${currentYear - 1}/$currentYear"
    val targetIndex = academicYear.indexOf(targetYear).takeIf { it >= 0 } ?: 0
    var selectedAcademicYearIndex by remember { mutableStateOf(targetIndex) }
    var selectedAcademicYear by remember { mutableStateOf(academicYear[targetIndex]) }
    val selectedAcademicFocus = remember { FocusRequester() }

    if (showDialog) {
        TimedDialog(status) { showDialog = false }
    }

    // Load tutor name
    LaunchedEffect(Global.currentEmail.value) {
        if (Global.currentEmail.value.isNotEmpty()) {
            name = getTutorNameByEmail(Global.currentEmail.value).toString()
        }
    }

    // Load absences when module or academic year changes
    LaunchedEffect(selectedModule, selectedAcademicYear) {
        selectedModule?.let { module ->
            val absences = fetchAbsencesForModule(module.code, selectedAcademicYear)
            absentStudentRegNos = absences.toSet()
        } ?: run {
            absentStudentRegNos = emptySet()
        }
    }

    // Load grades for the selected module/academic year
    LaunchedEffect(selectedModule, selectedAcademicYear) {
        studentGrades.clear()
        selectedModule?.let { module ->
            try {
                val loadedGradesList = loadGradesForModule(
                    projectId = projectId,
                    moduleCode = module.code,
                    academicYear = selectedAcademicYear
                )
                val loadedGradesMap = loadedGradesList.associateBy { it.studentId }
                studentGrades.putAll(loadedGradesMap)
            } catch (_: Exception) {}
        }
    }

    val filteredStudents by derivedStateOf {
        selectedModule?.let { module ->
            val studentIdsInModule = studentGrades.keys.toSet()
            val regularStudents = students.filter { student ->
                student.ntaLevel == module.level &&
                        student.regNo in studentIdsInModule &&
                        student.semester == module.semester &&
                        student.intake == selectedIntake &&
                        !absentStudentRegNos.contains(student.regNo.trim())
            }
            val absentStudents = students.filter { student ->
                absentStudentRegNos.contains(student.regNo.trim()) &&
                        student.intake == selectedIntake
            }
            (regularStudents + absentStudents).distinctBy { it.regNo }
        } ?: emptyList()
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colors.background) {
        Column(modifier = Modifier.padding(24.dp)) {

            // Back button row
            Row(modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = onBack,
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF4A90E2)),
                    modifier = Modifier.padding(bottom = 24.dp)
                ) {
                    Text("← Back to Dashboard", color = Color.White)
                }
                Spacer(modifier = Modifier.weight(1f))
            }

            Text(
                "Grade Students",
                color = GradeMateColors.Primary,
                style = MaterialTheme.typography.h4.copy(fontWeight = FontWeight.ExtraBold),
                modifier = Modifier.padding(bottom = 16.dp)
            )

            if (students.isEmpty() || modules.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Please wait...", style = MaterialTheme.typography.body1)
                    }
                }
            } else {
                val maxCodeLength = modules.maxOfOrNull { it.code.length } ?: 0
                val maxIndexLength = modules.size.toString().length

                val sortedModules = when (Global.role.value) {
                    "Admin" -> modules
                    "HOD" -> modules.filter { it.courses.contains(Global.department.value) || it.tutor == Global.currentEmail.value }
                    "Tutor" -> modules.filter { it.tutor == Global.currentEmail.value }
                    else -> emptyList()
                }

                val options = sortedModules.mapIndexed { index, module ->
                    val paddedIndex = (index + 1).toString().padStart(maxIndexLength, ' ')
                    val paddedCode = module.code.padEnd(maxCodeLength + 3)
                    "$paddedIndex). $paddedCode${module.name}"
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    DropdownMenuWithLabelModern(
                        label = "Select Module",
                        options = options,
                        selectedOption = selectedModule?.let {
                            val paddedCode = it.code.padEnd(maxCodeLength + 3)
                            "$paddedCode${it.name}"
                        } ?: "",
                        onOptionSelected = { index -> selectedModule = sortedModules[index] },
                        modifier = Modifier.weight(2f).padding(end = 8.dp)
                    )

                    SmallerDropDownMenuWithLabel(
                        label = "Select Academic Year",
                        options = academicYear,
                        selectedOption = selectedAcademicYear,
                        onOptionSelected = { index ->
                            selectedAcademicYearIndex = index
                            selectedAcademicYear = academicYear[index]
                        },
                        nextAction = {},
                        currentAction = selectedAcademicFocus,
                        modifier = Modifier.weight(1f).padding(end = 8.dp)
                    )

                    SmallerDropDownMenuWithLabel(
                        label = "Academic intake",
                        options = intake,
                        selectedOption = selectedIntake,
                        onOptionSelected = { selectedIntake = intake[it] },
                        nextAction = {},
                        currentAction = selectedIntakeFocus,
                        modifier = Modifier.weight(1f).padding(start = 8.dp)
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            ModuleGradesStateView(
                selectedModule = selectedModule,
                filteredStudents = filteredStudents,
                students = students,
                initialModuleCode = initialModuleCode,
                onShow = {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 400.dp),
                        contentPadding = PaddingValues(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredStudents) { student ->
                            val grade = studentGrades.getOrPut(student.regNo) {
                                Grade(
                                    studentId = student.regNo,
                                    moduleCode = selectedModule!!.code,
                                    academicYear = selectedAcademicYear
                                )
                            }

                            val isAbsent = absentStudentRegNos.contains(student.regNo.trim())

                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                elevation = 8.dp,
                                shape = RoundedCornerShape(16.dp),
                                backgroundColor = if (isAbsent) Color(0xFFE0E0E0) else Color(0xFFF5F7FA)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Icon(
                                            painter = painterResource("person.png"),
                                            modifier = Modifier.size(30.dp),
                                            contentDescription = null,
                                            tint = if (isAbsent) Color.Gray else Color(0xFF4A90E2)
                                        )
                                        Text(
                                            text = student.studentName,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            style = MaterialTheme.typography.h6
                                        )
                                        Spacer(Modifier.weight(1f))
                                        Text(text = student.regNo)
                                    }

                                    if (isAbsent) {
                                        Text(
                                            "Absent",
                                            color = Color.Red,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(top = 4.dp)
                                        )
                                    }

                                    Divider(modifier = Modifier.padding(vertical = 8.dp))

                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .horizontalScroll(rememberScrollState()),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        val maxCA = 60.0
                                        val maxExam = 40.0

                                        fun totalCA(
                                            assignment: String = grade.assignmentMark,
                                            quiz: String = grade.quizMark,
                                            attendance: String = grade.attendanceMark,
                                            test1: String = grade.testOneMark,
                                            test2: String = grade.testTwoMark
                                        ): Double {
                                            return listOf(
                                                assignment.toDoubleOrNull() ?: 0.0,
                                                quiz.toDoubleOrNull() ?: 0.0,
                                                attendance.toDoubleOrNull() ?: 0.0,
                                                test1.toDoubleOrNull() ?: 0.0,
                                                test2.toDoubleOrNull() ?: 0.0
                                            ).sum()
                                        }

                                        fun canAcceptCA(
                                            newAssignment: String? = null,
                                            newQuiz: String? = null,
                                            newAttendance: String? = null,
                                            newTestOne: String? = null,
                                            newTestTwo: String? = null
                                        ): Boolean {
                                            val newCA = totalCA(
                                                assignment = newAssignment ?: grade.assignmentMark,
                                                quiz = newQuiz ?: grade.quizMark,
                                                attendance = newAttendance ?: grade.attendanceMark,
                                                test1 = newTestOne ?: grade.testOneMark,
                                                test2 = newTestTwo ?: grade.testTwoMark
                                            )
                                            return newCA <= maxCA
                                        }

                                        markInput("Assign", grade.assignmentMark, { newVal ->
                                            if (canAcceptCA(newAssignment = newVal)) {
                                                studentGrades[student.regNo] = grade.copy(assignmentMark = newVal)
                                            } else {
                                                println("⚠️ Total CA mark cannot exceed $maxCA")
                                            }
                                        }, assignmentFocus, quizFocus)

                                        markInput("Quiz", grade.quizMark, { newVal ->
                                            if (canAcceptCA(newQuiz = newVal)) {
                                                studentGrades[student.regNo] = grade.copy(quizMark = newVal)
                                            } else {
                                                println("⚠️ Total CA mark cannot exceed $maxCA")
                                            }
                                        }, quizFocus, attendanceFocus)

                                        markInput("Attend", grade.attendanceMark, { newVal ->
                                            if (canAcceptCA(newAttendance = newVal)) {
                                                studentGrades[student.regNo] = grade.copy(attendanceMark = newVal)
                                            } else {
                                                println("⚠️ Total CA mark cannot exceed $maxCA")
                                            }
                                        }, attendanceFocus, testOneFocus)

                                        markInput("Test One", grade.testOneMark, { newVal ->
                                            if (canAcceptCA(newTestOne = newVal)) {
                                                studentGrades[student.regNo] = grade.copy(testOneMark = newVal)
                                            } else {
                                                println("⚠️ Total CA mark cannot exceed $maxCA")
                                            }
                                        }, testOneFocus, testTwoFocus)

                                        markInput("Test Two", grade.testTwoMark, { newVal ->
                                            if (canAcceptCA(newTestTwo = newVal)) {
                                                studentGrades[student.regNo] = grade.copy(testTwoMark = newVal)
                                            } else {
                                                println("⚠️ Total CA mark cannot exceed $maxCA")
                                            }
                                        }, testTwoFocus, examFocus)

                                        OutlinedTextField(
                                            value = String.format("%.1f", grade.caMark),
                                            onValueChange = {},
                                            readOnly = true,
                                            label = { Text("CA Mark") },
                                            modifier = Modifier.width(100.dp),
                                            singleLine = true
                                        )

                                        if (grade.caMark >= 30.0) {
                                            markInput("Exam", grade.examMark, { newVal ->
                                                val examVal = newVal.toDoubleOrNull() ?: 0.0
                                                if (examVal <= maxExam) {
                                                    studentGrades[student.regNo] = grade.copy(examMark = newVal)
                                                } else {
                                                    println("⚠️ Exam mark cannot exceed $maxExam")
                                                }
                                            }, examFocus, null, maxAllowed = maxExam)
                                        }

                                        OutlinedTextField(
                                            value = String.format("%.1f", grade.total),
                                            onValueChange = {},
                                            readOnly = true,
                                            label = { Text("Total Mark") },
                                            modifier = Modifier.width(100.dp),
                                            singleLine = true
                                        )

                                        val examValue = grade.examMark.trim().replace(",", ".").toDoubleOrNull() ?: 0.0

                                        val shownGrade = when {
                                            grade.caMark < 30 -> "Repeat"
                                            examValue < 20 -> "Technical Supplementary (TS)"
                                            selectedModule?.level?.toIntOrNull() != 6 -> when {
                                                grade.total >= 80 -> "A"
                                                grade.total >= 65 -> "B"
                                                grade.total >= 50 -> "C"
                                                grade.total >= 40 -> "D"
                                                else -> "F"
                                            }
                                            else -> when {
                                                grade.total >= 75 -> "A"
                                                grade.total >= 65 -> "B+"
                                                grade.total >= 55 -> "B"
                                                grade.total >= 45 -> "C"
                                                grade.total >= 35 -> "D"
                                                else -> "F"
                                            }
                                        }

                                        grade.academicYear = selectedAcademicYear

                                        Text(
                                            text = shownGrade,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            style = MaterialTheme.typography.h6
                                        )
                                    }

                                }
                            }
                        }
                    }
                }
            )

            Spacer(Modifier.height(24.dp))

            // Buttons row
            GradingActionButtons(
                showSave = savingData || generatingSheet || quickSheetLoading ,
                onSaveClick = {
                    coroutineScope.launch {
                        savingData = true
                        saveAllGrades(studentGrades, filteredStudents, selectedModule, selectedAcademicYear, projectId)
                        savingData = false
                    }
                },
                onGenerateClick = {
                    coroutineScope.launch {
                        generatingSheet = true
                        saveAllGrades(studentGrades, filteredStudents, selectedModule, selectedAcademicYear, projectId)
                        showGenerateDialog = true
                        generatingSheet = false
                    }
                },
                onQuickClick = {
                    coroutineScope.launch {
                        quickSheetLoading = true
                        saveAllGrades(studentGrades, filteredStudents, selectedModule, selectedAcademicYear, projectId)
                        allowQuickSheet = true
                        quickSheetLoading = false
                    }
                }
            )
        }
    }

    if (showGenerateDialog) {
        GenerateSheetDialog(
            onDismiss = { showGenerateDialog = false },
            onGenerate = { instructor, hod, examOfficer ->
                selectedModule?.let { module ->
                    coroutineScope.launch {
                        val gradesList = loadGradesForModule(projectId, module.code, selectedAcademicYear)
                        generatePdfReport(module, filteredStudents, gradesList, instructor, hod, examOfficer, selectedAcademicYear, selectedIntake, name)
                    }
                }
                showGenerateDialog = false
            }
        )
    }

    if (allowQuickSheet) {
        selectedModule?.let { module ->
            coroutineScope.launch {
                val gradesList = loadGradesForModule(projectId, module.code, selectedAcademicYear)
                generateQuickReport(module, filteredStudents, gradesList, selectedAcademicYear, selectedIntake, name)
            }
        }
        allowQuickSheet = false
    }
}

@Composable
fun GradingActionButtons(
    showSave: Boolean,
    onSaveClick: suspend () -> Unit,
    onGenerateClick: suspend () -> Unit,
    onQuickClick: suspend () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()

    if (!showSave) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally)
        ) {
            val sideButtonModifier = Modifier.weight(1f).height(56.dp)
            val middleButtonModifier = Modifier.weight(2f).height(56.dp)

            // Save Button
            Button(
                onClick = { coroutineScope.launch { onSaveClick() } },
                modifier = sideButtonModifier,
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(
                    backgroundColor = Color(0xFF4A90E2),
                    contentColor = Color.White
                )
            ) {
                Text("Save Data", style = MaterialTheme.typography.button.copy(fontWeight = FontWeight.Bold))
            }

            // Generate Sheet Button
            Button(
                onClick = { coroutineScope.launch { onGenerateClick() } },
                modifier = middleButtonModifier,
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(
                    backgroundColor = Color(0xFF4A90E2),
                    contentColor = Color.White
                )
            ) {
                Image(
                    painter = painterResource("pdf.svg"),
                    contentDescription = "Export Sheet",
                    modifier = Modifier.size(30.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text("Generate Sheet", style = MaterialTheme.typography.button.copy(fontWeight = FontWeight.Bold))
            }

            // Quick Sheet Button
            Button(
                onClick = { coroutineScope.launch { onQuickClick() } },
                modifier = sideButtonModifier,
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(
                    backgroundColor = Color(0xFF4A90E2),
                    contentColor = Color.White
                )
            ) {
                Text("Quick Sheet", style = MaterialTheme.typography.button.copy(fontWeight = FontWeight.Bold))
            }
        }
    } else {
        // Show a single loading indicator when saving/generating
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = GradeMateColors.Primary, strokeWidth = 2.dp)
        }
    }
}


// You can reuse your original saveAllGrades function here, just pass required params
suspend fun saveAllGrades(
    studentGrades: MutableMap<String, Grade>,
    filteredStudents: List<Student>,
    selectedModule: Module?,
    selectedAcademicYear: String,
    projectId: String
) {
    var successCount = 0
    var totalToSave = 0
    selectedModule?.let { module ->
        filteredStudents.forEach { student ->
            studentGrades.putIfAbsent(
                student.regNo,
                Grade(studentId = student.regNo, moduleCode = module.code, academicYear = selectedAcademicYear)
            )
        }
        val studentsInIntake = filteredStudents.map { it.regNo }.toSet()
        val gradesToSave = studentGrades.values.filter { grade ->
            grade.moduleCode == module.code &&
                    grade.academicYear == selectedAcademicYear &&
                    studentsInIntake.contains(grade.studentId)
        }
        totalToSave = gradesToSave.size
        gradesToSave.forEach { grade ->
            try { if (saveGradeToFirestore(projectId, grade)) successCount++ } catch (_: Exception) {}
        }
    }
}
