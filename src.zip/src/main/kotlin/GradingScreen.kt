import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import components.Constants.academicYear
import components.Constants.intake
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
fun GradingScreen(
    students: List<Student>,
    modules: List<Module>,
    projectId: String,
    onBack: () -> Unit,

) {

    var status by remember { mutableStateOf(true) }
    var showDialog by remember { mutableStateOf(false) }
    if (showDialog) {
        TimedDialog(status) {
            showDialog = false
        }
    }
    var showGenerateDialog by remember { mutableStateOf(false) }
    var selectedModule by remember { mutableStateOf<Module?>(null) }
    val coroutineScope = rememberCoroutineScope()
    val studentGrades = remember { mutableStateMapOf<String, Grade>() }
 var showSave by remember { mutableStateOf(false) }
 var middleClicked by remember { mutableStateOf(false) }
 var quickClicked by remember { mutableStateOf(false) }
 var generateQuickClicked by remember { mutableStateOf(false) }
 var allowQuickSheet by remember { mutableStateOf(false) }
    val assignmentFocus = remember { FocusRequester() }
    val quizFocus = remember { FocusRequester() }
    val attendanceFocus = remember { FocusRequester() }
    val testOneFocus = remember { FocusRequester() }
    val testTwoFocus = remember { FocusRequester() }
    val examFocus = remember { FocusRequester() }
    val selectedIntakeFocus = remember { FocusRequester() }
    val initialModuleCode = "XYZ"
    var absentStudentRegNos by remember { mutableStateOf(setOf<String>()) }
    var selectedIntake by remember {
        mutableStateOf(intake[0])
    }
    var showSaveText by remember {
        mutableStateOf("")
    }
    var name by remember { mutableStateOf("") }

    //Dealing with the academic year
    val currentYear = LocalDate.now().year
    val targetYear = "${currentYear - 1}/$currentYear"

// Find its index in the list (fallback = 0 if not found)
    val targetIndex = academicYear.indexOf(targetYear).takeIf { it >= 0 } ?: 0
//get name by email
    LaunchedEffect(Global.currentEmail.value){
        //setting the name
        if(Global.currentEmail.value.isNotEmpty()){
            name = getTutorNameByEmail(Global.currentEmail.value).toString()
        }

    }
// State for dropdown
    var selectedAcademicYearIndex by remember { mutableStateOf(targetIndex) }
    var selectedAcademicYear by remember { mutableStateOf(academicYear[targetIndex]) }
    val selectedAcademicFocus = remember { FocusRequester() }
    LaunchedEffect(selectedModule,selectedAcademicYear) {
        selectedModule?.let { module ->
            val absences = fetchAbsencesForModule(module.code,selectedAcademicYear) // returns List<String>
            absentStudentRegNos = absences.toSet()
        } ?: run {
            absentStudentRegNos = emptySet()
        }
    }
    LaunchedEffect(selectedModule, selectedAcademicYear,selectedIntake) {
        if (selectedModule != null) {
            try {
                val loadedGradesList = loadGradesForModule(
                    projectId = projectId,
                    moduleCode = selectedModule!!.code,
                    academicYear = selectedAcademicYear
                )
                val loadedGradesMap = loadedGradesList.associateBy { it.studentId }

                studentGrades.clear() // 👈 clear old data before inserting
                studentGrades.putAll(loadedGradesMap)

                println("✅ Loaded grades for ${selectedModule!!.code} - $selectedAcademicYear")
            } catch (e: Exception) {
                println("❌ Failed to load grades: ${e.message}")
            }
        } else {
            studentGrades.clear()
        }
    }
var shownGrade by remember {
    mutableStateOf("")
}


    val filteredStudents = remember(selectedModule, students, absentStudentRegNos,selectedIntake) {
        selectedModule?.let { module ->
            // Students matching the normal filters
            val regularStudents = students.filter {
                it.ntaLevel == module.level &&
                        module.courses.contains(it.program) &&
                        it.semester == module.semester && it.intake == selectedIntake
            }

            // Students absent for this module (based on regNo)
            val absentStudents = students.filter { student ->
                absentStudentRegNos.any { it.trim() == student.regNo.trim() } &&
                        student.intake == selectedIntake
            }
            // Combine both sets (avoid duplicates)
            (regularStudents + absentStudents).distinctBy { it.regNo }
        } ?: emptyList()
    }
    var studentGrade by remember { mutableStateOf<Map<String, List<Grade>>>(emptyMap()) }

    LaunchedEffect(generateQuickClicked) {
        if (generateQuickClicked) {
            val gradesList = loadGradesForModule(Database.projectId, initialModuleCode,selectedAcademicYear)
            studentGrade = gradesList.groupBy { it.studentId }
            generateQuickClicked = false // reset
        }
    }


    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colors.background) {
        Column(modifier = Modifier.padding(24.dp)) {

            Row (
                modifier = Modifier.fillMaxWidth()
            ){
                if(!showSave){
                    Button(
                        onClick = onBack,
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF4A90E2)),
                        modifier = Modifier.padding(bottom = 24.dp)
                    ) {
                        Text("← Back to Dashboard", color = Color.White)
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

            }

            Text(
                "Grade Students",
                style = MaterialTheme.typography.h4.copy(fontWeight = FontWeight.ExtraBold),
                modifier = Modifier.padding(bottom = 16.dp)
            )
            if (students.isEmpty() || modules.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Please wait...", style = MaterialTheme.typography.body1)
                    }
                }
            }
            else {

                val maxCodeLength = modules.maxOfOrNull { it.code.length } ?: 0
                val maxIndexLength = modules.size.toString().length // e.g. 2 digits if you have 10+ modules
                val sortedModules = when (Global.role.value) {
                    "Admin" -> modules // Admin sees all

                    "HOD" -> {
                        val department = Global.department.value // logged-in HOD’s department
                        val tutorId = Global.currentEmail.value // HOD might also be a tutor

                        modules.filter { module ->
                            module.courses.contains(department) || module.tutor == tutorId
                        }
                    }

                    "Tutor" -> {
                        val tutorId = Global.currentEmail.value
                        modules.filter { it.tutor == tutorId }
                    }

                    else -> emptyList() // no access
                }


                val options = sortedModules.mapIndexed { index, module ->
                    val paddedIndex = (index + 1).toString().padStart(maxIndexLength, ' ')
                    val paddedCode = module.code.padEnd(maxCodeLength + 3) // +3 spaces for alignment
                    "$paddedIndex). $paddedCode${module.name}"
                }



                if(!showSave){
                          Row(
                              modifier = Modifier
                                  .fillMaxWidth()
                                  .padding(horizontal = 16.dp),
                              horizontalArrangement = Arrangement.SpaceBetween,
                              verticalAlignment = Alignment.CenterVertically
                          ) {
                              // First dropdown (module)
                              DropdownMenuWithLabelModern(
                                  label = "Select Module",
                                  options = options,
                                  selectedOption = selectedModule?.let {
                                      val paddedCode = it.code.padEnd(maxCodeLength + 3)
                                      "$paddedCode${it.name}"
                                  } ?: "",
                                  onOptionSelected = { index -> selectedModule = modules[index] },
                                  modifier = Modifier
                                      .weight(2f) // take some space
                                      .padding(end = 8.dp)
                              )

                              // Second dropdown (academic year)
                              SmallerDropDownMenuWithLabel(
                                  label = "Select Academic Year",
                                  options = academicYear,
                                  selectedOption = selectedAcademicYear,
                                  onOptionSelected = { index ->
                                      selectedAcademicYearIndex = index
                                      selectedAcademicYear = academicYear[index]
                                  },
                                  nextAction = {},
                                  currentAction = selectedAcademicFocus,
                                  modifier = Modifier
                                      .weight(1f) // take equal space
                                      .padding(end = 8.dp)
                              )
                              Spacer(modifier = Modifier.width(8.dp)) // 👈 extra space
                              //Third Drop down
                              SmallerDropDownMenuWithLabel(
                                  label = "Academic intake",
                                  options = intake,
                                  selectedOption = selectedIntake,
                                  onOptionSelected = {
                                      selectedIntake = intake[it]
                                  },
                                  nextAction = {},
                                  currentAction = selectedIntakeFocus,
                                  modifier = Modifier
                                      .weight(1f) // take equal space
                                      .padding(start = 8.dp)
                              )
                          }


                      }


            }


            Spacer(Modifier.height(16.dp))

            if (filteredStudents.isEmpty() && students.isNotEmpty() && selectedModule?.code != initialModuleCode) {
                Text("No matching records found.", color = Color.Red)
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(8.dp)
                ) {
                    items(filteredStudents) { student ->
                        val grade = studentGrades.getOrPut(student.regNo) {
                            Grade(studentId = student.regNo, moduleCode = selectedModule!!.code)
                        }
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            elevation = 8.dp,
                            shape = RoundedCornerShape(16.dp),
                            backgroundColor = Color(0xFFF5F7FA)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                // Student info row
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(painter = painterResource("person.png"),
                                        modifier = Modifier.size(30.dp),
                                        contentDescription = null, tint = Color(0xFF4A90E2))
                                    Text(
                                        text = student.studentName,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        style = MaterialTheme.typography.h6
                                    )
                                    Spacer(Modifier.weight(1f))
                                    Text(text = student.regNo)
                                }

                                Divider(modifier = Modifier.padding(vertical = 8.dp))

                                // Grade inputs row
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    markInput("Assignment", grade.assignmentMark, {
                                        studentGrades[student.regNo] = grade.copy(assignmentMark = it)
                                    }, assignmentFocus, quizFocus)

                                    markInput("Quiz", grade.quizMark, {
                                        studentGrades[student.regNo] = grade.copy(quizMark = it)
                                    }, quizFocus, attendanceFocus)

                                    markInput("Attendance", grade.attendanceMark, {
                                        studentGrades[student.regNo] = grade.copy(attendanceMark = it)
                                    }, attendanceFocus, testOneFocus)

                                    markInput("Test One", grade.testOneMark, {
                                        studentGrades[student.regNo] = grade.copy(testOneMark = it)
                                    }, testOneFocus, testTwoFocus)

                                    markInput("Test Two", grade.testTwoMark, {
                                        studentGrades[student.regNo] = grade.copy(testTwoMark = it)
                                    }, testTwoFocus, examFocus)

                                    OutlinedTextField(
                                        value = String.format("%.1f", grade.caMark),
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("CA Mark") },
                                        modifier = Modifier.width(100.dp),
                                        singleLine = true
                                    )

                                    if (grade.caMark >= 30.0) {
                                        markInput("Exam", grade.examMark, {
                                            studentGrades[student.regNo] = grade.copy(examMark = it)
                                        }, examFocus, null, maxAllowed = 40)
                                    }

                                    OutlinedTextField(
                                        value = String.format("%.1f", grade.total),
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("Total Mark") },
                                        modifier = Modifier.width(100.dp),
                                        singleLine = true
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    shownGrade = if (grade.caMark < 30 && grade.caMark.toString().isNotEmpty()) {
                                        "Repeat"
                                    } else if ((grade.examMark.toDoubleOrNull() ?: 0.0) < 20 ) {
                                        "Technical Supplementary (TS)"
                                    } else {
                                        if (selectedModule?.level?.trim()?.toIntOrNull() != 6) {
                                            when {
                                                grade.total >= 80 -> "A"
                                                grade.total >= 65 -> "B"
                                                grade.total >= 50 -> "C"
                                                grade.total >= 40 -> "D"
                                                else -> "F"
                                            }
                                        } else {
                                            when {
                                                grade.total >= 75 -> "A"
                                                grade.total >= 65 -> "B+"
                                                grade.total >= 55 -> "B"
                                                grade.total >= 45 -> "C"
                                                grade.total >= 35 -> "D"
                                                else -> "F"
                                            }
                                        }
                                    }

                                    //setting the grade academic year
                                    grade.academicYear = selectedAcademicYear
                                    Text(
                                        text =shownGrade,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        style = MaterialTheme.typography.h6
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            // Suspend function to reuse Firestore saving logic
            suspend fun saveAllGrades(): Int {
                var successCount = 0
                studentGrades.values.forEach { grade ->
                    val success = saveGradeToFirestore(projectId, grade)
                    if (success) successCount++
                }
                if(successCount == studentGrades.size){
                    showDialog = true
                    if(middleClicked){
                       showGenerateDialog = true
                    }
                    if(quickClicked){
                        allowQuickSheet = true
                    }
                }
                else{
                    status = false
                    showDialog = true
                }
                quickClicked = false
                middleClicked = false
                return successCount
            }

// UI Section
            if (!showSave && filteredStudents.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally)
                ) {
                    val sideButtonModifier = Modifier
                        .weight(1f)
                        .height(56.dp)

                    val middleButtonModifier = Modifier
                        .weight(2f) // 👈 makes it bigger than the side buttons
                        .height(56.dp)

                    // Save Data Button (Left)
                    Button(
                        onClick = {
                            showSave = true
                            coroutineScope.launch {
                                val successCount = saveAllGrades()
                                println("✅ Saved $successCount / ${studentGrades.size} grades")
                                showSaveText = "✅ Saved $successCount / ${studentGrades.size} grades"
                                showSave = false
                                val gradesList = loadGradesForModule(
                                    Database.projectId, initialModuleCode, selectedAcademicYear
                                )
                                studentGrade = gradesList.groupBy { it.studentId }
                            }
                        },
                        modifier = sideButtonModifier,
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(
                            backgroundColor = Color(0xFF4A90E2),
                            contentColor = Color.White
                        ),
                        elevation = ButtonDefaults.elevation(6.dp, 10.dp)
                    ) {
                        Text(
                            "Save Data",
                            style = MaterialTheme.typography.button.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        )
                    }

                    // Generate Sheet Button (Middle, Bigger)
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                middleClicked = true
                                showSave = true
                                val successCount = saveAllGrades()
                                println("✅ Saved $successCount / ${studentGrades.size} grades")
                                showSave = false
                            }
                        },
                        modifier = middleButtonModifier,
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(
                            backgroundColor = Color(0xFF4A90E2),
                            contentColor = Color.White
                        ),
                        elevation = ButtonDefaults.elevation(6.dp, 10.dp)
                    ) {
                        Image(
                            painter = painterResource("pdf.svg"),
                            contentDescription = "Export Sheet",
                            modifier = Modifier.size(30.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "Generate Sheet",
                            style = MaterialTheme.typography.button.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.75.sp // slightly more spacing for emphasis
                            )
                        )
                    }

                    // Quick Sheet Button (Right)
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                showSave = true
                                quickClicked= true
                                val successCount = saveAllGrades()
                                println("✅ Saved $successCount / ${studentGrades.size} grades")
                                showSave = false

                            }
                        },
                        modifier = sideButtonModifier,
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(
                            backgroundColor = Color(0xFF4A90E2),
                            contentColor = Color.White
                        ),
                        elevation = ButtonDefaults.elevation(6.dp, 10.dp)
                    ) {
                        Text(
                            "Quick Sheet",
                            style = MaterialTheme.typography.button.copy(
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        )
                    }
                }




            } else {
                // Show loading spinner while saving
                Column (
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }


        }
    }
    //defining the Export Sheet
    if (showGenerateDialog) {
        GenerateSheetDialog(
            onDismiss = { showGenerateDialog = false },
            onGenerate = { instructor, hod, examOfficer ->
                selectedModule?.let { module ->
                    coroutineScope.launch {
                        val gradesList = loadGradesForModule(projectId, module.code,selectedAcademicYear)
                        generatePdfReport(module, filteredStudents, gradesList, instructor, hod, examOfficer,selectedAcademicYear,selectedIntake,name)
                    }
                }
                showGenerateDialog = false
            }
        )
    }
    //defining the quick sheet
    if(allowQuickSheet){
        selectedModule?.let { module ->
            coroutineScope.launch {
                val gradesList = loadGradesForModule(projectId, module.code,selectedAcademicYear)
                generateQuickReport(module, filteredStudents, gradesList,selectedAcademicYear,selectedIntake,name)
            }
        }
        showSave = false
        allowQuickSheet = false
    }
}

@Composable
fun markInput(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    currentFocus: FocusRequester,
    nextFocus: FocusRequester?,
    maxAllowed: Int = 60 // 👈 configurable max (default 100)
) {
    OutlinedTextField(
        value = value,
        onValueChange = { newValue ->
            // Only allow digits
            val filtered = newValue.filter { it.isDigit() }

            // Convert to int safely
            val intVal = filtered.toIntOrNull()

            // Apply restriction
            if (intVal != null && intVal in 0..maxAllowed) {
                onValueChange(filtered)
            } else if (filtered.isEmpty()) {
                // Allow clearing input
                onValueChange("")
            }
        },
        label = {
            Text(
                text = label,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth()
            )
        },
        modifier = Modifier
            .width(100.dp)
            .focusRequester(currentFocus)
            .onPreviewKeyEvent { keyEvent ->
                // optional: tab to next field
                false
            },
        singleLine = true,
        colors = TextFieldDefaults.outlinedTextFieldColors(
            focusedBorderColor = Color(0xFF4A90E2),
            focusedLabelColor = Color(0xFF4A90E2),
            cursorColor = Color(0xFF4A90E2)
        )
    )
}













