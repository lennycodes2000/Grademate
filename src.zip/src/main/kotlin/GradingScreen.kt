import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.apache.pdfbox.pdmodel.PDDocument
import org.apache.pdfbox.pdmodel.PDPage
import org.apache.pdfbox.pdmodel.PDPageContentStream
import org.apache.pdfbox.pdmodel.common.PDRectangle
import org.apache.pdfbox.pdmodel.font.PDFont
import org.apache.pdfbox.pdmodel.font.PDType1Font
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject
import java.awt.Desktop
import java.io.File
import java.util.*

@Composable
fun GradingScreen(
    students: List<Student>,
    modules: List<Module>,
    projectId: String,
    onBack: () -> Unit
) {
    var showGenerateDialog by remember { mutableStateOf(false) }
    var selectedModule by remember { mutableStateOf<Module?>(null) }
    val coroutineScope = rememberCoroutineScope()
    val studentGrades = remember { mutableStateMapOf<String, Grade>() }
 var showSave by remember { mutableStateOf(false) }
 var generateQuickClicked by remember { mutableStateOf(false) }
    val assignmentFocus = remember { FocusRequester() }
    val quizFocus = remember { FocusRequester() }
    val attendanceFocus = remember { FocusRequester() }
    val testOneFocus = remember { FocusRequester() }
    val testTwoFocus = remember { FocusRequester() }
    val examFocus = remember { FocusRequester() }
    val initialModuleCode = "XYZ"
    var absentStudentRegNos by remember { mutableStateOf(setOf<String>()) }

    LaunchedEffect(selectedModule) {
        selectedModule?.let { module ->
            val absences = fetchAbsencesForModule(module.code) // returns List<String>
            absentStudentRegNos = absences.toSet()
        } ?: run {
            absentStudentRegNos = emptySet()
        }
    }
var shownGrade by remember {
    mutableStateOf("")
}
    val filteredStudents = remember(selectedModule, students, absentStudentRegNos) {
        selectedModule?.let { module ->
            // Students matching the normal filters
            val regularStudents = students.filter {
                it.ntaLevel == module.level &&
                        module.courses.contains(it.program) &&
                        it.semester == module.semester
            }

            // Students absent for this module (based on regNo)
            val absentStudents = students.filter { absentStudentRegNos.contains(it.regNo) }

            // Combine both sets (avoid duplicates)
            (regularStudents + absentStudents).distinctBy { it.regNo }
        } ?: emptyList()
    }
    var studentGrade by remember { mutableStateOf<Map<String, List<Grade>>>(emptyMap()) }

    LaunchedEffect(generateQuickClicked) {
        if (generateQuickClicked) {
            val gradesList = loadGradesForModule(Database.projectId, initialModuleCode)
            studentGrade = gradesList.groupBy { it.studentId }
            generateQuickClicked = false // reset
        }
    }
    LaunchedEffect(selectedModule) {
        if (selectedModule != null) {
            try {
                val loadedGradesList: List<Grade> = loadGradesForModule(projectId, selectedModule!!.code)
                val loadedGradesMap = loadedGradesList.associateBy { it.studentId } // Map<String, Grade>
                studentGrades.putAll(loadedGradesMap)
                println(studentGrades.toMap())

                           } catch (e: Exception) {
                println("Failed to load grades: ${e.message}")
            }
        } else {
            studentGrades.clear()
        }
    }
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colors.background) {
        Column(modifier = Modifier.padding(24.dp)) {

            Row (
                modifier = Modifier.fillMaxWidth()
            ){
                Button(
                    onClick = onBack,
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF4A90E2)),
                    modifier = Modifier.padding(bottom = 24.dp)
                ) {
                    Text("← Back to Dashboard", color = Color.White)
                }
                Spacer(modifier = Modifier.weight(1f))

            }

            Text(
                "Grade Students",
                style = MaterialTheme.typography.h4.copy(fontWeight = FontWeight.ExtraBold),
                modifier = Modifier.padding(bottom = 16.dp)
            )
            if (students.isEmpty() || modules.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Please wait...", style = MaterialTheme.typography.body1)
                    }
                }
            }
            else {
                val maxCodeLength = modules.maxOfOrNull { it.code.length } ?: 0

                val options = modules.map { module ->
                    val paddedCode = module.code.padEnd(maxCodeLength + 3) // +3 spaces for alignment
                    "$paddedCode${module.name}"
                }

                DropdownMenuWithLabelModern(
                    label = "Select Module",
                    options = options,
                    selectedOption = selectedModule?.let {
                        val paddedCode = it.code.padEnd(maxCodeLength + 3)
                        "$paddedCode${it.name}"
                    } ?: "",
                    onOptionSelected = { index -> selectedModule = modules[index] },
                    modifier = Modifier.fillMaxWidth()
                )

            }


            Spacer(Modifier.height(16.dp))

            if (filteredStudents.isEmpty() && students.isNotEmpty() && selectedModule?.code != initialModuleCode) {
                Text("No students found for this module or no module is selected.", color = Color.Red)
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(8.dp)
                ) {
                    items(filteredStudents) { student ->
                        val grade = studentGrades.getOrPut(student.regNo) {
                            Grade(studentId = student.regNo, moduleCode = selectedModule!!.code)
                        }
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            elevation = 8.dp,
                            shape = RoundedCornerShape(16.dp),
                            backgroundColor = Color(0xFFF5F7FA)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                // Student info row
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(painter = painterResource("person.png"),
                                        modifier = Modifier.size(30.dp),
                                        contentDescription = null, tint = Color(0xFF4A90E2))
                                    Text(
                                        text = student.studentName,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        style = MaterialTheme.typography.h6
                                    )
                                    Spacer(Modifier.weight(1f))
                                    Text(text = student.regNo)
                                }

                                Divider(modifier = Modifier.padding(vertical = 8.dp))

                                // Grade inputs row
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    markInput("Assignment", grade.assignmentMark, {
                                        studentGrades[student.regNo] = grade.copy(assignmentMark = it)
                                    }, assignmentFocus, quizFocus)

                                    markInput("Quiz", grade.quizMark, {
                                        studentGrades[student.regNo] = grade.copy(quizMark = it)
                                    }, quizFocus, attendanceFocus)

                                    markInput("Attendance", grade.attendanceMark, {
                                        studentGrades[student.regNo] = grade.copy(attendanceMark = it)
                                    }, attendanceFocus, testOneFocus)

                                    markInput("Test One", grade.testOneMark, {
                                        studentGrades[student.regNo] = grade.copy(testOneMark = it)
                                    }, testOneFocus, testTwoFocus)

                                    markInput("Test Two", grade.testTwoMark, {
                                        studentGrades[student.regNo] = grade.copy(testTwoMark = it)
                                    }, testTwoFocus, examFocus)

                                    OutlinedTextField(
                                        value = String.format("%.1f", grade.caMark),
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("CA Mark") },
                                        modifier = Modifier.width(100.dp),
                                        singleLine = true
                                    )

                                    if (grade.caMark >= 30.0) {
                                        markInput("Exam", grade.examMark, {
                                            studentGrades[student.regNo] = grade.copy(examMark = it)
                                        }, examFocus, null)
                                    }

                                    OutlinedTextField(
                                        value = String.format("%.1f", grade.total),
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("Total Mark") },
                                        modifier = Modifier.width(100.dp),
                                        singleLine = true
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    shownGrade = if (grade.caMark < 30 && grade.caMark.toString().isNotEmpty()) {
                                        "Repeat"
                                    } else if ((grade.examMark.toDoubleOrNull() ?: 0.0) < 20 ) {
                                        "Technical Supplementary (TS)"
                                    } else {
                                        if (selectedModule?.level?.trim()?.toIntOrNull() != 6) {
                                            when {
                                                grade.total >= 80 -> "A"
                                                grade.total >= 65 -> "B"
                                                grade.total >= 50 -> "C"
                                                grade.total >= 40 -> "D"
                                                else -> "F"
                                            }
                                        } else {
                                            when {
                                                grade.total >= 75 -> "A"
                                                grade.total >= 65 -> "B+"
                                                grade.total >= 55 -> "B"
                                                grade.total >= 45 -> "C"
                                                grade.total >= 35 -> "D"
                                                else -> "F"
                                            }
                                        }
                                    }




                                    Text(
                                        text =shownGrade,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        style = MaterialTheme.typography.h6
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            // Suspend function to reuse Firestore saving logic
            suspend fun saveAllGrades(): Int {
                var successCount = 0
                studentGrades.values.forEach { grade ->
                    val success = saveGradeToFirestore(projectId, grade)
                    if (success) successCount++
                }
                return successCount
            }

// UI Section
            if (!showSave) {
                // Save Data Button
                Button(
                    onClick = {
                        showSave = true // Immediately hide buttons and show progress
                        coroutineScope.launch {
                            val successCount = saveAllGrades()
                            println("✅ Saved $successCount / ${studentGrades.size} grades")
                            showSave = false
                            // Optional: Show Snackbar or dialog
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(
                        backgroundColor = Color(0xFF4A90E2),
                        contentColor = Color.White
                    )
                ) {
                    Text("Save Data", style = MaterialTheme.typography.button.copy(fontWeight = FontWeight.Bold))
                }

                Spacer(Modifier.height(8.dp))

                // Generate Sheet Button
                Button(
                    onClick = {
                        showSave = true // Immediately hide buttons and show progress
                        coroutineScope.launch {
                            val successCount = saveAllGrades()
                            println("✅ Saved $successCount / ${studentGrades.size} grades")
                            showGenerateDialog = true
                            showSave = false
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(24.dp),
                    colors = ButtonDefaults.buttonColors(
                        backgroundColor = Color(0xFF4A90E2),
                        contentColor = Color.White
                    ),
                    elevation = ButtonDefaults.elevation(10.dp)
                ) {
                    Image(
                        painter = painterResource("document_icon.svg"),
                        contentDescription = "Generate Sheet",
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text("Generate Sheet", style = MaterialTheme.typography.button.copy(fontWeight = FontWeight.Bold))
                }

            } else {
                // Show loading spinner while saving
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator()
                }
            }


        }
    }
    if (showGenerateDialog) {
        GenerateSheetDialog(
            onDismiss = { showGenerateDialog = false },
            onGenerate = { instructor, hod, examOfficer ->
                selectedModule?.let { module ->
                    coroutineScope.launch {
                        val gradesList = loadGradesForModule(projectId, module.code)
                        generatePdfReport(module, filteredStudents, gradesList, instructor, hod, examOfficer)
                    }
                }
                showGenerateDialog = false
            }
        )
    }
}

@Composable
fun markInput(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    currentFocus: FocusRequester,
    nextFocus: FocusRequester?
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = {
            Text(
                text = label,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth() // ensures it wraps inside field width
            )
        },
        modifier = Modifier
            .width(100.dp)
            .focusRequester(currentFocus)
            .onPreviewKeyEvent { keyEvent ->
                // Optional: tab to next field logic here
                false
            },
        singleLine = true,
        colors = TextFieldDefaults.outlinedTextFieldColors(
            focusedBorderColor = Color(0xFF4A90E2),
            focusedLabelColor = Color(0xFF4A90E2),
            cursorColor = Color(0xFF4A90E2)
        )
    )
}






@Composable
fun DropdownMenuWithLabelModern(
    label: String,
    options: List<String>,
    selectedOption: String,
    onOptionSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }
    var currentLabel by remember { mutableStateOf(selectedOption) }
    val rotation by animateFloatAsState(
        targetValue = if (expanded) 180f else 0f,
        animationSpec = tween(durationMillis = 300, easing = FastOutSlowInEasing)
    )

    Box(modifier = modifier) {
        OutlinedTextField(
            value = currentLabel,
            onValueChange = {},
            readOnly = true,
            label = { Text(label, fontWeight = FontWeight.Medium) },
            trailingIcon = {
                Icon(
                    tint = GradeMateColors.Primary,
                    painter = painterResource("down.png"),
                    contentDescription = "Dropdown Arrow",
                    modifier = Modifier.size(25.dp).rotate(rotation)
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedBorderColor = Color(0xFF4A90E2),
                unfocusedBorderColor = Color(0xFFB0BEC5),
                focusedLabelColor = Color(0xFF4A90E2),
                cursorColor = Color(0xFF4A90E2)
            )
        )
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false },
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
        ) {
            options.forEachIndexed { index, text ->
                DropdownMenuItem(onClick = {
                    currentLabel = text
                    expanded = false
                    onOptionSelected(index)
                }) {
                    Text(text)
                }
            }
        }
        Spacer(
            modifier = Modifier
                .matchParentSize()
                .clickable { expanded = true }
        )
    }
}

@Composable
fun GenerateSheetDialog(
    onDismiss: () -> Unit,
    onGenerate: (instructorName: String, hodName: String, examOfficerName: String) -> Unit
) {
    var instructorName by remember { mutableStateOf("") }
    val instructorNameRequest = remember {
        FocusRequester()
    }
    var hodName by remember { mutableStateOf("") }
    val hodNameRequest = remember {
        FocusRequester()
    }
    var examOfficerName by remember { mutableStateOf("") }
    val examOfficerRequest = remember {
        FocusRequester()
    }
    LaunchedEffect(Unit){
        instructorNameRequest.requestFocus()
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                "Enter Sheet Details",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = Color(0xFF263238)
            )
        },
        text = {
            Column {
                OutlinedTextField(
                    value = instructorName.uppercase(Locale.getDefault()),
                    onValueChange = { instructorName = it },
                    label = { Text("Instructor's Name") },
                    modifier = Modifier.fillMaxWidth().focusRequester(instructorNameRequest),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = {hodNameRequest.requestFocus()}),
                    shape = RoundedCornerShape(14.dp),
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color(0xFF4A90E2),
                        focusedLabelColor = Color(0xFF4A90E2),
                        cursorColor = Color(0xFF4A90E2)
                    )
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = hodName.uppercase(Locale.getDefault()),
                    onValueChange = { hodName = it },
                    label = { Text("HOD's Name") },
                    modifier = Modifier.fillMaxWidth().focusRequester(hodNameRequest),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    keyboardActions = KeyboardActions(onNext = {examOfficerRequest.requestFocus()}),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color(0xFF4A90E2),
                        focusedLabelColor = Color(0xFF4A90E2),
                        cursorColor = Color(0xFF4A90E2)
                    )
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = examOfficerName.uppercase(Locale.getDefault()),
                    onValueChange = { examOfficerName = it },
                    label = { Text("Examination Officer's Name") },
                    modifier = Modifier.fillMaxWidth().focusRequester(examOfficerRequest),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            if (instructorName.isNotBlank() && hodName.isNotBlank() && examOfficerName.isNotBlank()) {
                                onGenerate(instructorName.uppercase(Locale.getDefault()),
                                    hodName.uppercase(Locale.getDefault()), examOfficerName.uppercase(Locale.getDefault())
                                )
                            }
                        }),
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = TextFieldDefaults.outlinedTextFieldColors(
                        focusedBorderColor = Color(0xFF4A90E2),
                        focusedLabelColor = Color(0xFF4A90E2),
                        cursorColor = Color(0xFF4A90E2)
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (instructorName.isNotBlank() && hodName.isNotBlank() && examOfficerName.isNotBlank()) {
                        onGenerate(instructorName.uppercase(Locale.getDefault()),
                            hodName.uppercase(Locale.getDefault()), examOfficerName.uppercase(Locale.getDefault())
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF4A90E2)),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.height(40.dp)
            ) {
                Text("Generate", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("Cancel", fontWeight = FontWeight.Medium)
            }
        },
        shape = RoundedCornerShape(20.dp),
        backgroundColor = Color(0xFFF9FAFB),
        modifier = Modifier.padding(24.dp)
    )
}
fun generatePdfReport(
    module: Module,
    students: List<Student>,
    grades: List<Grade>,
    instructor: String,
    hod: String,
    examOfficer: String
) {
    val passingScore = 30
    val maxNameFontSize = 12f
    val minNameFontSize = 8f

    val document = PDDocument()
    val pageSize = PDRectangle(PDRectangle.LETTER.height, PDRectangle.LETTER.width) // Landscape
    val pageWidth = pageSize.width
    val pageHeight = pageSize.height

    val pages = mutableListOf<PDPage>()
    var currentPage = PDPage(pageSize)
    document.addPage(currentPage)
    pages.add(currentPage)

    var contentStream = PDPageContentStream(document, currentPage)
    val margin = 50f
    var yPosition = pageHeight - margin
    val lineSpacing = 18f

    fun newPage() {
        contentStream.close()
        currentPage = PDPage(pageSize)
        document.addPage(currentPage)
        pages.add(currentPage)
        contentStream = PDPageContentStream(document, currentPage)
        yPosition = pageHeight - margin
    }

    fun drawCenteredText(text: String, font: PDFont, fontSize: Float, yOffset: Float) {
        val textWidth = font.getStringWidth(text) / 1000 * fontSize
        val x = (pageWidth - textWidth) / 2
        contentStream.beginText()
        contentStream.setFont(font, fontSize)
        contentStream.newLineAtOffset(x, yOffset)
        contentStream.showText(text)
        contentStream.endText()
    }

    drawCenteredText("BIHARAMULO COLLEGE OF BUSINESS AND TECHNOLOGY ( BCBT )", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= 25f

    val resourceStream = object {}.javaClass.getResourceAsStream("/logo.png")
    if (resourceStream != null) {
        val tempLogoFile = File.createTempFile("logo", ".png")
        tempLogoFile.deleteOnExit()
        tempLogoFile.outputStream().use { output -> resourceStream.copyTo(output) }
        val pdImage = PDImageXObject.createFromFileByContent(tempLogoFile, document)
        val imgWidth = 70f
        val imgHeight = (pdImage.height.toFloat() / pdImage.width.toFloat()) * imgWidth
        val imgX = (pageWidth - imgWidth) / 2
        val imgY = yPosition - imgHeight
        contentStream.drawImage(pdImage, imgX, imgY, imgWidth, imgHeight)
        yPosition = imgY - 20f
    }

    drawCenteredText("DEPARTMENT OF INFORMATION AND COMMUNICATION TECHNOLOGY", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= lineSpacing
    drawCenteredText("SEMESTER EXAMINATION / SPECIAL & SUPPLEMENTARY EXAMINATION", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= lineSpacing
    drawCenteredText("Module Name: ${module.name}", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= lineSpacing

    val ntaLevel = module.code.filter { it.isDigit() }.drop(1).firstOrNull()?.toString() ?: "-"
    drawCenteredText("Module Code: ${module.code}     NTA Level: $ntaLevel", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= lineSpacing

    val semester = module.code.filter { it.isDigit() }.drop(2).firstOrNull()?.toString() ?: "-"
    drawCenteredText("Year of Study: 2025/26     Semester: $semester", PDType1Font.TIMES_BOLD, 12f, yPosition)
    yPosition -= 30f

    val colTitles = listOf("S/N", "Full Name", "Assign", "Quiz", "Attend", "Test1", "Test2", "CA", "UE/SE","Total","Remarks")
    val colWidths = listOf(30f, 210f, 45f, 40f, 45f, 45f, 45f, 30f, 40f,40f,90f)
    val colX = colWidths.runningFold(margin) { acc, w -> acc + w }.dropLast(1)

    val cellHeight = 20f
    val textPaddingTop = 5f

    contentStream.setFont(PDType1Font.TIMES_BOLD, 12f)
    contentStream.setStrokingColor(java.awt.Color.BLACK)
    contentStream.setLineWidth(1f)

    // Header row
    for (i in colTitles.indices) {
        contentStream.addRect(colX[i], yPosition - cellHeight, colWidths[i], cellHeight)
    }
    contentStream.stroke()
    for (i in colTitles.indices) {
        contentStream.beginText()
        contentStream.newLineAtOffset(colX[i] + 2f, yPosition - cellHeight + textPaddingTop)
        contentStream.showText(colTitles[i])
        contentStream.endText()
    }
    yPosition -= cellHeight

    contentStream.setFont(PDType1Font.TIMES_ROMAN, 12f)
    students.forEachIndexed { index, student ->
        if (yPosition < 100f) newPage()

        val grade = grades.find { it.studentId == student.regNo && it.moduleCode == module.code }

        val assignment = grade?.assignmentMark ?: ""
        val quiz = grade?.quizMark ?: ""
        val attendance = grade?.attendanceMark ?: ""
        val testOne = grade?.testOneMark ?: ""
        val testTwo = grade?.testTwoMark ?: ""
        val ca = grade?.let { g ->
            String.format(
                "%.1f",
                listOf(g.assignmentMark, g.quizMark, g.attendanceMark, g.testOneMark, g.testTwoMark)
                    .sumOf { mark -> mark.toDoubleOrNull() ?: 0.0 }
            )
        } ?: ""

        val exam = grade?.examMark
        val total = String.format(
            "%.1f",
            (ca.toDoubleOrNull() ?: 0.0) + (exam?.toDoubleOrNull() ?: 0.0)
        )
        val levelFour = listOf("Excellent(A)","Good(B)","Pass(C)","Poor(D)","Failure(F)")
        val levelSix = listOf("Excellent(A)","Very Good(B+)","Good(B)","Average(C)","Poor(D)","Failure(F)")
        val caValue = ca.toDoubleOrNull() ?: 0.0
        val examValue = exam?.toDoubleOrNull()
        val totalValue = total.toDoubleOrNull()
        val ntaLevelInt = ntaLevel.trim().toIntOrNull() ?: -1

        val remark = when {
            caValue >= passingScore && exam.isNullOrEmpty() -> "Passed"
            caValue < passingScore && exam.isNullOrEmpty() -> "Repeat"
            caValue >= passingScore && examValue != null && examValue < 20.0 -> "Supplementary"

            // Level 4 or 5 grading
            (ntaLevelInt == 4 || ntaLevelInt == 5) && examValue != null && totalValue != null -> when {
                totalValue >= 80 -> levelFour[0]
                totalValue >= 65 -> levelFour[1]
                totalValue >= 50 -> levelFour[2]
                totalValue >= 40 -> levelFour[3]
                else -> levelFour[4]
            }

            // Level 6 grading
            ntaLevelInt == 6 && examValue != null && totalValue != null -> when {
                totalValue >= 75 -> levelSix[0]
                totalValue >= 65 -> levelSix[1]
                totalValue >= 55 -> levelSix[2]
                totalValue >= 45 -> levelSix[3]
                totalValue >= 35 -> levelSix[4]
                else -> levelSix[5]
            }

            else -> "Pending"
        }


        val values = listOf(
            (index + 1).toString(),
            student.studentName,
            assignment,
            quiz,
            attendance,
            testOne,
            testTwo,
            ca,
            exam,
            total,
            remark
        )

        for (i in values.indices) {
            contentStream.addRect(colX[i], yPosition - cellHeight, colWidths[i], cellHeight)
        }
        contentStream.stroke()

        for (i in values.indices) {
            val fontSize = if (i == 1) {
                val textWidth = PDType1Font.TIMES_ROMAN.getStringWidth(values[i]) / 1000
                val maxWidth = colWidths[i] - 4f
                (maxNameFontSize.coerceAtMost((maxWidth / textWidth))).coerceAtLeast(minNameFontSize)
            } else 12f

            contentStream.beginText()
            contentStream.setFont(PDType1Font.TIMES_ROMAN, fontSize)
            contentStream.newLineAtOffset(colX[i] + 2f, yPosition - cellHeight + textPaddingTop)
            contentStream.showText(values[i])
            contentStream.endText()
        }

        yPosition -= cellHeight
    }

    yPosition -= 20f
    val nameSectionX = 50f
    val signX = 300f
    val nameFont = PDType1Font.TIMES_ROMAN

    val details = listOf(
        "Instructor: $instructor",
        "HOD: $hod",
        "Examination Officer: $examOfficer"
    )

    details.forEach { line ->
        if (yPosition < 100f) newPage()
        contentStream.beginText()
        contentStream.setFont(nameFont, 12f)
        contentStream.newLineAtOffset(nameSectionX, yPosition)
        contentStream.showText(line)
        contentStream.newLineAtOffset(signX - nameSectionX, 0f)
        contentStream.showText("Signature: ............................")
        contentStream.endText()
        yPosition -= 20f
    }

    // Draw date with superscript suffix
    val today = java.time.LocalDate.now()
    val day = today.dayOfMonth
    val suffix = when {
        day in 11..13 -> "th"
        day % 10 == 1 -> "st"
        day % 10 == 2 -> "nd"
        day % 10 == 3 -> "rd"
        else -> "th"
    }
    val baseFontSize = 12f
    val suffixFontSize = 7f
    val suffixYOffset = 4f // superscript raise amount

    // Draw "Date:" label
    contentStream.beginText()
    contentStream.setFont(nameFont, baseFontSize)
    contentStream.newLineAtOffset(50f, yPosition)
    contentStream.showText("Date: ")
    contentStream.endText()

    // Draw day number
    val dateX = 50f + nameFont.getStringWidth("Date: ") / 1000 * baseFontSize
    contentStream.beginText()
    contentStream.setFont(nameFont, baseFontSize)
    contentStream.newLineAtOffset(dateX, yPosition)
    contentStream.showText(day.toString())
    contentStream.endText()

    // Draw suffix as superscript
    val suffixX = dateX + nameFont.getStringWidth(day.toString()) / 1000 * baseFontSize
    contentStream.beginText()
    contentStream.setFont(nameFont, suffixFontSize)
    contentStream.newLineAtOffset(suffixX, yPosition + suffixYOffset)
    contentStream.showText(suffix)
    contentStream.endText()

    // Draw month and year normally after suffix
    val monthYearText = " ${today.month.name.lowercase().replaceFirstChar { it.uppercase() }}, ${today.year}"
    val monthYearX = suffixX + nameFont.getStringWidth(suffix) / 1000 * suffixFontSize
    contentStream.beginText()
    contentStream.setFont(nameFont, baseFontSize)
    contentStream.newLineAtOffset(monthYearX, yPosition)
    contentStream.showText(monthYearText)
    contentStream.endText()

    yPosition -= 20f

    drawCenteredText("Generated from GradeMate App", nameFont, 8f, 40f)

    pages.forEachIndexed { index, page ->
        val footer = PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, true)
        footer.beginText()
        footer.setFont(nameFont, 8f)
        val footerText = "Page ${index + 1} of ${pages.size}"
        val footerWidth = nameFont.getStringWidth(footerText) / 1000 * 8f
        footer.newLineAtOffset((pageWidth - footerWidth) / 2, 20f)
        footer.showText(footerText)
        footer.endText()
        footer.close()
    }

    contentStream.close()

    val outputFile = File("GradeSheet_${module.code}.pdf")
    document.save(outputFile)
    document.close()

    try {
        if (Desktop.isDesktopSupported()) {
            Desktop.getDesktop().open(outputFile)
        }
    } catch (e: Exception) {
        e.printStackTrace()
    }
}



