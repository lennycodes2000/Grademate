import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import components.Constants.academicYear
import components.Constants.intake
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
fun GradingScreen(
    students: List<Student>,
    modules: List<Module>,
    projectId: String,
    onBack: () -> Unit,
) {

    var status by remember { mutableStateOf(true) }
    var showDialog by remember { mutableStateOf(false) }
    if (showDialog) {
        TimedDialog(status) { showDialog = false }
    }

    var showGenerateDialog by remember { mutableStateOf(false) }
    var selectedModule by remember { mutableStateOf<Module?>(null) }
    val coroutineScope = rememberCoroutineScope()
    val studentGrades = remember { mutableStateMapOf<String, Grade>() }
    var showSave by remember { mutableStateOf(false) }
    var middleClicked by remember { mutableStateOf(false) }
    var quickClicked by remember { mutableStateOf(false) }
    var allowQuickSheet by remember { mutableStateOf(false) }
    val assignmentFocus = remember { FocusRequester() }
    val quizFocus = remember { FocusRequester() }
    val attendanceFocus = remember { FocusRequester() }
    val testOneFocus = remember { FocusRequester() }
    val testTwoFocus = remember { FocusRequester() }
    val examFocus = remember { FocusRequester() }
    val selectedIntakeFocus = remember { FocusRequester() }
    val initialModuleCode = "XYZ"
    var absentStudentRegNos by remember { mutableStateOf(setOf<String>()) }
    var selectedIntake by remember { mutableStateOf(intake[0]) }
    var showSaveText by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }

    // Academic year setup
    val currentYear = LocalDate.now().year
    val targetYear = "${currentYear - 1}/$currentYear"
    val targetIndex = academicYear.indexOf(targetYear).takeIf { it >= 0 } ?: 0
    var selectedAcademicYearIndex by remember { mutableStateOf(targetIndex) }
    var selectedAcademicYear by remember { mutableStateOf(academicYear[targetIndex]) }
    val selectedAcademicFocus = remember { FocusRequester() }

    // Load tutor name
    LaunchedEffect(Global.currentEmail.value) {
        if (Global.currentEmail.value.isNotEmpty()) {
            name = getTutorNameByEmail(Global.currentEmail.value).toString()
        }
    }

    // Load absences when module or academic year changes
    LaunchedEffect(selectedModule, selectedAcademicYear) {
        selectedModule?.let { module ->
            val absences = fetchAbsencesForModule(module.code, selectedAcademicYear)
            absentStudentRegNos = absences.toSet()
        } ?: run {
            absentStudentRegNos = emptySet()
        }
    }

    // Load grades for the selected module/academic year
    LaunchedEffect(selectedModule, selectedAcademicYear) {
        studentGrades.clear()
        selectedModule?.let { module ->
            try {
                val loadedGradesList = loadGradesForModule(
                    projectId = projectId,
                    moduleCode = module.code,
                    academicYear = selectedAcademicYear
                )
                val loadedGradesMap = loadedGradesList.associateBy { it.studentId }
                studentGrades.putAll(loadedGradesMap)
                println("✅ Loaded grades for ${module.code} - $selectedAcademicYear")
            } catch (e: Exception) {
                println("❌ Failed to load grades: ${e.message}")
            }
        }
    }

    // Filter students: regular first, then absent, all matching intake
    val filteredStudents = remember(selectedModule, students, absentStudentRegNos, selectedIntake) {
        selectedModule?.let { module ->
            val regularStudents = students.filter { student ->
                student.ntaLevel == module.level &&
                        module.courses.contains(student.program) &&
                        student.semester == module.semester &&
                        student.intake == selectedIntake &&
                        !absentStudentRegNos.contains(student.regNo.trim())
            }

            val absentStudents = students.filter { student ->
                absentStudentRegNos.contains(student.regNo.trim()) &&
                        student.intake == selectedIntake
            }

            (regularStudents + absentStudents).distinctBy { it.regNo }
        } ?: emptyList()
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colors.background) {
        Column(modifier = Modifier.padding(24.dp)) {

            // Back button row
            Row(modifier = Modifier.fillMaxWidth()) {
                if (!showSave) {
                    Button(
                        onClick = onBack,
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF4A90E2)),
                        modifier = Modifier.padding(bottom = 24.dp)
                    ) {
                        Text("← Back to Dashboard", color = Color.White)
                    }
                }
                Spacer(modifier = Modifier.weight(1f))
            }

            Text(
                "Grade Students",
                color = GradeMateColors.Primary,
                style = MaterialTheme.typography.h4.copy(fontWeight = FontWeight.ExtraBold),
                modifier = Modifier.padding(bottom = 16.dp)
            )

            if (students.isEmpty() || modules.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator()
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Please wait...", style = MaterialTheme.typography.body1)
                    }
                }
            } else {

                val maxCodeLength = modules.maxOfOrNull { it.code.length } ?: 0
                val maxIndexLength = modules.size.toString().length
                val sortedModules = when (Global.role.value) {
                    "Admin" -> modules
                    "HOD" -> {
                        val department = Global.department.value
                        val tutorId = Global.currentEmail.value
                        modules.filter { it.courses.contains(department) || it.tutor == tutorId }
                    }
                    "Tutor" -> modules.filter { it.tutor == Global.currentEmail.value }
                    else -> emptyList()
                }

                val options = sortedModules.mapIndexed { index, module ->
                    val paddedIndex = (index + 1).toString().padStart(maxIndexLength, ' ')
                    val paddedCode = module.code.padEnd(maxCodeLength + 3)
                    "$paddedIndex). $paddedCode${module.name}"
                }

                if (!showSave) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        DropdownMenuWithLabelModern(
                            label = "Select Module",
                            options = options,
                            selectedOption = selectedModule?.let {
                                val paddedCode = it.code.padEnd(maxCodeLength + 3)
                                "$paddedCode${it.name}"
                            } ?: "",
                            onOptionSelected = { index -> selectedModule = modules[index] },
                            modifier = Modifier.weight(2f).padding(end = 8.dp)
                        )

                        SmallerDropDownMenuWithLabel(
                            label = "Select Academic Year",
                            options = academicYear,
                            selectedOption = selectedAcademicYear,
                            onOptionSelected = { index ->
                                selectedAcademicYearIndex = index
                                selectedAcademicYear = academicYear[index]
                            },
                            nextAction = {},
                            currentAction = selectedAcademicFocus,
                            modifier = Modifier.weight(1f).padding(end = 8.dp)
                        )

                        SmallerDropDownMenuWithLabel(
                            label = "Academic intake",
                            options = intake,
                            selectedOption = selectedIntake,
                            onOptionSelected = { selectedIntake = intake[it] },
                            nextAction = {},
                            currentAction = selectedIntakeFocus,
                            modifier = Modifier.weight(1f).padding(start = 8.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            if (filteredStudents.isEmpty() && students.isNotEmpty() && selectedModule?.code != initialModuleCode) {
                Text("No matching records found.", color = Color.Red)
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(8.dp)
                ) {
                    items(filteredStudents) { student ->
                        val grade = studentGrades.getOrPut(student.regNo) {
                            Grade(
                                studentId = student.regNo,
                                moduleCode = selectedModule!!.code,
                                academicYear = selectedAcademicYear
                            )
                        }

                        val isAbsent = absentStudentRegNos.contains(student.regNo.trim())

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            elevation = 8.dp,
                            shape = RoundedCornerShape(16.dp),
                            backgroundColor = if (isAbsent) Color(0xFFE0E0E0) else Color(0xFFF5F7FA)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        painter = painterResource("person.png"),
                                        modifier = Modifier.size(30.dp),
                                        contentDescription = null,
                                        tint = if (isAbsent) Color.Gray else Color(0xFF4A90E2)
                                    )
                                    Text(
                                        text = student.studentName,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        style = MaterialTheme.typography.h6
                                    )
                                    Spacer(Modifier.weight(1f))
                                    Text(text = student.regNo)
                                }

                                if (isAbsent) {
                                    Text(
                                        "Absent",
                                        color = Color.Red,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }

                                Divider(modifier = Modifier.padding(vertical = 8.dp))

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    markInput("Assignment", grade.assignmentMark, {
                                        studentGrades[student.regNo] = grade.copy(assignmentMark = it)
                                    }, assignmentFocus, quizFocus)

                                    markInput("Quiz", grade.quizMark, {
                                        studentGrades[student.regNo] = grade.copy(quizMark = it)
                                    }, quizFocus, attendanceFocus)

                                    markInput("Attendance", grade.attendanceMark, {
                                        studentGrades[student.regNo] = grade.copy(attendanceMark = it)
                                    }, attendanceFocus, testOneFocus)

                                    markInput("Test One", grade.testOneMark, {
                                        studentGrades[student.regNo] = grade.copy(testOneMark = it)
                                    }, testOneFocus, testTwoFocus)

                                    markInput("Test Two", grade.testTwoMark, {
                                        studentGrades[student.regNo] = grade.copy(testTwoMark = it)
                                    }, testTwoFocus, examFocus)

                                    OutlinedTextField(
                                        value = String.format("%.1f", grade.caMark),
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("CA Mark") },
                                        modifier = Modifier.width(100.dp),
                                        singleLine = true
                                    )

                                    if (grade.caMark >= 30.0) {
                                        markInput("Exam", grade.examMark, {
                                            studentGrades[student.regNo] = grade.copy(examMark = it)
                                        }, examFocus, null, maxAllowed = 40)
                                    }

                                    OutlinedTextField(
                                        value = String.format("%.1f", grade.total),
                                        onValueChange = {},
                                        readOnly = true,
                                        label = { Text("Total Mark") },
                                        modifier = Modifier.width(100.dp),
                                        singleLine = true
                                    )

                                    val examValue = grade.examMark.trim().replace(",", ".").toDoubleOrNull() ?: 0.0

                                    val shownGrade = when {
                                        grade.caMark < 30 -> "Repeat"
                                        examValue < 20 -> "Technical Supplementary (TS)"
                                        selectedModule?.level?.toIntOrNull() != 6 -> when {
                                            grade.total >= 80 -> "A"
                                            grade.total >= 65 -> "B"
                                            grade.total >= 50 -> "C"
                                            grade.total >= 40 -> "D"
                                            else -> "F"
                                        }
                                        else -> when {
                                            grade.total >= 75 -> "A"
                                            grade.total >= 65 -> "B+"
                                            grade.total >= 55 -> "B"
                                            grade.total >= 45 -> "C"
                                            grade.total >= 35 -> "D"
                                            else -> "F"
                                        }
                                    }


                                    grade.academicYear = selectedAcademicYear

                                    Text(
                                        text = shownGrade,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        style = MaterialTheme.typography.h6
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            // Save grades
            suspend fun saveAllGrades(): Pair<Int, Int> {
                var successCount = 0
                var totalToSave = 0

                selectedModule?.let { module ->
                    // Ensure we have a Grade object for every filtered student (so we actually attempt to save them)
                    filteredStudents.forEach { student ->
                        studentGrades.putIfAbsent(
                            student.regNo,
                            Grade(
                                studentId = student.regNo,
                                moduleCode = module.code,
                                academicYear = selectedAcademicYear
                            )
                        )
                    }

                    // Students in the selected intake (filteredStudents already uses intake)
                    val studentsInIntake = filteredStudents.map { it.regNo }.toSet()

                    // Collect exactly the grades we intend to save:
                    val gradesToSave = studentGrades.values.filter { grade ->
                        grade.moduleCode == module.code &&
                                grade.academicYear == selectedAcademicYear &&
                                studentsInIntake.contains(grade.studentId)
                    }

                    totalToSave = gradesToSave.size

                    // Save them and count successes
                    gradesToSave.forEach { grade ->
                        try {
                            val ok = saveGradeToFirestore(projectId, grade)
                            if (ok) {
                                successCount++
                                println("✅ Saved grade for ${grade.studentId}")
                            } else {
                                println("❌ Failed to save grade for ${grade.studentId}")
                            }
                        } catch (e: Exception) {
                            println("❌ Exception saving ${grade.studentId}: ${e.message}")
                        }
                    }
                }

                // UI flags / dialogs
                if (totalToSave > 0 && successCount == totalToSave) {
                    showDialog = true
                    if (middleClicked) showGenerateDialog = true
                    if (quickClicked) allowQuickSheet = true
                } else if (totalToSave > 0) {
                    status = false
                    showDialog = true
                } else {
                    // nothing to save — optionally set status to false or show a toast
                    status = false
                    showDialog = true
                }

                quickClicked = false
                middleClicked = false

                return successCount to totalToSave
            }


            // Action buttons
            if (!showSave && filteredStudents.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally)
                ) {
                    val sideButtonModifier = Modifier.weight(1f).height(56.dp)
                    val middleButtonModifier = Modifier.weight(2f).height(56.dp)

                    // Save Data
                    Button(
                        onClick = {
                            showSave = true
                            coroutineScope.launch {
                                val (successCount, totalAttempted) = saveAllGrades()
                                println("✅ Saved $successCount / $totalAttempted grades")
                                showSaveText = "✅ Saved $successCount / $totalAttempted grades"
                                showSave = false
                            }
                        },
                        modifier = sideButtonModifier,
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF4A90E2), contentColor = Color.White)
                    ) {
                        Text("Save Data", style = MaterialTheme.typography.button.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp))
                    }

                    // Generate Sheet
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                middleClicked = true
                                showSave = true
                                saveAllGrades()
                                showSave = false
                            }
                        },
                        modifier = middleButtonModifier,
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF4A90E2), contentColor = Color.White)
                    ) {
                        Image(painter = painterResource("pdf.svg"), contentDescription = "Export Sheet", modifier = Modifier.size(30.dp))
                        Spacer(Modifier.width(10.dp))
                        Text("Generate Sheet", style = MaterialTheme.typography.button.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.75.sp))
                    }

                    // Quick Sheet
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                showSave = true
                                quickClicked = true
                                saveAllGrades()
                                showSave = false
                            }
                        },
                        modifier = sideButtonModifier,
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFF4A90E2), contentColor = Color.White)
                    ) {
                        Text("Quick Sheet", style = MaterialTheme.typography.button.copy(fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp))
                    }
                }
            } else if (showSave) {
                Column(modifier = Modifier.fillMaxWidth().height(56.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }
        }
    }

    // Generate Sheet Dialog
    if (showGenerateDialog) {
        GenerateSheetDialog(
            onDismiss = { showGenerateDialog = false },
            onGenerate = { instructor, hod, examOfficer ->
                selectedModule?.let { module ->
                    coroutineScope.launch {
                        val gradesList = loadGradesForModule(projectId, module.code, selectedAcademicYear)
                        generatePdfReport(module, filteredStudents, gradesList, instructor, hod, examOfficer, selectedAcademicYear, selectedIntake, name)
                    }
                }
                showGenerateDialog = false
            }
        )
    }

    // Quick Sheet
    if (allowQuickSheet) {
        selectedModule?.let { module ->
            coroutineScope.launch {
                val gradesList = loadGradesForModule(projectId, module.code, selectedAcademicYear)
                generateQuickReport(module, filteredStudents, gradesList, selectedAcademicYear, selectedIntake, name)
            }
        }
        showSave = false
        allowQuickSheet = false
    }
}
