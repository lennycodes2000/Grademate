import components.Constants
import java.io.File
import java.util.Properties
import javax.mail.*
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeMultipart


fun sendEmail(
    to: List<String>,
    subject: String,
    body: String,
    attachment: File
) {
    val from = Constants.email
    val password = Constants.appPass

    val props = Properties().apply {
        put("mail.smtp.auth", "true")
        put("mail.smtp.starttls.enable", "true")
        put("mail.smtp.host", "smtp.gmail.com")
        put("mail.smtp.port", "587")
    }

    val session = Session.getInstance(props,
        object : Authenticator() {
            override fun getPasswordAuthentication(): PasswordAuthentication {
                return PasswordAuthentication(from, password)
            }
        })

    try {
        val message = MimeMessage(session)
        message.setFrom(InternetAddress(from))

        // Add all recipients
        val recipients = to.map { InternetAddress(it) }.toTypedArray()
        message.setRecipients(Message.RecipientType.TO, recipients)

        message.subject = subject

        // Text body
        val mimeBodyPart = MimeBodyPart().apply {
            setText(body)
        }

        // Attachment body
        val attachmentBodyPart = MimeBodyPart().apply {
            attachFile(attachment)
        }

        val multipart = MimeMultipart().apply {
            addBodyPart(mimeBodyPart)
            addBodyPart(attachmentBodyPart)
        }

        message.setContent(multipart)

        Transport.send(message)
        println("✅ Email sent successfully to ${to.size} recipients with attachment")

    } catch (e: MessagingException) {
        e.printStackTrace()
    }
}

