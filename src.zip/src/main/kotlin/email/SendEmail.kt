import components.Constants
import java.io.File
import java.util.Properties
import javax.mail.*
import javax.mail.internet.InternetAddress
import javax.mail.internet.MimeBodyPart
import javax.mail.internet.MimeMessage
import javax.mail.internet.MimeMultipart


fun sendEmail(
    to: List<String>,
    subject: String,
    body: String,
    attachment: File?
): Boolean {
    val from = Constants.email
    val password = Constants.appPass

    val props = Properties().apply {
        put("mail.smtp.auth", "true")
        put("mail.smtp.starttls.enable", "true")
        put("mail.smtp.host", "smtp.gmail.com")
        put("mail.smtp.port", "587")
    }

    val session = Session.getInstance(props, object : Authenticator() {
        override fun getPasswordAuthentication(): PasswordAuthentication {
            return PasswordAuthentication(from, password)
        }
    })

    return try {
        val message = MimeMessage(session).apply {
            setFrom(InternetAddress(from))
            setRecipients(Message.RecipientType.TO, to.map { InternetAddress(it) }.toTypedArray())
            setSubject(subject)

            val mimeBodyPart = MimeBodyPart().apply { setText(body) }

            val multipart = MimeMultipart().apply {
                addBodyPart(mimeBodyPart)
                if (attachment != null) {
                    val attachmentPart = MimeBodyPart().apply { attachFile(attachment) }
                    addBodyPart(attachmentPart)
                }
            }

            setContent(multipart)
        }

        Transport.send(message)
        println("✅ Email sent successfully to ${to.size} recipients")
        true
    } catch (e: Exception) {
        e.printStackTrace()
        println("❌ Failed to send email: ${e.message}")
        false
    }
}


