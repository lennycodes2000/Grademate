

@kotlinx.serialization.Serializable
data class FirestoreGradesListResponse(
    val documents: List<FirestoreDocumentGrade>
)
@kotlinx.serialization.Serializable
data class FirestoreGradeDocument(val fields: GradeFields)
data class Grade(
    val studentId: String,
    val moduleCode: String,
    val assignmentMark: String = "",
    val quizMark: String = "",
    val attendanceMark: String = "",
    val testOneMark: String = "",
    val testTwoMark: String = "",
    val examMark: String = "",
    var academicYear:String = ""
) {
    val digits = moduleCode.filter { it.isDigit() } // get all digits from the code

    val ntaLevel = digits.getOrNull(1)?.toString() ?: "0"   // second digit is level
    val semester = digits.getOrNull(2)?.toString() ?: "0"


    val caMark: Double
        get() = listOf(
            assignmentMark,
            quizMark,
            attendanceMark,
            testOneMark,
            testTwoMark
        ).sumOf { it.trim().replace(",", ".").toDoubleOrNull() ?: 0.0 }

    val total: Double
        get() = caMark + (examMark.trim().replace(",", ".").toDoubleOrNull() ?: 0.0)
}



